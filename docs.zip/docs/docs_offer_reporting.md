# Scraped content from: https://docs.capillarytech.com/docs/offer-reporting

Reporting

Suggest Edits

You can generate charts and reports based on your requirements using the coupon KPI and dimensions. For more information, refer to KPI and Dimension documentation. For information on the Fact and Dimension table related to Coupon, refer to the Fact and Dimension table documentation.

Updated 6 months ago