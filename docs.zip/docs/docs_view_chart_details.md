# Scraped content from: https://docs.capillarytech.com/docs/view-chart-details

View Chart Details

Suggest Edits

To view chart details, follow these steps:

Navigate to Library > Charts.

Select the chart type - Normal, Migration or Funnel.

In Search Charts, search the chart either from the list or search by the name. Click the desired chart to open it.



Click More options > View chart details.



The system displays the chart details.



Updated 11 months ago