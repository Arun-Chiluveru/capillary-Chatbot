# Scraped content from: https://docs.capillarytech.com/docs/whatsapp

WhatsApp

Suggest Edits

Creating WhatsApp template - https://docs.capillarytech.com/docs/create-whatsapp-template

Creating WhatsApp content - https://docs.capillarytech.com/docs/create-whatsapp-content

The communications on WhatsApp are sent based on the user's subscription status. For more information, refer to the documentation here.

Updated 8 months ago