# Scraped content from: https://docs.capillarytech.com/docs/grouping-and-ranking-of-badges

Rewards Event Notification

Suggest Edits

An event notification is sent to the user for the following events:

Reward Creation

Reward Issued

Reward Updation

Issue Reward Failure

Reward Expiry

Configuring Reward Expiry Event Notification

The Reward Expiry event notification enables you to proactively engage users by notifying them about expired rewards and manage notifications to reduce missed redemption opportunities, thereby increasing customer satisfaction and enhancing loyalty program engagement. Perform the following to configure an event notification for reward expiry.

Create a webhook URL and then configure the event notification settings.

Enable the Expiry feature using the config.

Configure the event expiry duration and time. If needed, you can update or retrieve details of the reward expiry.

Test and verify the event notification

Create a test reward with an upcoming expiry date

Verify event configuration is enabled in UI

Confirm API configuration is successful

Check your webhook endpoint receives notifications

Updated 5 months ago