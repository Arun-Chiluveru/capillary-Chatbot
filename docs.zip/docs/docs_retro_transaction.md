# Scraped content from: https://docs.capillarytech.com/docs/retro_transaction

PII cleanup template

Suggest Edits

This template enables you to delete Personal Identifiable Information (PII) data of customers in bulk.

Perform the below steps:

In the Connect to Source Block, enter the source server details. See Connect to source.

In the Transform data block, enter the transformation details and map the API fields.

API Field Transformation Example source Customer registration source Wechat, web_engage etc identifierType Customer identifier type Mobile, e-mail etc identifierValue Customer identifier value for the defined identifier type mobile number, e-mail id etc type Type of request. In this case, the value should be CUSTOMER. Customer baseType Subtype of the request. In this case, the value should be DELETE. Delete accountId Account id of the sources with multiple accounts. This is required only if there are multiple accounts of the same source. 123344 comments Additional comments if any Any comment

In the Connect to destination block, enter the PII deletion API endpoint details (https://<host>/v2/requests). See Connect to destination. For information on PII deletion API endpoint, see PII deletion API documentation.

Set the trigger frequency. See Trigger frequency.

📘

If the brand has multiple source profiles, for every source profile you need not run this flow multiple times. During the first run itself, the dataflow deletes both profile's PII data.

Updated over 1 year ago