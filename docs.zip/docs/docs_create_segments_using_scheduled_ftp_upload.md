# Scraped content from: https://docs.capillarytech.com/docs/create-segments-using-scheduled-ftp-upload

Configure SFTP server for data export

Suggest Edits

You can export data only to an SFTP server. Insights+ supports configuring up to five SFTP servers and using the desired one while configuring an export job. For example, you can have one dedicated to Capillary internal exports and others for org exports based on the location. From the SFTP location, you can then download data to your local machine.

📘

Note

An SFTP once added you cannot be deleted or renamed. However, you can change server details and the path within that SFTP.

Prerequisites

Destination SFTP server for data storage

Source Host server IP for data retrieval

FTP Configuration Details:

Hostname

Port number

Username and Password

Path to the folder

Configuring SFTP

To configure the SFTP server, follow these steps.

Whitelist the below Capillary's IP addresses to allow connections to the brand's SFTP server.

Cluster IPs APAC1/INCRM 54.235.251.85 3.227.110.70 APAC2/SGCRM 3.0.242.134 3.1.68.245 EUCRM 54.247.60.162 52.214.98.25 USCRM 18.224.36.121 18.189.151.155

On Insights+ UI navigate to Settings > FTP and click Add FTP Server.

1312

Enter the following details:



Ftp name - Specify a name for the SFTP Server. The name will be displayed when configuring an export job (in Select FTP).

Server Address - enter the URL of the SFTP. If the default port (22) is being used, then enter the URL of the client SFTP server. For example, abc.def.com. If custom port 82 is used, then enter the URL with the port number of the client SFTP server. For example, abc.def.com:82

Username - Enter the username of the SFTP server.

Password - Enter the password of the SFTP server.

Default Target Folder box - Specify the path in the SFTP server to which you want the data to be saved. For example, '/export'. If the path is not specified, data will be saved in the root directory of the SFTP server.

Enable Password Protection - Select Yes to enable password protection for the files that will be exported to the current server.

Click Submit.

🚧

Note

If the specified folder is not identified in the Target Path of the SFTP server, the configuration fails.

The file name of an exported file will have the following naming convention. * schedulenametemplateName_timestamp. For example, DailySlabChangeSlabChangeLog2019-10-29-12-30-021572356331802.

Testing SFTP configuration

You can either export a test file from Insights and test if the file is exported successfully or can also check the connection using Wetty.

To check the connection using Wetty,

Run the command nmap <hostname> to check the open port for a host.



Run the command telnet <hostname> <port>.



Updated about 1 year ago