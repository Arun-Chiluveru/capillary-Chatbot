# Scraped content from: https://docs.capillarytech.com/docs/attribute-target-based

Deactivating and Activating Badges

Suggest Edits

Deactivating a badge

Badges can be deactivated and activated from the quick actions as shown below. Click Deactivate to deactivate the badge.



Once deactivated, the badge cannot be issued to new customers or claimed by any module.



Activating a badge

Once the badges have been deactivated, they can be activated again from the quick actions as shown below. Click Activate to reactivate the badge.



Once reactivated, badges can be issued to customers and can be claimed as well by other modules.

Updated about 1 year ago