# Scraped content from: https://docs.capillarytech.com/docs/fact_registration-event

Create segments using filters

Suggest Edits

Introduction

Segments are equipped with predefined rules using which you can set conditions for each partition. The segment details are updated automatically based on the ruleset. Rule-based segments are usually SCD and activity-based.

For example, you can have a segment based on RFM (Recency, Frequency, Monetary) and have partitions as explained below:

Champions: High spending customers who purchased recently and also shop quite often (Last Txn Date in the last 10 days) AND (Latency < 25) AND (Lifetime Purchased > 500)

Loyal Customers: A frequent shopper and responsive to promotions. (Last Txn Date in the last 30 days) AND (Latency between 25 and 45) AND (Lifetime Purchased between 200 and 500)

📘

Note

Each org unit can create a maximum of 20 SCD segments. So if you want to create a new one thereafter, you need to deactivate an existing SCD segment and create a new one. If the brand requires more than 20 SCD segments, they can request additional segments by contacting the product sustenance team.

There is no limit on non-SCD segments.

To create a rule-based segment:

On the EI navigation pane, click User Segments > Create Segment.

In Segment Name, specify a name for the group.

In Description, specify a short description of the segment.

In Type, select SCD to keep a track of customers' behavior for the current segment. Select Non-SCD to save only the current snapshot.

In Method, choose Conditions for creating based on rule conditions.

Click Next to continue.

966

In Update, choose your preferred frequency for updating the segment data.

Manually: To update the partition values manually. The list will be updated only if the list is refreshed manually on the segment details page.



Daily: To update the segment values on a daily basis.

Weekly: To update the list on a weekly basis.

Monthly: To update the list on a monthly basis.

In Partition name, specify a name for the partition.

885

In Description, specify a short description for the partition.

Click +Add rule > Customer summary KPIs and choose the desired option on which you want to define the condition.

199

832

FILTER DESCRIPTION Average Spent Per SKU Get customers based on their average item value (Total items purchased/total transaction amount) Average Spent Per Visit Get customers based on their average transaction value per visit (Total transaction amount/No. of visits) Canceled Points Get customers by the number of reverted points. That is, issued points that were reverted due to reasons like transaction return. Expired Points Get customers by their expired points (points that are expired for not redeeming within the expiry period) First Visit Basket Size Get customers by the number of items purchased during their first visit (line-item count) First Visit Bill Amount Get customers by their transaction amount during their first visit (line-item count) Has Spike Bill Used to get Fraud bills. Gets customers whose bills have a sudden spike. For example, spiked 2 times, spiked greater than 5 times, and so on Last Visit Bill Amount Get customers by their recent bill amount Latency Get customers by their average duration between two transactions Lifetime Points Get customers by their total loyalty points earned (considering from the registration date) Lifetime Purchased Get customers by their lifetime purchases amount (Total transaction amount after becoming a member) Line Item Count Get customers by the total number of line-items purchase Loyalty Points Get customers by their current or active loyalty points Max Bill Amount Get customers by the maximum bill amount recorded Max Bill Count In Day Get customers by their maximum number of transactions in a day Max Bill Count In Week Get customers by their maximum number of transactions in a week Max Zones With Billing On Same Day Get customers based on their transactions recorded in one or more zones on the same day (fraud customers) Number Of Visits Get customers by their total number of visits  (visited and made transactions) Number Of Visit Days Get customers by the unique number of days visited Points Awarded Days Get customers by the unique number of days loyalty points were awarded Redeemed Points Get customers by the number of loyalty points redeemed Redeemed Rate Get customers by the percentage of points redemption - (Points Redeemed/Points Awarded) * 100 Redeemed Visits Get customers by the unique number of days customers redeemed their points Redeemed Visit Days Get customers by the unique number of days customers redeemed their coupons Redeemed Voucher Count Get customers by the number of coupons redemption Redemption Latency Get customers by the average gap (in days) between two consecutive redemption Returned Bill Amount Get customers by the total amount of return transactions Returned Bill Count Get customers by the number of transactions returned SKUs Returned Get customers by the total number of items (SKUs) returned SKU Purchased Get customers by the total number of items (SKUs) purchased Total Bill Amount Get customers by their total transaction amount Total Bill Count Get customers by their transactions count Total Line Item Amount Get customers by the total amount of line items purchased in their transactions Total Points Redeemed Get customers by the total number of points redeemed Total Returned Line Item Amount Get customers by the total amount of returned line items Conversion Date Get customers by their loyalty conversion date (loyalty registration date) during a specified period DOB Date Get customers by their birth date (day, month) First Points Awarded Date Get customers based on the date when points were first awarded First Points redemption date Get customers based on the date when points were first redeemed  (relative days or during a specified period) First coupon redemption date Get customers based on the date when a coupon was first redeemed (relative days or during a specified period) Lapsation Date Get customers by their lapsation date (did not shop for a specific duration) First Txn Date Get customers whose first transaction is in a specified period Last Txn Date Get customers whose recent transaction date is in a specified period Last Points Redemption Date Get customers whose recent points redemption is in a specific period Last Coupon Redemption Date Get customers whose recent coupons redemption is in a specific period Wedding Date Get customers by their wedding anniversary date. That is, anniversary in a specific duration

To validate more than one condition, click + Add rule that uses OR operator - In this, a customer is added to the partition, if any of the specified conditions are satisfied.

838

To validate multiple rules (and), click +Rule Set (AND) > + Add Rule. In this, a customer is added to the partition only if both conditions are satisfied

840

Click Save.

📘

The Description field is mandatory along with other fields. The save button will not be enabled if the Description is left blank.

Similarly, multiple partitions are required, and click Compute & Proceed. You will see the Processing bar.

892

878

Click Create to complete creating the segment. Else, it will be in the draft state

902

The segment will be in Inprogress status initially and once processed, the status label will disappear automatically.

Inprogress: The segment creation is being processed

Note:

Draft: Signifies draft state where the recent changes were not saved. If you open the segment, you will see Draft available: Save changes to see the partition values. You can save or Deactivate draft segments

Active segment: Only active segments will appear on the service that consumes Segments. You can either edit or deactivate active segments

Inactive segment: These segments will be inactive and will not appear in any service that consumes segments. You can edit and activate inactive segments

Editing an existing rule-based segment

You can modify a segment to add new partitions or modify rules for existing partitions.

To edit a segment

On the Segments summary page, click on the segment that you want to edit. You can filter the summary list by Type (SCD, Non-SCD, or All) and Method (Condition, Upload, or All) and also search for a specific filter in the Search box

Click on the drop-down box that appears on the top and chooses Edit Segment.

916

Click Edit Partitions.

To add a new partition, click Add Partition. If you want to update the rule of an existing partition, click on the More options icon > Edit. Modify rules as needed and click Save.

883

Click Compute & Proceed. You will see the Processing bar

Click Update to complete creating the segment. Else, it will be in the draft state.

📘

If you try to edit the draft version, you will see the following prompt . Click Continue editing draft version to start editing the previously saved version, click Discard draft and edit current state to discard the previously saved draft version and edit

274

Deactivate: You can click the Deactivate button to inactivate a segment and vice versa Refresh: This lets you update the segment manually. This can be used for segments with the manual update. However, if you have a segment that is set to update monthly or any other frequency, you can get the updated list whenever required by clicking this manual Refresh. The time to complete the process depends on the rules to be evaluated and the data size.

881

Limit of only 20 SCD segments: You can create up to 20 SCD segments only. If you want to create a new SCD segment thereafter, you need to deactivate an existing one and create new one.

Updated 6 months ago