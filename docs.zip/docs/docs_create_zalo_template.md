# Scraped content from: https://docs.capillarytech.com/docs/create-zalo-template

Create Zalo template

Suggest Edits

You can use the Zalo notification service (ZNS) to send messages through Zalo, a popular communication channel in Vietnam.

Prerequisite

An official Zalo account (OA) is required.

Configuring the template

Configuration of the Zalo template can only be done through the Capillary Gateway support team.

Approval of Zalo templates

The Zalo template needs to be approved and whitelisted by Zalo. This approval process is handled by the Capillary Gateway team/vendor. You can filter the Zalo templates in the Creatives by their status.



Previewing of a template

To preview a template, click the preview button or the overview button.







👍

Note

To avoid exceeding the character limit for variables, add labels.

Using Zalo templates in Campaigns and journeys

You can use Zalo for communication in campaigns as well as in journeys.

📘

Note

Only approved templates are available for selection when you add Zalo templates in campaigns or journeys.

Using Zalo templates in Journeys

You can add Zalo as an engagement block in the Journeys to send communication. For more information on adding engagement blocks in a Journey, refer to the documentation on Journey.



Using Zalo templates in campaigns

To use a Zalo template in the campaign, select the required Zalo template while adding creatives to the campaign message. For more information on adding creatives in a Campaign message, refer to the documentation here.



Editing the Zalo template

You can edit the template after adding it to the campaign or a journey.

To edit, open the campaign/journey, navigate to the Zalo template in the Journey/Campaign and click on the edit icon. Make the required changes and click Done.



For information on Generate OTP APIs, refer to the API documentation.

Updated 6 days ago