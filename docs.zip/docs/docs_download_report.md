# Scraped content from: https://docs.capillarytech.com/docs/download-report

Download Report

Suggest Edits

You can download a report to an Excel sheet for offline analysis. Both standard and custom reports are available for download. The downloaded report consists of the entire data of the report such as segment level data for each KPI and filters applied.

To download a report:

Open the report that you want to download.

Click the More Options icon > Download Report.



You will see the report summary in the first sheet and data of each chart in different tabs as shown below.

The report contains the summary along with the descriptions of KPIs and Dimensions, scorecards, and data from individual charts of the report.

1172

Updated 10 months ago