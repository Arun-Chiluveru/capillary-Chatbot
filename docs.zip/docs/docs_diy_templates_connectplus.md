# Scraped content from: https://docs.capillarytech.com/docs/diy-templates-connectplus

Configuring Goodwill Points Request Workflow

Suggest Edits

This request is mapped to a standard workflow, allowing you to submit requests to issue goodwill points.

Points redemption standard workflow

As part of the standard workflow, the Capillary platform provides a two-step approval process involving a Maker and Checker-based workflow.

Users with “CanMakeRequest” access can submit a request to issue goodwill points.

Users with “CanCheckRequest” access can approve or reject the request.

Once a Checker approves a request, the system executes it, allowing the issue of the goodwill points.

Configurations

Auto approval - You can enable Auto-approval configuration to enable auto-approval of certain user requests.

Goodwill points upper cap - You can set an upper cap to restrict the issue of goodwill points.

To configure, perform the following:

From the Request Workflows list, navigate to Goodwill_points > Edit request workflow mapping.

To set auto-approval, turn on the Auto-approval flag toggle.

To set an upper cap for goodwill point issue, in Goodwill points upper cap, enter the goodwill points upper cap value.

For sending e-mail notifications on the request status, enter the customer's e-mail ID.

Click Save.



APIs to create, approve and retrieve request details

Create request - https://docs.capillarytech.com/reference/issue-goodwill-points

Approve or reject a request - https://docs.capillarytech.com/reference/approve-or-reject-a-request

Retrieve details of a request - https://docs.capillarytech.com/reference/get-request-info

Updated 10 months ago