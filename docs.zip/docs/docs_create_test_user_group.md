# Scraped content from: https://docs.capillarytech.com/docs/create-test-user-group

Create test user group

Suggest Edits

User groups are special users that you can use to test campaign messages or share the campaign reports and alerts.

To create a test user group, follow these steps.

On the Engage+ home page, click on the setting icon and navigate to the User Groups page.

Click Create user group.

791

In Name, enter the name of the test group.

On the All contacts page, add each user using +Add. You can use the search box to find a specific user.

Click Done to save the group. Similarly, you can create multiple user groups.

📘

If the users you add have invalid email addresses. the group will not save.

Updated over 1 year ago