# Scraped content from: https://docs.capillarytech.com/docs/apply-dimensions-to-charts

Apply Dimensions to Charts

Suggest Edits

A dimension is an attribute by which you can classify and group the data. Dimensions can be applied to a KPI but cannot exist independently. Applying various dimensions to charts aids in understanding business data, such as sales data categorized by date, zone, month, year, etc., enabling deeper insights and analysis.

For example, if you are interested in analyzing the number of transactions at each store, you can set "Transactions" as the Key Performance Indicator (KPI), representing the metric you want to measure. The dimension would be "Store-wise data," indicating that you want to categorize the transaction data based on different stores.

Similarly, in the second scenario, if you are examining sales data, you can set "Sales" as the KPI, representing the metric you are analyzing. The dimension would be "Product-wise data," indicating that you want to categorize the sales data based on different products.

There are two types of dimensions:

Primary Dimensions - These are the dimensions selected by default while creating the report.

Secondary Dimensions - These are the additional supported dimension attributes you can add to a chart.

You can apply dimensions for chart cards.

Add Dimensions/ Attributes to a Chart

You can replace primary dimensions with the same type of attribute values by expanding the drop-down box and selecting the values.

To change the attribute of an applied dimension: Open the report and scroll down to the chart card for which you want to apply dimensions. Expand the attribute drop-down and select the required attribute.



To add more dimensions, Click +/- attribute.



For example, to see a month-wise report of the current year, click Date to expand and select Month.



Following is the tabular format (for better understanding) of the zone-wise, month-wise reports.



You can see all applied dimensions below the chart header.



Remove a dimension attribute: Click X to remove the respective attribute.

Note: Dimensions are applied at the chart-card level and cannot be applied to the entire report.

Updated 10 months ago