# Scraped content from: https://docs.capillarytech.com/docs/create-email-template

Create email template

Suggest Edits

To create a new email content

955

On the dashboard, click the Creatives tab and then click the Email tab.

Click Create new.

Enter a Creative name.

Select a create option from the followings:

907

Upload zip file

Click Upload zip file, then click Upload.

Browse a file (format: .zip, .html, .htm), and then click Continue.

In the email body; modify the text and formatting, add images and labels, and then click Create.

958

Create using the editor

Click Create using editor, then click Continue.

Click Select on the appropriate template.

In the email body; modify the text and formatting, add images and labels, and then click Create.

943

📘

Notes

You can also create email content from Create message section.

Unsubscribe tag is compulsory to include. To know more about each tag, see Message content section.

You can upload a file with a size limit of up to 10MB.

Troubleshooting email image quality issues

👍

Notes

Do not forcefully enlarge images.

Use actual images or image URLs in zip files without enlarging them.

Issue Resolution File size is getting reduced Expected behavior. File size reduction due to image transformations does not affect user experience. Specify image dimensions to maintain quality. For example, if the email specifies a height and width of 200 x 300, images are transformed to match these dimensions instead of saving the original image, which might have very high dimensions. Consequently, the file size is reduced. This reduction could also occur due to dynamic image quality adjustments based on file sizes. Image getting compressed excessively Compression varies with file size. Smaller images have less compression; larger images undergo higher compression. This makes sure that irrespective of the file size, similar quality of images is achieved after compression. Do not artificially enlarge images to increase the file size. Images saved in avif format instead of jpeg Images are saved in their actual format except when the device supports avif format. avif format enables saving the images in smaller file sizes without impacting image quality.

For information on Generate OTP APIs, refer to the API documentation.

Updated 6 days ago