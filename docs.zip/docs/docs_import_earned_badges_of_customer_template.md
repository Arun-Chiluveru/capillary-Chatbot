# Scraped content from: https://docs.capillarytech.com/docs/import-earned-badges-of-customer-template

Points expiry

Suggest Edits

Update Points Expiry (Date range)

This profile lets you update the validity of points (of a customer) that are expiring in a specific date range. It is very important to understand how the issued and expired points will be affected by this import. Example:

Consider Blue Purple(org) loyalty program is having 12 months of points validity for a list of customers which they want to change to 24 months. In such case, you can select the extended expiry type and use the relative point expiry option to update the point expiry duration from 12 to 24 months.

Facts Date & duration Current date August 01, 2021 Actual point expiry date July 31, 2022 (12 months from current date) Extended point expiry date July 31, 2023  (24 months from current date)

CSV Fields

Customer identifier (User ID/External ID/Email/Mobile/Card Number)* CSV Sample using User ID:

User Id

1250755



Template configuration



Option Description Choose customer's unique identifier Choose the unique customer identifier used in the CSV to identify customers. USER_ID MOBILE EMAIL EXTERNAL_ID CARD_NUMBER Program Name Select the loyalty program name for which you want to update the point expiry date. Select start date - Select end date Set the duration for which you want to update the expiry date. Any points that are expiring in the specified duration will be updated as per the new expiry date you set. Select Expiry Update Reason Type Choose your preferred type for points update. Early expiry : Select this option to expire points before the actual expiry date. For example, If the actual point expiry date is August 30, 2021, then the early expiry date must be before August 30, 2021. Extended expiry : Select this option to extend the expiry date from the actual expiry date. For example, If the actual point expiry date is August 30, 2021, then the extended expiry date must be after August 30, 2021. Select Expiry Update Reason Note Enter the reason for updating the point expiry date. Set expiry date to Choose the expiry date from the following options. Fixed date expiry : Set a date on which you want to expire the points. Fixed date expiry must be greater than the current date. For example, If the current date is August 29, 2021, then the fixed date expiry must start from August 30, 2021 Relative date expiry : Set the number of days or months after which the points will expire. For example, If the current date is July 29, 2021(today) and you set the expiry count to 5 days then the point expiry date will be August 02, 2021. * Immediate expiry : Select this option if you want the points to be expired immediately(the moment system has successfully updated the point expiry using data import. Expire Promised Points Select this to expire promised points.

Update Points Expiry (PointsType & RefID)

This profile lets you modify the points expiry of a customer based on Point Awarded Reference Type and Point Awarded Reference ID. It is very important to understand how the issued and expired points will be affected by this import.

Example:

Consider there are five customers in an org with different reasons to update their point expiry and you want to update customer 1, customer 2, and rest customers(customer 3, 4, and 5) with different expiry type(extended or early expiry) and date(fixed, relative, or immediate).

Use case 1 - Update expiry for a customers with point awarded reference ID Consider customer 1 has accidentally received points with a incorrect validly (incorrect validity awarded - 4 months, correct validity should be - 6 months). In this case, you can update customer 1 with an extended points expiry of 2 months(relative) using point awarded reference ID. Note: When point awarded reference ID is mentioned then you also have to mention point awarded reference type in the csv file.

Facts Date & duration Current date August 01, 2021 Incorrect point expiry date September 31, 2021 (31 days from current date) Extended point expiry date October 31, 2021 (After 2 months from incorrect point expiry date)

Use case 2 - Update expiry for a customers with point awarded reference type Consider customer 1 has 100 points that are going to expire on August 31, 2021 but the store will be closed from August 22, 2021 to August 31, 2021(10 days) due to store redesigning. In this case, you can update customer 2 with an extended points expiry of 10 days(relative) using point awarded reference type.

Facts Date & duration Current date August 01, 2021 Actual point expiry date August 31, 2021 (31 days from current date) Extended point expiry date September 09, 2021 (Points expiring after 10 days from actual point expiry date)

Use case 3 - Update expiry for a list of customers Consider customer 3, 4, and 5 have 100 points each that are going to expire on September 30, 2021 but the store will be closed permanently after August 31, 2021 due to business failure. In this case, you can update customer 3, 4, and 5 with an early points expiry date - August 31, 2021(fixed).

Facts Date & duration Current date August 01, 2021 Actual point expiry date September 30, 2021 Early point expiry date August 31, 2021 (Points expiring before actual point expiry date)

The following are fields of the csv file.

Customer identifier (User ID/External ID/Email/Mobile/Card Number)*

Point Awarded Ref Type*

Point Awarded Ref ID*

Expiry Type*

Expiry Unit*

Expiry Value*

Expiry Update Reason Type*

Expiry Update Reason Note

CSV Sample using User ID:

User Id,Point Awarded Ref Type,Point Awarded Ref Id,Expiry Type,Expiry Unit,New Expiry Value,Expiry Update Reason Type,Expiry Update Reason Note

235233,POINTS_AWARDED,134435,relative,months,12,Extend_Expiry,Covid



Template configuration



Option Description Choose customer's unique identifier Choose the unique customer identifier used in the CSV to identify customers. USER_ID MOBILE EMAIL EXTERNAL_ID * CARD_NUMBER Choose Program Name Select the loyalty program for which you want to update the point expiry date of a customer. Select Expiry Update Reason Type Choose your preferred type for points update. Early expiry : Select this option to expire points before the actual expiry date. For example, If the actual point expiry date is August 30, 2021, then the early expiry date must be before August 30, 2021. Extended expiry : Select this option to extend the expiry date from the actual expiry date. For example, If the actual point expiry date is August 30, 2021, then the extended expiry date must be after August 30, 2021. Select Expiry Update Reason Note Enter the reason for updating the point expiry date/days/months. Expire promised points Select this to expire promised points.

Update Points Expiry (using Promotion ID)

This profile lets you update the points expiry of a customer based on Loyalty Promotion ID.

It is very important to understand how the issued and expired points will be affected by this import.

Example:

Consider that 100 promotional points wrongly awarded to 10 customers of an org. Now the org want to remove the promotional points from all 10 customers. In such case, you can select the promotion and use the customer identifier(User ID/External ID/Email/Mobile/Card Number) to change the expiry type(early expiry) and date(immediately).

Facts Date & duration Early point expiry date Immediate expiry (on the date of data import)

Customer identifier (User ID/External ID/Email/Mobile/Card Number)*

CSV Sample using User ID:

User Id

1250755



Template configuration



Option Description Choose customer's unique identifier Choose the unique customer identifier used in the CSV to identify customers. USER_ID MOBILE EMAIL EXTERNAL_ID * CARD_NUMBER Program Name Select the loyalty program for which you want to update the point expiry date of a customer. Select Promotion Select the promotion for which you want to update the point expiry date of a customer. Select Expiry Update Reason Type Choose your preferred type for points update. Early expiry : Select this option to expire points before the actual expiry date. For example, If the actual point expiry date is August 30, 2021, then the early expiry date must be before August 30, 2021. Extended expiry : Select this option to extend the expiry date from the actual expiry date. For example, If the actual point expiry date is August 30, 2021, then the extended expiry date must be after August 30, 2021. Select Expiry Update Reason Note Enter the reason for updating the point expiry date. Set expiry date to Choose the expiry date from the following options. Fixed date expiry : Set a date on which you want to expire the points. Fixed date expiry must be greater than the current date. For example, If the current date is August 29, 2021, then the fixed date expiry must start from August 30, 2021 Relative date expiry : Set the number of days or months after which the points will expire. For example, If the current date is July 29, 2021(today) and you set the expiry count to 5 days then the point expiry date will be August 02, 2021. * Immediate expiry : Select this option if you want the points to be expired immediately(the moment system has successfully updated the point expiry using data import. Expire promised points Select this to expire promised points.

Updated over 1 year ago