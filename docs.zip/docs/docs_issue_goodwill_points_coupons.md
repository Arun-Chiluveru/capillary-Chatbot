# Scraped content from: https://docs.capillarytech.com/docs/issue-goodwill-points_coupons

Transaction line item merge template

This page provides you with information on transaction line item merge template.

Suggest Edits

This template enables comparison and merging of transaction data from both the line item file and the bill-level file, then adds the merged data to the platform.

During merging, the template also performs additional calculations, such as determining the bill amount using expressions, and includes the calculated values in the merged file.

Use case

Scenario:

A retail company receives data in two separate Excel files. One file contains bill-level information, including total amounts, dates, and customer details. The other file contains line-level data, such as individual items, quantities, and prices. The retail company wants to create a consolidated dataset that combines bill-level and line-level data. They want to know which items were purchased in each bill and calculate the total cost of each item in every bill.

Solution:

They can use Transaction line item merge template and choose the "Inner Join" option to include only the records that have matching BillNumbers in both data sources.

Configuring transaction line item merge dataflow

To configure transaction line item merge dataflow, perform the below steps/actions:

In the Connect-to-source Block, enter the source server details where the source data is present and the location for saving the processed file. See Connect to source.

In the Decrypt data block, if the files are encrypted, enter the details to decrypt the data. See Decrypt data.

In the Join-Data block, enter the required details and define the conditions to merge the two files and join the data. See Join Data.

In the Transform Data block, map the API fields with the source file. For information on how to map the fields, see Transform data.

In the Connect-to-destination block, Enter the API endpoint details. See Connect to destination. For this template, the API /v2/transactions/bulk is used.

In the Trigger block, enter the details to schedule the trigger. See Trigger.

FAQ

Q: Is it mandatory to enable Merge based on common Name checkbox? A: Yes, It is mandatory to Merge based on common Name checkbox to make sure the correct files are merged together.

Q: How to view the transaction details in Memebercare against the customer? A: You can view the customer details in Membercare by clicking on Transactions under the Events tab.

Q: Is it mandatory to enable the Alphabetical sort checkbox? A: Yes, it is highly recommended to enable the Alphabetical sort checkbox to ensure accurate sorting of the files in alphanumerical order.

Updated over 1 year ago