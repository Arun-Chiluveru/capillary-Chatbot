# Scraped content from: https://docs.capillarytech.com/docs/create-journeys

Create journey

Suggest Edits

To create a Journey -

Log on to InTouch of your cluster and navigate to Engage+ from the menu.

Click on Journeys . You will see the Journeys homepage.

1088

Click on Create new.

In the Journey name text box, enter a name for your journey.

1351

You can choose to create a journey from scratch or choose one of the existing templates to configure your journey. The existing templates are just samples which are editable Please note that as of now, only three templates are functional - Welcome Journey, NPS, Churn Prevention

Welcome Journey- This template is to engage with newly registered customers to encourage them to make a transaction.

Churn Prevention- This template is to engage customers who haven't transacted with the brand for a while. The goal is to reactivate the customers.

NPS- Engaging customers based on the NPS score. Higher the NPS score, higher is the satisfaction level of customers. This is a pre-configured journey template with 5 states- Very good, Good, Average, Poor and remainder users.

If you choose to Build from Scratch, here's how you should Configure the journey.

Updated over 1 year ago