# Scraped content from: https://docs.capillarytech.com/docs/promotion-earning-expiry-communications

Cart Promotion Earning & Expiry Communications

Suggest Edits

📘

Applicable only for Loyalty earning promotion and Reward Promotion.

You can notify customers about when they earn new points or when their existing points get expired.

On earning

To configure the notification message on earning points, do the following.

Navigate to the communication section.

Click Add creative On earning.

542

Select any of the following channels of communication.

SMS

Email

Push notification

Select an existing template; or click Create New to create a new template and configure the notification message.

📘

To learn about creating a new template, see SMS, Email, Push Notification.

Click Done.

Set expiry reminder

To notify customers before their promotion points expire, configure an expiry reminder as explained in the following.

In Set expiry reminder, Click Add creative Expiry reminder.

539

Select any of the following channels of communication.

SMS

Email

Push notification

Select an existing template or click Create New to create a new template and configure the notification message.

📘

To learn about creating a new template, see SMS, Email, Push Notification.

Click Done.

Delivery settings

The delivery setting allows you to set the sender ID, enable POC, and use a tiny URL. For more details, see Delivery settings.

Updated 10 days ago