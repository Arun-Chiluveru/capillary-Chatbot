# Scraped content from: https://docs.capillarytech.com/docs/target-loyalty-1

Points Promotion

Suggest Edits

Users can now add custom fields for their promotions from the Product UI itself. The Points promotion section allows to add custom fields, which can then be used in Loyalty promotions.

The ability to add custom field to a promotion will help brands to tag custom meta data with the promotions, it could a terms & conditions, url or any other meta data that can be retrieved with the promotion

The custom fields can be created of the types, String, Number, Boolean.

The user can create/edit/delete a custom field and add the meta data.



Updated 2 months ago