# Scraped content from: https://docs.capillarytech.com/docs/manage-coupons

Coupon Management

Suggest Edits

Create Coupons

Coupons can only be created under an offer. To create a coupon,

Select the Incentive tab, and then click Create OfferRefer to the Create Offer flow.

Click Coupon details under Create an Offer.

To set how to distribute and manage coupon codes for an offer, follow these steps,

In "How would you issue these coupons to customers," choose a coupon delivery method, select "Through Capillary" for the coupon to be sent to customers from Capillary, or select "Through a Third Party" if you prefer the coupon to be sent through an external service. Note: For third-party coupon issuance, you cannot control the issue & reminder settings also restrict who can redeem the coupon.

In How to create the coupon codes you can Select coupon generation method from the following.

Automatically create unique codes: A unique offer code will be auto-generated based on the configuration. Click Edit to change the configuration (number of digits and/ or the alphanumeric characters). You can also select the unique audience for the added coupon code. Enable Issue to specific customers only and Click View/ Add, to view or upload the specific customers' list to restrict the coupons to the list of customers you want to for Select a CSV file, and then click Proceed to upload.

In Generate common code(s): select Give a common code to all coupons Enter a code, that is common, for the entire audience. You can also select the unique audience for the added coupon code. Use the toggle button to enable the Issue to specific customers-only button. Click View/ Add, to view or upload the specific customers' list. Select a CSV file, and then click Proceed to upload.

Upload existing coupon codes: Upload the existing coupon codes. To upload the coupon code, click View/ Add, select an upload option, browse a CSV file, and then click Proceed to upload. You can use this option to upload existing coupon codes, tag them to a customer and view them on Member Care. This is useful when migrating customers who already have coupon codes from a third party. Note: You can upload only coupons or coupons with customer details.

In "When would a coupon expire," you can set the expiry date.

Select "Along with the offer" for the coupon to expire when the campaign ends. This is applicable only if the Offer expires on a Fixed date.

Select "Days from issual" for the coupon to expire after a certain number of days from the issue date or the campaign end date, whichever comes first.

For example, If a coupon is issued on 12th November 0 days from issual Expires on 12th Nov EOD and 1 day from issual Expires on 13th Nov EOD .

You can also choose "Month ends from issual" for the coupon to expire after a specified number of months from the issue date or the campaign end date which is earlier.

For example, if a coupon is issued on 12th November then 0 months from issual Expires on 30th Nov and 1 month from issual Expires on 31st Dec.



📘

You can create an offer that includes various options for generating coupons and redeeming those coupons.

Issue Multiple Coupon Codes to a Customer

When you issue coupons to customers, you can also add multiple coupon codes for each customer from a single offer or coupon series in one file. This works for coupons issued through Capillary, using any of these methods:

Automatically create unique codes

Give a common code to all coupons

Upload existing coupon codes

You can add customers when you create an offer or by navigating to Engage+ > Incentive > More Options under the offer name > Upload customers.

Below is the screenshot of a sample file to upload multiple coupons for a customer



Error scenarios when issuing multiple coupons to a customer

You may encounter errors when issuing multiple coupon codes to a customer in the following cases:

Invalid customer identifier, such as email ID, mobile number, external ID, or user ID. Below are the screenshots of the error messages for different invalid customer identifiers when uploading existing coupon codes.

Exceed the maximum coupon issuance limit per customer Example scenario: Consider the following:

Series type: DiscCode

Maximum issual limit per customer: 3

Minimum gap between two issual: No gap

Maximum issual limit for series: No limit

Perform the following steps:

Upload a file containing four entries for the same UserID.

Re-upload the same file without any changes.

Upload the same file again, but include only one entry for the UserID.



An error message indicating exceeding the maximum coupon limit per customer

Issue a coupon before meeting the minimum gap requirement Example scenario: Consider the following:

Series type: DiscCode

Maximum issual limit per customer: 3

Minimum gap between two issuals: 1 day

Maximum issual limit for series: No limit

Perform the following:

Upload a file containing four entries for the same UserID.

Exceed the maximum issuance limit for the series

Example scenario: Consider the following:

Series Type : DiscCode

Maximum issual limit per customer: No limit

Minimum gap between two issual: No gap

Maximum issual limit for series: 2

Perform the following:

Upload a file containing four entries for the same UserID.

Issue more than one generic coupon to a customer Example scenario: Consider the following:

Series Type : Generic

Maximum issual limit per customer: Not Applicable

Minimum gap between two issual: Not Applicable

Maximum issual limit for series: Not Applicable

Perform the following steps:

Upload a file containing four entries for the same UserID.

Upload the same file again.

Checking the status of coupon upload

After uploading the CSV file to issue coupons, you can check the upload status by going to Engage+ > Incentive > More Options under the offer name > Upload customers.



In case of failures, click on Download Issues to view the error details from the Upload customer screen.



Configuring the Issual & Reminder Details

You can manage how coupons are issued and tracked and also restrict customers based on past issuals, max issuals per customer etc...To set this up, follow these steps:

Enable “Restrict based on past coupon issuals” so that you can prevent customers from receiving coupons they've already used in the past 6 months and Select the offer from the past 6 months from the drop-down. The selected coupons will not be sent to the customers who have received these coupons in the past 6 months.



Enable “maximum issuals per customer” to set the maximum number of coupons to be issued to each customer and the minimum gap (number of days) between two consecutive coupon issues and Enter the maximum number of coupons a customer can receive. If you do not want to set a limit, choose “No Limit."

Select If a customer matches the criteria again.

Select Send existing valid coupon to send the same coupon again.

Select Do not send any coupon to ignore sending any coupon.



Enable “limit total issuals from the offer?” and enter the number of limits that you can restrict the maximum coupon to be issued in an offer and configure notifications and then Enable “send notification for issual limit” and enter the number of remaining coupons that should trigger the notification.

You can notify brand POCs when the coupon issual limit is about to reach a certain threshold value. The notification is sent to the brand POCs through email.



Enable “sms content for resending the coupon” to resend coupons via SMS if a customer missed them. Use predefined Tags wherever necessary. If the message has Unicode characters, check Allow Unicode characters.

Example: If a customer missed a coupon and requested an executive to resend it. The executive can resend the coupon if this option is enabled.

Enable “Send expiry reminders” to create multiple coupon expiry reminders and send them to customers through SMS/Email. Then Set the number of days before which message is to be sent, the message channel and the specific time. Similarly, you can add multiple reminders using the +Reminder option.



Configuring the Redemption settings

To configure various redemption limits and rules for how and when coupons can be redeemed, perform the following :

Enable Coupon can be shared and redeemed by anyone to allow redemption of a coupon by anyone, for example friends and family. You can limit the number of times the coupon is redeemed. This additionally also gives access to set limits on Coupon code limit.



Configure the coupon code limits under Coupon code limit, Individual customer limit and Across customer limit.

Coupon code limit - The 'coupon code limit' feature allows brands to set a maximum number of times a specific coupon code can be redeemed across all customers. This ensures that once the set limit is reached, the code can no longer be used, regardless of how many different customers attempt to redeem it. USECASE: A brand runs a promotion using the coupon code "SUMMER50", offering a 50% discount. Without a coupon code limit, an unlimited number of customers could redeem the code, potentially leading to higher-than-expected discounts. By setting a coupon code limit of 1,000 redemptions, the brand ensures that only the first 1,000 customers can use the code. Once the limit is reached, the code becomes invalid, preventing excessive discount usage.

Individual customer limit - The 'Individual customer limit' feature allows brands to set the maximum number of times a single customer can redeem a specific coupon code. Once a customer reaches their redemption limit, they cannot use the code again, even if the coupon is still available for other customers. USECASE 1: A brand offers a "WELCOME10" coupon that gives a 10% discount on purchases. To prevent misuse, they set the Individual customer limit to 1. This ensures that each customer can only use the coupon once, even though the code may still be available for others. This helps the brand maintain the promotion’s intended purpose—rewarding new customers without allowing repeated use by the same person. USECASE 2: In the case of the Step Function, the limit should be set to no limit because the number of coupons issued depends on the transaction amount and cannot be predetermined. However, the redemption limit can be set depending on how many times a particular issued coupon can be redeemed. To know more about Step Function, click here.

Across customer limit - The 'Across customer limit' feature controls the total number of redemptions allowed across all coupon codes within a specific series. This ensures that once the predefined limit is reached, no additional redemptions can occur, even if individual codes or customers still have remaining redemption allowances. This is particularly useful for large-scale promotions where multiple codes are distributed but the brand wants to cap the overall number of discounts given out. It provides a way to manage total redemptions across a campaign while still allowing flexibility at the individual coupon and customer levels. USECASE: A brand launches a holiday sale where they distribute 5,000 unique coupon codes, each offering a discount. To control the total discount given, they set a Series-Level Limit of 50,000 redemptions. This means that even though each individual code may have its own redemption limit, once the total redemptions across all codes in the series reach 50,000, no further redemptions will be allowed. This helps the brand manage the overall budget for the promotion while still allowing multiple customers to redeem different codes.



The redemption limit settings are as follows:

Field Description Limit to Set the maximum number of times a coupon code can be redeemed to a certain number. No limit Allows unlimited redemptions for a coupon code

S. No Coupon Series Type Allow anyone to redeem it? Code-Level Limit Customer-Level Limit Series-Level Limit Example 1 Automatically Generated Yes Yes Yes No A new year sale where a generated code "NY2024" can be redeemed 10 times in total, but can be redeemed only once per customer. Code level limit: 10, Customer level limit: 1 2 Automatically Generated Yes Yes No Yes An offer where total redemption from the offer will be 10k but a code can be redeemed only 5 times irrespective of number of customers who redeem it. Code level limit: 5, Series level limit: 10k 3 Automatically Generated Yes Yes Yes Yes An offer where total redemption from the offer will be 10k, a code can be redeemed 5 times but can be redeemed only once per customer. Customer level limit: 1, Code level limit: 5, Series level limit: 10k 4 Automatically Generated Yes Yes No No An offer where a code can be redeemed 5 times. Code level limit: 5 5 Automatically Generated Yes No Yes Yes An offer where total redemption from the offer will be 10k but can be redeemed only once per customer. Customer level limit: 1, Series level limit: 10k 6 Automatically Generated No No Yes Yes An offer where total redemption from the offer will be 5k but a code can be redeemed only once or a customer can redeem it only once. Customer level limit: 1, Series level limit: 5k. Code level config won't be needed as the code and customer level limits are equal when the config “allow anyone to redeem it” is false 7 Common Coupon Codes Yes No Yes Yes A holiday campaign with a single code "HOLIDAY20" can be redeemed by every customer twice, but the overall series redemption restricts to 1000 only. Customer level limit: 2, Series level limit: 1000 8 Capillary-Uploaded Yes Yes Yes Yes Partnering with a popular blog, a brand released up to 5k codes with a total limit of 50k redemptions, each customer can use the code only once, and code level limit goes up to 5 redemptions. Series level limit: 50k, Customer level limit: 1, Code level limit: 5 9 Capillary-Uploaded Yes Yes Yes No Partnering with a popular blog, a brand released up to 5k codes, each customer can use the code only once, and code level limit goes up to 5 redemptions. Customer level limit: 1, Code level limit: 5 10 Capillary-Uploaded Yes Yes No Yes Partnering with a popular blog, a brand released up to 5k codes, and code level limit goes up to 5 redemptions irrespective of the number of customers who redeem it and total redemptions 25k. Series level limit: 25k, Code level limit: 5 11 Capillary-Uploaded Yes Yes No No Partnering with a popular blog, a brand released up to 5k codes, and code level limit goes up to 5 redemptions irrespective of the number of customers who redeem it. Code level limit: 5 12 Capillary-Uploaded Yes No Yes Yes Partnering with a popular blog, a brand released up to 5k codes, and customer level limit goes up to 5 redemptions and total redemption can be 5000 only. Customer level limit: 5, Series level limit: 5000 13 Capillary-Uploaded No No Yes Yes An offer where total redemption from the offer will be 5k but a code can be redeemed only once or a customer can redeem it only once. Customer level limit: 1, Series level limit: 5k. Code level config won't be needed as the code and customer level limits are equal when the config “allow anyone to redeem it” is false 14 Third-Party Uploaded No No Yes Yes Here, code level redemption restrictions are equal to customer level redemption restrictions as today in this series type, system doesn’t allow “allow anyone to redeem it” as true







In Redemption can start You can set when a coupon becomes available for redemption by setting the start time.



Enable “Allow a coupon to be redeemed more than once” to allow a customer to redeem the coupon more than once then Enable “Limit the maximum times a customer can redeem a coupon” to set the maximum number of times the coupon can be redeemed by a customer. In Limit to, enter the maximum number of times the coupon can be redeemed by a customer.



In “Stores allowing redemption” You can restrict an offer to be redeemed at specific stores by selecting the stores or uploading a list of stores. Select tills/stores/concepts/ zones From the “Restrict stores allowing redemptions“section. By default, an offer is available for redemption at any store.

Choose Upload CSV file to upload a file containing the IDs of your preferred zones/stores/concepts.

Choose Select Values to select your preferred zones/stores/concepts from the list directly. Till -> fetches the series for the till IDs, Store -> fetches for that individual store, Zone -> fetches the series mapped to zone, Concept -> fetches for the series mapped to concept.



In Bill Amount that can redeem the coupon You can restrict the minimum and maximum bill amount criteria for offer eligibility that Enable “Minimum bill amount” enter the minimum amount and Enable “Maximum bill amount” and enter the maximum amount. The coupon can be redeemed only if your bill amount is under the limitation.



In Days & time when the coupon can be redeemed You can set a specific day, date, and time slot for the coupon to be redeemed by selecting the following:

Days of the week - To allow redemption on selected days of the week- Sunday to Saturday.

Days of the month - To allow redemption on selected days of a month - 1st - 31st.

Hours of the day - To allow redemption in the preferred hours of the day.



In Require gap between the redemption of a customer You can set a minimum gap (number of days) between two consecutive redemptions. For that Enable “Require gap between redemptions of a customer” and Enter minimum days between redemption. Note: This option is not applicable if the coupon is restricted to redeemed only once.

In Limit total redemption in the offer You can limit the maximum number of coupon redemption in an offer and set the maximum allowed coupon redemption number. Enable “Limit total redemptions in the offer” and Enter the number of maximum allowed customers.

In Restrict to new customer you can restrict coupon redemptions to new or first-time customers based on their registration date or a number of transactions Click “Restrict to new customer”, Enable “Date of registration” and enter the start and end date then Enable “Number of transactions” and enter the value.



Revoke Coupon

When a cashier redeems a coupon in case of an internet outage, you can expire such coupons instead of doing a manual cleanup at the backend. To expire active coupons, follow these steps:

Navigate to Engage+ and Select Incentives.

Click the three dots next to the offer you want to revoke.

Click Revoke Coupons.



Select your desired revoking option.

All unredeemed coupons (Issued and unissued): To expire all coupons that are either not redeemed or issued.

Only unissued coupons: To expire only coupons that are not issued.

For specific customers: To expire all active coupons of particular customers. Create a CSV file with identifiers of customers whose coupons you want to expire, and upload the file using Upload Customer.



Check I understand that revoking coupons will make them unredeemable. Expired coupons cannot be redeemed or reversed.

Click Revoke.

A message is shown that the customer data is successfully uploaded. All the coupons issued to the selected customer are revoked and ready for use.

Notes: You cannot revoke redeemed coupons. If a customer has multiple active coupons from the same series, then all active coupons are revoked.

Transfer of Coupon

You can revoke the coupon and then assign the same coupon code to the intended customer through coupon upload, as transferring a coupon from one customer to another customer is not supported.

Personalization of coupon at scale

Personalization of coupon at scale (audience of 20M+) : This is a limited release and is enabled as an add-on. This is not a part of any standard package. Please reach out to your CSM to enable the personalization of the coupon feature.

To create this follow the steps:

Navigate to the Engage + module and click on Incentives.

Click on* Create Offer*.



Enter the basic details of the coupon series like offer name, offer expiry, discount value for each coupon(fixed/percentage), products applicable etc.

While selecting how to generate coupon codes for the series :

Select Through capillary.

Click on Generate common codes(s) -> Generate randomized common code(s).



Enter the sample common code, it could be numeric or alphanumeric.



Here, in this case, TEST12345 is just a sample code to generate the randomized codes from this reference.

The system will take the length of the sample code provided and if it is numeric or alphanumeric and then generate the random codes based on this input.

The resulting codes will be of the same length and will have 50% of the code as fixed for all the codes, i.e. in this case, let’s say TEST will be fixed and the remaining 5 digits will be randomly generated.

The fixed part will be unique in the backend for an org. Note: Min 5 characters should be there in the sample code and Max. of 10 characters is supported.



Once the offer is created, the sample code provided at the time of creation can’t be changed and in the UI, in edit flow, it won’t be the same code which was provided at the time of offer creation.



This option is only available when offers are created from the incentives section but can be claimed in any module.

This type of series can only be created via UI and not via coupon APIs.

The feature of uploading customers won’t be available for this type of coupon series.

This option is not available for offers created via campaign flow or loyalty flow.

Time to issue 30M coupons via campaigns flows 3 hours.

With this feature, we can issue a maximum of 60 million unique coupons when 10-digit alphanumeric characters are used to create a coupon series. Note: The system allows for coupons to have multiple currencies and it is important to note that the coupon value will be converted to the store default currency at the time of transaction.

Track the reversal status of a coupon

This feature allows brands to easily indicate which coupons have been reversed and reinstated in the mobile app's user interface.

This will help customers to easily identify the coupon that was reversed, thus reducing confusion and the number of queries made to support.

Additionally, this feature will also improve the customer's experience by providing them with transparency and visibility into the status of their coupons.

Brands can also use this feature to track and analyse the performance of their coupon campaigns and make data-driven decisions to optimise their rewards strategy.

Impacted APIs : Get Customer Coupons Get Coupon details

In both the API response, isReversed and last_status_change_on values would be returning from the coupon_redemptions table based on the active and last_status_change_on columns.

Coupon APIs

If you specify a zone in the API call, it will only return offers tagged to that zone, not to individual stores within it. For example, if a brand has stores A, B, and C in zone 1, using "zone 1" will only show offers for that zone, not for stores A, B, or C. To get offers for those specific stores, you need to include their store IDs in the API call.

The provided orgEntityIds won't be validated, meaning if an invalid ID is entered (not a proper store, zone, or concept ID), no error will be shown; instead, you simply won't receive any results for that ID.

You can only filter by one orgEntityType at a time in a single request.

Manage Store and Zone-Level Redemption Settings

This helps brands select & upload store names while creating a coupon series to restrict the coupon redemption to those stores. However, brands generally run scope restrictions based on store name.

To add store IDs for coupon series via Thrift,

SaveCouponConfigRequest:  
          CouponConfiguration:  
                      redemptionOrgEntityDetails:  
                                <orgEntityId
                                redemptionOrgEntityType>,  
                                <orgEntityId
                                redemptionOrgEntityType>,

API based implementation details,

redemptionOrgEntityDetails is a list of redemptionOrgEntityType and orgEntityId.

Add redemptionOrgEntityType as STORE, ZONE or CONCEPT.

Add orgEntityId as a store, zone or concept id.

This is to be added in thrift SaveCouponConfigRequest to make a thrift call for saveCouponConfiguration.

To filter store IDs for coupon series via Thrift:

Add orgEntityType as STORE, ZONE or CONCEPT.

Add orgEntityIds with a list of store, zone or concept IDs.

This is to be added in thrift GetAllCouponConfigsRequest to make a thrift call for getAllCouponConfigurations.

📘

Note:

Refer coupon v1.1 APIs to issue coupon,Resend coupon,Redeem coupon etc..

Refer Coupon v2 APIs to create coupon series, update coupon series etc...

Refer Coupon Upload v1 APIs to upload coupon, upload redeem coupon etc...

Updated 8 days ago