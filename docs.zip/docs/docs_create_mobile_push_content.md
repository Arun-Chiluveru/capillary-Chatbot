# Scraped content from: https://docs.capillarytech.com/docs/create-mobile-push-content

Create mobile push content

Suggest Edits

To create mobile push content, follow these steps.

In the Content section, click Add creative.

Navigate to the Push Notification tab.

Select your preferred Push Notification account.

Click Create new.

Select a content type from the following options:

Image Content

Text Content

901

Image Content

Click Image Content, and then click Continue.

Select a mobile device type: Android or iOS. You can copy the same content for another device type by selecting Copy Title and Content From Android/ iOS.

Enter a Mobile Push Notification Title. Click +Add Label to use appropriate tags in the notification title.

Enter a Mobile Push Notification Message. Click +Add Label to use appropriate tags in your message. You can also use Liquid language in the messages.

To add an image to the notification, click Upload image. Browse an image, and click open.

Select Add action link to content, if you want to include a navigation link to the content. Select Deep-link or External link. Deep-link redirects the content navigation to a page within the mobile app. An external link redirects the content navigation to an external web page.

Select Add primary button to notification, if you want to add a primary button in the notification message. Enter a button label. Select Deep-link or External link. Deep-link redirects the button action to a page within the mobile app. An external link redirects the button action to an external web page.

Click Add secondary button to notification if you want to add a secondary button in the notification message. This option is only enabled if the primary button is added to the notification. Select Deep-link or External link. Deep-link redirects the button action to a page within the mobile app. An external link redirects the button action to an external web page.

889

Text Content

Click Text Content, and then click Continue.

Select a mobile device type: Android or iOS. You can copy the same content for another device type by selecting Copy Title and Content From Android/ iOS.

Enter a Mobile Push Notification Title. Click +Add Label to use appropriate tags in your message.

Enter a Mobile Push Notification Message. Click +Add Label to use appropriate tags in the notification title. You can also use Liquid language in the messages. You can use Liquid language to send personalised messages, messages based on conditions, product recommendations based on last purchase, etc. For more information, refer to the detailed documentation on Liquid language.

Select Add action link to content, if you want to include a navigation link to the content. Select Deep-link or External link. Deep-link redirects the content navigation to a page within the mobile app. An external link redirects the content navigation to an external web page.

Select Add primary button to notification if you want to add a primary button in the notification message. Enter a button label. Select Deep-link or External link. Deep-link redirects the button action to a page within the mobile app. An external link redirects the button action to an external web page.

Click Add secondary button to notification if you want to add a secondary button in the notification message. This option is only enabled if the primary button is added in the notification. Select Deep-link or External link. Deep-link redirects the button action to a page within the mobile app. An external link redirects the button action to an external web page.

893

📘

Preview: Use to view the email content and design in advance before saving the message.

TEST MESSAGE: You can send a text message to a test group to review the content and design before sending it to the actual audience. You can send it to your preferred email IDs or to a test user group.

Updated 6 months ago