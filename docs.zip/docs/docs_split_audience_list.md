# Scraped content from: https://docs.capillarytech.com/docs/split-audience-list

Split Audience List

Suggest Edits

Audience split allows you to divide your audience into smaller groups randomly, with a maximum of four groups.

Steps to Split an Audience List

Click on the audience list you want to split.



Click on the horizontal ellipses (three dots).

Select the Split Audience option.

Set the Split Criteria: On the split audience screen, you can:

Choose the number of splits (up to 4).

📘

Note

The maximum audience split count is set to 4 by default. It can be based on your requirements. To request this configuration, kindly raise a Jira ticket to the Tech team.

ii. the percentage for each split.



📘

Notes

The total percentage across all splits must equal 100%.

There will be no changes to the original list from which you have created split audience.

The splitted audience group cannot be combined back. You will also not get option to combine these lists when selecting the audience while configuring the campaign.

Use the pencil icon on the right-hand pane to rename each audience group.



Click Done, and the new audience lists are created automatically.

Updated 17 days ago