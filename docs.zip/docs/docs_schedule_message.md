# Scraped content from: https://docs.capillarytech.com/docs/schedule-message

Schedule message

Suggest Edits

Learning Objectives

After reading this article you would be able to:

Set a Message Delivery Schedule

Introduction

Message delivery scheduling provides the user with flexibility and helps plan ahead on their goals.

👍

You can schedule a message only within the campaign period.

Messages will not deliver between 9:00 pm to 9:00 am. Any message scheduled within this period will be sent post 9:00 am.

Problem Statement

Set a message delivery schedule. The message will be delivered based on the selected schedule.

Solution

There are 3 ways in which a message can be scheduled:

Immediately after approval

On a specific date

Repeats Periodically

1090

Immediately After Approval The message will be immediately delivered after its approval.

993

👍

Currently, for campaigns that are set to run Immediately on Approval or Scheduled on a future date, the current state of the lists is used. However, if the user can manually refresh the list in Audience Manager before using the message.

On a specific date The message will be delivered only on the selected date and time.

Select a specific date and time, and then click Done.

671

👍

Currently, for campaigns that are set to run Immediately on Approval or Scheduled on a future date, the current state of the lists is used. However, if the user can manually refresh the list in Audience Manager before using the message.

Repeats periodically The message will be delivered on a repeated frequency within the campaign duration.

Select a repeat frequency from the available options, and then click Done

822

👍

Currently, for the recurring campaigns, the audience list (filter-based) attached will be refreshed at the time of campaign execution

Every day: Select a message delivery time. The message will be delivered every day at the same time within the campaign duration. You can also set the repeat frequency calendar timeline. Select a start date and an end date for it.

803

Every week: Select a day of the week and time for message delivery. The message will be delivered on a particular day of the weekday and at a particular time within the campaign duration. You can also set the repeat frequency calendar timeline. Select a start date and an end date for it.

783

Every month: Select a date and time for message delivery. The message will be delivered on a particular date of the month and at a particular time within the campaign duration. You can also set the repeat frequency calendar timeline. Select a start date and an end date for it.

799

Custom: Select a date and time for message delivery. The message will be delivered on a specific date of the month and at a particular time within the campaign duration. You can also set the repeat frequency calendar timeline. Select a start date and an end date for it.

543

Explore

Create a message

Updated over 1 year ago