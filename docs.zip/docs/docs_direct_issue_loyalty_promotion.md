# Scraped content from: https://docs.capillarytech.com/docs/direct-issue-loyalty-promotion

Sample Rewards Catalog for Various Verticals

Suggest Edits

Fuel Vertical

Customers have the option to redeem rewards not just for fuel discounts or free coffee, but can redeem from brand’s partner (Movie Ticket, Travel Vouchers, Ride Hailing, etc.)







Beauty and Fashion Vertical

A brand is a group of 18 sub brands, and its loyalty program is a group level program. So they provide free vouchers of different internal brands through Rewards catalog so that customer can see the coupon code in the account while redeeming at any brand's store.



Healthcare Vertical









CPG Vertical







Updated 8 months ago