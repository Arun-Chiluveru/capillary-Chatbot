# Scraped content from: https://docs.capillarytech.com/docs/attributes-custom-field

Loyalty+ Promotions

Suggest Edits

Getting started

Types of promotions

Available to Issue loyalty promotion

Direct issue loyalty promotion

Enrol & Issue loyalty promotion

Updated 10 months ago