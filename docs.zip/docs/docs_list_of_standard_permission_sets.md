# Scraped content from: https://docs.capillarytech.com/docs/list-of-standard-permission-sets

Core Concepts

Suggest Edits

Dataflow & Building Blocks

Tags & Filters in DataflowTags & Filters in Dataflow

Block Libraries

Updated 7 days ago