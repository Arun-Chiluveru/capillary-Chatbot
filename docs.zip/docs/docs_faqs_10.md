# Scraped content from: https://docs.capillarytech.com/docs/faqs-10

Manage customer feedback

Suggest Edits

Introduction

Capillary's Feedback Management(CFM) system helps their clients in managing customer feedback. CFM is a process that is based on the systematic collection of customer feedback data, the analysis of the data, and defined dissemination and follow-up actions. With the CFM in place, it becomes easier for the business owners with insight that further can be used to improve their business, products, and/or overall customer experience.

To access Feedback Management System, log in to InTouch and navigate to the Workbench page. Click on Feedback Management in the left panel. You can see the following options:-

Add Ticket

Search Ticket

Upload Ticket

Reports

CCMS reports

1347

Add Ticket

To add a ticket, click on Feedback Management (InTouch Workbench page). Click the Add Ticket option, the following page appears

1372

Clients can add a new ticket for their customer feedback. This ticket can be used for future references and also can be used by customers in checking the status of their raised ticket. Few fields are mandatory that need to be filled and the remaining are custom fields, for example, feedback_anniversary, the purpose of visit, etc. Once all fields are filled, click on Submit.

Find below the description of the mandatory fields:

Mandatory Field Name Description Status Select from the drop-down the required options (OPEN, PARTIAL, CLOSE) Department Select from the drop-down the department (APPARELS, BOOKS, HOME-NEEDS) Priority Select either low, medium, or high priority from the drop-down. Subject The issue of the complaint is the subject for example Wrong Size, Fade Colour, etc. Details Write a description giving specific of the complaint raised. Mobile Number Enter the customer's registered mobile number. Customer Name Enter the name of the customer. Email Id Enter registered email id. Assigned To Assign it to respective department heads or person concerned. Due Date Provide a due date for the complaint to be resolved.

Search Ticket

To SearchTicket, click on Feedback Management (InTouch Workbench). Click the Search Ticket option, the following page appears:

1345

The fields are shown above in the screenshot need to be filled(Status, Priority, Department, Due Date till-from, Created Date, etc.) to search for a particular ticket of a customer. Search can further be done by selecting the custom field option. You can also view and edit the ticket using the Search Issue Download option. See the figures below for better clarity.

1368

1368

The tickets can further be edited. Click on the ticket and you will be navigated to the following page:

512

Upload Ticket

Tickets can be uploaded either using CSV or by adding customer attributes. To Upload a ticket using either of the options, go to Upload Ticket under Feedback Management, the following page appears:

1368

Reports

To access Reports, go to InTouch Workbench > Feedback Management.

Click the Reports option, the following page appears:

1368

On the Reports page, you need to do the following:

Enter the Last Updated Date Between _And

Enter the Created Date Between_And

Select from the drop-down whom to assign under Assigned to

Select Yes/No under Include Inactive

Check the box either for Download as CSV or Download Revision Log as CSV

Select Custom Fields On the Reports page, you can further see the Master Table as well as Revision Logs for a complete analysis of the tickets raised. See the following figures for better clarity:

1368

1368

CCMS Reports

To see Customer Complaint Management Reports(CCMS), click on Feedback Management which is located on the left panel of the Intouch Settings page. Click on the CCMS option, the following page appears:

1368

In CCMS reports, you can view the status, department, dates, etc. with regards to the ticket. It will also give an overview of the issue and its related details. Further, you can also get details about the overall escalation in the Overview Escalation. See the figure below:

1368

Updated over 1 year ago