# Scraped content from: https://docs.capillarytech.com/docs/profile-current-transactioncurrenttxn

RBAC (Role-based access control)

View Mode: Configurable Access Control

Suggest Edits

View Role in Loyalty Module

Overview The View Mode feature enables organizations to customize data access permissions based on user roles. It refines the user interaction by restricting the ability to modify or accidentally delete information. This feature is especially pertinent for managing loyalty programs.

Background Responding to a frequent enterprise-level request, View Mode addresses the need for granular control over different aspects of loyalty programs. Clients have expressed the importance of role-specific access settings, either Read or Write, for different team members.

Use-Cases Data Monitoring: Users who only need to review Loyalty Module configurations, promotions, and programs can have restricted access to prevent accidental changes. Role-Based Permissions: Users can be assigned specific access levels, allowing or disallowing the creation and modification of promotions, loyalty programs, tier strategies, points strategies, and tracker conditions.

Need for View Mode Unrestricted access to the Loyalty Module can result in unintended changes that have substantial implications, including potential negative effects on ROI and brand reputation. View Mode aims to mitigate these risks by providing different modes of access.

Modes

Read (View): This setting permits 'View Only' access, preventing unintentional configuration changes.

Write (Create/Edit): Users with this permission level can create and modify elements like Promotions, Loyalty Programs, Tier Strategies, Points Strategies, and Tracker Conditions.

Benefits

Risk Mitigation: The risk of accidental data alteration or deletion is significantly reduced.

Operational Efficiency: Team members can access only the data and features necessary for their roles, thereby ensuring a focused and efficient workflow.



View (Read Only) in Loyalty +

Program Level Changes:

Disabled the functionality of edit access for the members who have view-only Access.

Users can view Program configurations within the organization, user can check the tiers information, Rewards Currency, Trackers, workflow, etc.

Image: Edit Program Functionality is disabled.



In phase 1 we have enabled visibility of the below actions. We will add support for other actions later

Points allocation action

Issue coupon

Forward to set

Tracker Evaluation



Points Allocation Action: Within the point allocation actions, the edit/save options are completely disabled for a user with view-only access as shown in the image attached below.



Forward to set action: Once the settings are saved, a user can not play around with the toggle button to change the existing settings done.



Trackers: Within the Workflow, Users with view-only access can see which tracker is been configured but can’t change the tracker. To view which tracker has been configured in the action, the user has to click on the "eye" icon on the right side of the tracker action bar.



Promotions level changes:

Create promotions: The view mode in loyalty promotions disables the “Create Promotion” functionality and thus a user with view-only access can not “Create Promotion”.



Edit Promotions: Users can view the existing promotions and respective configuration but on clicking the three dots, the EDIT option is disabled.



Promotion Workflows: Within the Promotion workflows with a view access

The user can not change or add the set conditions.

The user can not change the workflow expression as well.



A user with view access cannot change actions or edit the actions, In the below image the functionality to enable or disable existing settings of the “forward to set” action can not be altered and thus a user with view access of promotions can not edit the existing configurations of the promotions.



Advance Settings of Promotions: With the view-only access, a user can not edit the advance settings as well. In the image attached below all the edit, save, and toggle buttons are disabled and thus can’t be changed.



Way to get View Only Access :

To enable the view-only access please write to the access team.

If you want to have edit/approve/delete access, make sure you are tagging your manager in the access request email before sending it to the access team.

Updated over 1 year ago