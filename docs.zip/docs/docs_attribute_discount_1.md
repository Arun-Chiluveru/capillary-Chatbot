# Scraped content from: https://docs.capillarytech.com/docs/attribute-discount-1

Custom Field Information for Badges

Suggest Edits

Overview

To create a flexible badges platform, it is important to give brands the ability to include additional, custom information when creating badges. This custom data can be used for various purposes such as displaying personalized information within the app or website, and for accounting or reporting purposes. Additionally, this custom data can also help brands to track and analyze the performance of their badges, and make data-driven decisions to improve their badges strategy. Furthermore, the ability to include custom data can also help brands to comply with legal and regulatory requirements, and to report on the performance of the badges to stakeholders.

Usecase

A retail brand aims to establish a badges platform to reward loyal customers and foster engagement through their mobile app. To personalize the badge experience, the brand intends to display custom information associated with each badge earned by users. To implement this the brand can perform the following:

Create a custom field named "Terms & Conditions" with the data type set as STRING.

Create a badge and assign this custom field "Terms & Conditions," ensuring to populate it with relevant information.

When a customer earns the badge, it will be showcased along with the "Terms & Conditions" field, providing users with pertinent details about the badge. Examples of custom field content may include terms and conditions, redemption instructions, brief descriptions, legal text, exclusivity status, purpose, etc.

Notes

Custom fields can be created, updated, or disabled.

There can be only one active custom field with the same name. If the existing custom field is disabled, then a new custom field with the same name can be created.

It is mandatory to define the default value for a custom field which is mandatory for the badge. In case a badge doesn't define a mandatory custom field with it, the default value will be considered.

Data types supported in custom fields: boolean, integer, string, and date.

Once the custom field is disabled, it can't be enabled again.

Only active custom fields will be returned in all the getcalls.

Only below fields can be updated while updating the custom field:

Name : can be updated

Isactive : can be updated from true to false but false to true is not allowed

Default value can be updated

Ismandatory can be updated from true to false or false to true

Data type can’t be updated

There is no limit on the number of custom fields that can be defined at an org level for badges.



Creating Custom Fields from Badges UI

Start by navigating to the badges UI and go to Settings.



Select the option to Create Custom field.



In the Name field, enter a name for the custom field and from the Data type drop-down, select the appropriate data type. The supported data types are Boolean, Date, Number and String. There is no limit set on the number of characters.









To set the custom field to mandatory, set it to Yes. When a custom field is set to mandatory, it is linked to the Badges and will be part of the creation process.



Click Done to finish creating the custom field.

The custom field is now successfully created.

Editing a custom field

Custom field can be edited by clicking on the Edit option.



Make the required changes.



📘

Notes

When a mandatory field is changed to optional, it will be unlinked from all badges that previously relied on it. This means the field will no longer be required for those badges, and any validation or functionality tied to it will be removed.

The data type cannot be changed in edit mode.

Verify the creation of a custom field

To verify the addition of the custom field, return to the badges UI and hover over New badges to see the option to Create a badge. Click on it.



Enter the necessary information to create a badge and click Next.

Select the owner of the badge.

Scroll down to see the mandatory custom fields under the Custom fields section. The custom fields that were created as non-mandatory are available as a selection.



Creating custom fields for badges using APIs

For more information on the APIs related to custom fields for badges, check the below links:

Create custom field

Update custom field

Get custom field by id

Get all custom fields

Add custom field while creating badges

Add custom field while updating badges

Get badge by id

Get all badges

Get customer badges

Updated 7 months ago