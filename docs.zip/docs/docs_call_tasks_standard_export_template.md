# Scraped content from: https://docs.capillarytech.com/docs/call-tasks-standard-export-template

BI Tool Connector

Suggest Edits

Bi Tool Connectors

What BI Tool connectors?

BI Tool connector is a solution that enables connectivity between the Data Analytics tool to a data source. Data Connectors enable you to connect your data sources to the Visulatisation tools securely without expensive re-engineering, testing, or retraining.

How can we access BI Tool Connector?

BI Tool connector can be used by creating a private cluster within databricks. You can contact your CSM or Sales team to get a databricks license. Please refer to the process below -

Read here

Updated over 1 year ago