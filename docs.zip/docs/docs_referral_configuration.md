# Scraped content from: https://docs.capillarytech.com/docs/referral-configuration

Referral Configuration

Suggest Edits

This page lets you configure referral codes.

To configure,

Navigate to Engage+ > Campaigns > Settings.

On the settings page, select Referral configuration.



On Define referral code, you can select one of the following options:

Random: The system will generate random referral codes.

Custom: You can customise the referral codes.

On selecting Random, perform the following options: a. In the Minimum code length field, you can enter the number that sets the minimum number of characters that you want for your referral code. b. Select Save.

On selecting Custom, perform the following options: a. On the Define character set section, you can select the following options:

Uppercase: This option will make the characters in your referral code uppercase.

Lowercase: This option will make the characters in your referral code lowercase.

Numbers: This option will add numbers to your referral code.



b. In the Minimum code length field, you can enter the number that sets the minimum number of characters that you want for your referral code.

c. On the Add prefix section, enable the button to add characters at the beginning of your referral code.

d. On enabling Add prefix, select one of the following options:



When you select Custom string, you can enter the desired characters that you want as a beginning for your referral code in the provided field.

When you select Profile attribute, You can choose First Name or Last Name of the referrer from the drop-down menu to use as the beginning of your referral code.



e. To configure the maximum length for your prefix, check the Maximum prefix length box and enter the desired length number in the provided field.

f. On Add suffix, enable the button to add characters at the end of your referral code.

g. On enabling Add suffix, select one of the following options:



When you select Custom string, you can enter the characters that you want as an ending for your referral code in the provided field.

When you select Profile attribute, you can choose First Name or Last Name from the drop-down menu to use as the ending for your referral code.

h. To configure the maximum length for your prefix, check the Maximum prefix length box and enter the desired length number in the provided field.

Select Save.

Use case

Consider that we are configuring a referral code with a length of 3 characters with the prefix "Hello" and suffix "code".

To configure,

Navigate to Engage+ > Campaigns > Settings.

On the settings page, select Referral configuration.

On the Define Referral code section, select Custom.

On the Define character set section, select Uppercase and Numbers.

In the Minimum code length field, enter ”3”.

On the Add prefix section, enable the button and perform the following: a. Select Custom string. b. In the Custom string field, enter “Hello”.

On the Add suffix section, enable the button and perform the following: a. Select Custom string. b. In the Custom string field, enter “code”.

Select Save.

You can see your configured referral code in the Sample code section.



Updated 10 months ago