# Scraped content from: https://docs.capillarytech.com/docs/csv-to-xml-converter

Goodwill points issue template

Suggest Edits

The goodwill points issue template allows you to issue goodwill points to the customer.

Configuring goodwill points issue dataflow

To configure goodwill points issue dataflow, perform the below steps/actions:

In the Connect-to-source section Block enter the source server details where the source data is present and the location for saving the processed file. See Connect to source.

In the Decrypt data block, if the files are encrypted, enter the details to decrypt the data. See Decrypt data.

In the Transform Data block, map the API fields with the source file. For information on how to map the fields, see Transform data.

It is mandatory to map the fields marked in asterisks (*) with the file.



📘

Note

The referenceId is for future use only. This ensures that in the future, if there is a need to replay the failures from the workflow, in cases where EMF is successful but Intouch end fails due to a timeout, points won't be mistakenly awarded twice to the same customer, as the reference ID is always unique.

In the Connect-to-destination block, enter the API endpoint details. For this template the API v2/request-workflow/GOODWILL-POINTS, is used. See Connect to destination.

In the Trigger block, enter the details to schedule the trigger. See Trigger.

For troubleshooting information, refer to the troubleshooting section of the documentation.

Updated 11 months ago