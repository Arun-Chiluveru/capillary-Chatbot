# Scraped content from: https://docs.capillarytech.com/docs/force-generate-barcode-template

(New) Request Workflow

Suggest Edits

The documentation covers the topics below:

Introduction

Request workflow for Customer Enrolment

Request Workflow for Badge Issuance

Request Workflow for Customer Status Change

Request Workflow for Points Redemption

Request Workflow for Goodwill Points

Updated 10 months ago