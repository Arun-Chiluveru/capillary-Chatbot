# Scraped content from: https://docs.capillarytech.com/docs/enable-tracking-of-clicked-links

Enable tracking of clicked links

Suggest Edits

To track the link (URLs or web links) clicks sent through messages, you need to do the following.

On the Engage+ home page, click the setting icon and navigate to the Messages page.

Enable the Enable link tracking in messages toggle button.

Choose the formatting of tags from the Format numerical tag drop-down menu.

To set the communication limit, click +Add limits.

📘

Notes

The communication limit allows you to configure the messaging limit, channel-wise for direct messaging channels, and an overall limit for all the channels.

This is also applicable for all communications sent using Journeys.

626

Setting up communication limits for each channel

To limit the number of messages to be sent through Engage+, follow these steps.

Click +Add limits.

634

In-Channel, select the channel for which you want to set the limit.

📘

To set a limit on overall messages (across channels), choose Overall.

426

Select the desired option by which you want to set a limit.

Daily: Check to set a daily limit and enter the limit value in the respective box. For example, 100 messages per day.

Weekly: Check this to set a weekly limit and enter the respective box's limit value. For example, 500 messages per week.

Monthly: Check this to set a monthly limit and enter the respective box's limit value — for example, 2500 messages per month.

📘

To edit the channel limit, hover the pointer over the more options (…) symbol, and then click Edit.

To delete the channel limit, hover the pointer over the more options (…) symbol, and then click Delete.

Updated 8 months ago