# Scraped content from: https://docs.capillarytech.com/docs/marvel-games

Channel configuration

This page provides you with information on communication/source channels in the Capillary platform.

Suggest Edits

The following channels are available on the Capillary platform. These can serve as either a source for customer registration, a communication channel to engage with a customer or both.

Facebook

WEB_ENGAGE

WECHAT

INSTORE

MARTJACK

TMALL

TAOBAO

JD

ECOMMERCE

WEBSITE

LINE

XIAOHONGSHU

GLOBAL_SCANNER

SUNING

PINDUODUO

KAOLA

MOBILE_APP

WHATSAPP

Linkedin

SMS

Indiamart

VIBER

MPUSH_FCM

STOREMAX

RCS

MAPP_SDK

OAUTH_EXTERNAL

ZALO

Adding account

From the channels list, click on the required channel name.

Click +Add account.

Enter the following details. These fields can differ based on the channel. For adding the details, contact the Gateway team.

Click Submit.

📘

Note

If any of the channels are unavailable, please contact the Capillary Gateway team for support.

Updated 10 months ago