# Scraped content from: https://docs.capillarytech.com/docs/loyalty-promotions-basic-and-advanced

Badges Reporting

Suggest Edits

You can use Insights and perform the following:

Create a chart using Badges KPI and Dimensions

Create a custom report on Badges

Export Badges using standard Badges export templates

Reporting on badges data is based on the badges fact and dimension tables. For more information, refer Badges fact and dimension documentation.

Updated 6 months ago