# Scraped content from: https://docs.capillarytech.com/docs/getting-started

Getting Started

Suggest Edits

This guide describes how to get started with Engage+.

1064

Campaign overall performance dashboard: Shows the overall performance of campaigns for the last 7 days, 1 month, 3 months, and 6 months.

Search Campaign: Enter the campaign name in the search box.

Filters campaigns by duration: Click the calendar icon to enter the duration in Start date and End date.

OU Filter: Filter campaigns created for different org units.

Filter campaigns by status, marketing objective, and/or created by: Click on the filters icon for advanced filters, choose the desired options, and click Apply.

340

Campaign status: Select Campaign status and choose from the following options.

Live Shows: ongoing campaigns.

Upcoming: Shows future campaigns.

Lapsed: Shows the past or inactive campaigns.

Marketing Objective: The marketing objective is an option to define the purpose of your campaign. For example, Boost sales, Acquire customers, Promote specific products, and so on. To know more about marketing objectives, see Marketing Objective.

Created by: This option allows you to filter campaigns created by a specific user. Select the user in the drop-down box.

Role-based access

We can provide access to org users based on their access to each of the following actions or components.

Create Campaign

Set campaign name and duration

Add a message - this includes the audience, incentives, message content

Schedule message

Get the message approved

View campaign reports post execution

Key Social Media KPI Definitions

Match Count

Count of customers who are available on Facebook with the same mobile or email, as present in our target list. (Approximated to the nearest 10)

Reach: Unique users reached through the campaign.

Impressions: Total number of exposures to your advertisement. One person can receive multiple exposures over time.

Clicks (All): Total number of clicks received on the links, buttons, etc.

Amount spent: Amount charged by Facebook for running the ad campaign

ROAS: Return on Ad Spend. The number of times the ad spend amount was recovered through Responder Sales.

Derived KPIs

Frequency: Average number of times an Ad was served to a reached customer. (Impressions / Reach)

Cost per Click (CPC): Amount Spend / Clicks

Cost per mille (CPM): Cost per thousand impressions: Amount Spend / Impressions / 1000

Updated over 1 year ago