# Scraped content from: https://docs.capillarytech.com/docs/store-hierarchy

Session Logs

Suggest Edits

The session logs feature enables you to track and review changes made for any customer by Intouch admin users. Session history displays the following information:

History of past sessions

Reason for the changes made

Date and time of each session by any user.

Starting and ending a session

Session recording starts and logs the data automatically whenever you log into member care and access a customer profile. To end a session, perform the following:

Click End session. The End session dialogue box appears. This dialogue box also appears, if you try to navigate to the home page.

From the Reason drop-down, select the appropriate option. This field becomes optional if no changes are made.

(Optional) In the Comments text box, enter additional comments, if any.

Click Yes, end session.



Viewing session logs

From the member care home page, click Session history to view the session logs.



Updated over 1 year ago