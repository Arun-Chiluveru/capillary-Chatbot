# Scraped content from: https://docs.capillarytech.com/docs/slab-change-log-standard-export-template

Methodology

Suggest Edits

The fraud detection method is based on a weight (w) associated with every rule which can be any value between 0 & 1 as specified by the brand. The weights help the brand to adjust the importance of every rule in finally considering the user as a fraud. Given below are the steps followed in fraud detection:

Brand provides the following:

Threshold for each rule.

Weight for each rule.

Critical score value.

The fraud detection engine follows these steps for every user: a. Evaluate each user against the 13 predefined fraud detection rules. And, whenever a user violates a rule, that is marked as 1 else 0. b. Calculates the score for each rule:

Multiplies the weight (w) by 1 if the rule is violated.

Multiplies the weight (w) by 0 if the rule is not violated. c. Sums the scores for all 13 rules to obtain the customer's total fraud score. If this total meets or exceeds the critical value (as defined by the brand or default 1.5), they are flagged as potential fraud.

Diagrammatic representation of fraud score calculation



Confirming the Fraud Status

The brand reviews the suspected fraud customer list (downloaded using the fraud export template) and can categorize each customer into the following fraud status:

Marked: A customer who has shown fraudulent behavior, but yet to be confirmed.

Confirmed: A customer who has been confirmed as a fraud (from the status "marked").

Reconfirmed: A confirmed fraud customer who has shown fraudulent behavior again.

Not_Fraud: A customer who has shown fraudulent behavior, but later found to be not fraud.

Internal: Internal Capillary users that make transactions and other activities for testing purposes.

These statuses are updated in the Intouch system through MemberCare or bulk upload via data import framework.

Configure Fraud Management

To use fraud detection, brands can follow the given steps:

Raise a Jira ticket with the product support team.

Provide the weightage and threshold values for the rules.

Provide the critical score. Based on these values, Capillary can configure the 13 KPIs for the brand.

Brand can then download the export template for fraud management.

Brand can use the fraud template to download a list of potential fraud customers.

Brand can mark the customers from the list, as fraud or not fraud, on an individual basis, using Member Care or by uploading them through the bulk import framework.

Fraud User Restrictions

The brand can define the restrictions for the customers who are CONFIRMED, or RECONFIRMED as fraud. These restrictions include:

Not issuing them vouchers.

Prohibiting changes to their mobile numbers.

Preventing them from redeeming points; and

Excluding their information from all the reports.

Brands can add the restrictions to customers through CDP. For more information, please refer to the restrictions documentation.

Sample CSV file downloaded using the fraud template



Updated 4 months ago