# Scraped content from: https://docs.capillarytech.com/docs/return-transactions-standard-export-template

Editing an export job

Suggest Edits

You can edit frequency, notify recipient, and validity end date only for recurring jobs and not for one-time export jobs.

With edit, you cannot

rename an export job once created

modify the template to change measures, KPIs, and dimensions

change the start date of validity

To edit an export job:

Click on an active export schedule that you want to edit

1343

Click Edit.

In Frequency, choose your preferred frequency range.

In Validity, set your preferred validity range according to the selected frequency.

In Notify Recipients, select recipients whom you want to send the notification during unsuccessful export.

Click Update.

Updated 10 months ago