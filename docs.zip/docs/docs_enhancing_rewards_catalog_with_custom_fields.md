# Scraped content from: https://docs.capillarytech.com/docs/enhancing-rewards-catalog-with-custom-fields

Managing Permission for Users in Multiple Orgs

Suggest Edits

A user created in one organization (originating org) can be granted access to other orgs. Users who were not originally created in an org but have access to it are called proxy users. By default, when a user is given access to another org, their permissions from the originating org are inherited. However, their permissions in each assigned org can be managed separately as needed.

Providing Access to a User to Multiple orgs

Perform the following to provide access to multiple orgs for a user who is created in an org.

Navigate to Organisation Settings > Security and Audit > Configure Access Control > Change The User Permission.



Expand the Change the User Permissions section and search for the user for whom you want to provide access to an org.



Click Manage that's present in the Proxy Org column.



A list of available organizations will appear in the left box. Select the organization you want to grant access and click Add.



Select the check box Check for Add & Untick to Remove and click Submit.

Once submitted, the proxy user will be successfully granted access to the selected organization within the Multi-Org setup.

Viewing Proxy Users

Once the proxy user is created and access is granted, follow these steps to verify their presence in the assigned organization and manage their visibility settings.

On the User Management page, use the Org Selection Dropdown at the top to select the organization where the proxy user was added (e.g., Client Merge&Merge).

Click on Settings icon at the top-left corner of the page.



Expand the "Show Proxy Organization Users" tab. Use the toggle switch to enable or disable proxy user visibility:

Toggle OFF → Only original users of the selected org will be displayed.

Toggle ON → Proxy users will also be included in the user list.

Click Save Changes to apply the setting.



Once enabled, proxy users will be displayed alongside original org users in the user list, allowing admins to manage them as needed.

Exporting Proxy Users

Export function now respects the proxy user toggle. If proxy users are included in the list, they will also appear in the export. Refer to the documentation on exporting, here.

Managing Permission for Proxy Users

A proxy user inherits permissions from their base organization by default. To modify them, go to Organization Setup > User Management, select the organization, and find the proxy user.

In the Permissions tab, a note states: "Permissions are from the user's base org. Edit to set permissions for this org." Click Edit to override inherited permissions. Refer to this documentation for assigning permission sets.



Updated 14 days ago