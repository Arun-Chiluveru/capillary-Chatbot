# Scraped content from: https://docs.capillarytech.com/docs/company

Points rolling expiry

Suggest Edits

Points rolling expiry is a feature that resets or extends the expiry date of loyalty points when a customer performs certain actions, such as making a transaction or redeeming points. These actions are referred to as "rolling events." Points rolling expiry allows you to control when loyalty points expire, ensuring that points remain valid as long as the customer continues to engage in rolling events.

When a rolling event occurs, the expiry date for all points earned is updated or rolled to a later date. The "rolling window" determines how far this expiry date is extended. For example, a rolling window of 12 months will extend the expiry date of the earned points by 12 months.

Including Zero Points in Rolling Expiry

By default, the rolling expiry process only considers points with a value greater than zero. If a customer performs a rolling event and receives no points for it, the system will not consider the rolling event even if it is valid, and the expiry window is not extended. To consider zero points, you can enable ROLLING_EXPIRY_INCLUDE_ZERO_POINTS to ensure that even zero-value points are considered for extending the expiry.

For example: A retail loyalty program allows customers to earn points on purchases. Points expire after 12 months unless they engage in a rolling event — such as making another purchase — to extend the expiry.

A customer earns 100 points in January 2024, with a 12-month rolling expiry (set to expire in January 2025).

Now, in December 2024, the customer purchases as part of a special promotion. However, this promotion does not award any new points (0 points are awarded).

With ROLLING_EXPIRY_INCLUDE_ZERO_POINTS Disabled:

Since the promotion awards 0 points, it is ignored by the rolling expiry.

The customer’s 100 points still expire in January 2025.

With ROLLING_EXPIRY_INCLUDE_ZERO_POINTS Enabled:

The system recognizes the 0-point award purchase as a valid rolling event.

The expiry date of the 100 points is extended to December 2026.

To enable ROLLING_EXPIRY_INCLUDE_ZERO_POINTS, raise a ticket to the sustenance team.

Creating a Points Rolling Expiry

To configure the points rolling expiry for a loyalty program, follow these steps:

On the Loyalty+ home page, navigate to the Settings page by clicking the

Gear Icon

icon



Select Points Rolling Expiry from the menu.

Enable points rolling expiry for all programs using the Points rolling expiry across program toggle.

Select the rolling expiry strategy using the Points rolling expiry strategy dropdown.

The rolling expiry strategies are as follows:

Rolling Expiry Strategy Description Example Maximum expiry date All points earned by the customer are assigned a single expiry date. If the date passes without a new rolling event, the expiry date for the points is reset to the expiry conditions configured within the loyalty program. This applies to points with a 'rolling' expiry strategy. A  customer earns points on January 1st 2025. The following configurations define the expiration of the points earned by the customer: - Points expiry for loyalty program: six months from date of issual (July 1st 2025). - Points rolling expiry strategy: 12 months from the date of issual.The customer makes a transaction on June 1st 2025, extending the expiry to June 1st of the following year (2026). If no further rolling events occur and the rolling window date (June 1st, 2026) has passed, the points will expire on this day. Add one more rolling window If no rolling events happen during the last rolling window, the expiry date is extended by another rolling window. The strategies for which the rolling window applies can be selected. Refer to the expiry conditions table for more information on the strategies available for points expiry. A customer earns points that expire after 12 months. If no rolling events occur during this time, the expiry date automatically extends by another 12 months.

Select the expiry strategies for which the rolling window is applied using the Types of points expiry strategies to be rolled over dropdown. This is applicable for the Add one more rolling window rolling expiry strategy.

Enter the period for the rolling window and select the units (Days or Months) from the dropdown menu.

Select the customer activities for which the rolling window is applied using the Customer activities for points expiry extension dropdown. For more information on the types of activities and events, refer to the documentation on customer activities and behavioural events.

Select Done to save the changes and create a points rolling expiry.

The points rolling expiry for all loyalty programs is successfully created.



Editing a Points Rolling Expiry

On the Loyalty+ home page, navigate to the Settings page by clicking the

Gear Icon

icon.



Select Points Rolling Expiry from the menu.

Edit the required fields.

Select Done to save the changes.

The points rolling expiry for all loyalty programs is successfully edited.

Updated about 13 hours ago