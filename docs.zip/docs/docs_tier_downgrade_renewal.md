# Scraped content from: https://docs.capillarytech.com/docs/tier-downgrade-renewal

Attributes - Other

Suggest Edits

isLoyal

Profile : currentCustomer Attribute : isLoyal Type : Boolean Meaning : returns True, if the current customer is registered in the brand's loyalty program Sub-Attribute: NA Syntax: currentCustomer.isLoyal() Example: currentCustomer.isLoyal==true

Example: write a rule to check if the current customer isLoyal or not. Profile: Current Customer Attribute: isLoyal() Type: Boolean Rule: currentCustomer.isLoyal()

Updated 9 months ago