# Scraped content from: https://docs.capillarytech.com/docs/mask-data-in-databricks

Communication details

Suggest Edits

The Communication tab on the Customer Single View page shows the communication summary of every communication channel for your customer.

You can view details of the following communication channels:

SMS

Email

Push notification

WeChat

WhatsApp

Zalo



📘

Note

Note: By default, OTPs are not masked on Member Care. You can raise a ticket and enable OTP masking. See the documentation to configure OTP masking.

To search for a message, you can click on the search icon and search using the Message ID.

Updated over 1 year ago