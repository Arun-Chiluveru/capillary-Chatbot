# Scraped content from: https://docs.capillarytech.com/docs/communication-channels

Communication Channels
Suggest Edits
Communication channels are the ways you can communicate and engage with your customers through SMS, Emails, messaging applications and push notifications.

Channels
LINE Logo
LINE
Push Notifications Icon
Push Notifications

Messaging Availability Across Channels and Platforms
This table provides an overview of support for various types of messages (Transactional, OTP, and Bulk) across multiple communication channels and platforms.

How to Read the Table

✓ (Checkmark): Indicates that the feature is available. For example, Bulk SMS under the Engage+ channel means that bulk SMS messaging is supported.
Template Creation (Template Creation): Indicates that while direct sending might not be supported, templates can be created for that message type. For instance, for Engage+, in WhatsApp OTP, the Template Creation symbol means that Whatsapp OTP message templates can be created in the Engage+ channel.
Channel	Type of Message	SMS	Email	WhatsApp	Zalo	LINE*	Mobile Push/In-app	Viber	RCS
Engage+	Transactional								
OTP			Template Creation	Template Creation				
Bulk	✓	✓	✓	✓	✓	✓	✓	✓
Journeys	Transactional								
OTP								
Bulk	✓	✓	✓	✓		✓		
Loyalty+	Transactional	✓	✓				✓		
OTP								
Bulk								
Unified Comms. Engine	Transactional		✓	✓					
OTP		✓	✓					
Bulk		✓	✓					
Send Comm. API	Transactional	✓	✓						
OTP	✓	✓						
Bulk	✓	✓						
GET Customer Interactions
API	Transactional	✓	✓	✓	✓	✓	✓		
OTP	✓	✓	✓	✓	✓	✓		
Bulk	✓	✓	✓	✓	✓	✓		
Auth Engine	Transactional								
OTP	✓	✓	✓	✓				
Bulk								
*For the LINE channel, individual message delivery statuses are not available.

**For information on creating OTP templates, refer to the documentation on creating templates.

