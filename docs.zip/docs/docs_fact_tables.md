# Scraped content from: https://docs.capillarytech.com/docs/fact-tables

Fact tables

Suggest Edits

Fact and dimension tables form the foundation for all reporting conducted within Insights+.

Fact tables contain quantitative data, typically numerical values that represent the measurements or metrics of a business process. For instance, in a sales environment, a fact table might record each sale transaction, with columns representing details such as transaction ID, sale amount, product ID, and date of sale. Each row in the fact table corresponds to a unique event or transaction and often references multiple dimension tables, which provide context to the facts.

📘

Note

By default, fact tables are not onboarded for all organisations. To enable them, raise a JIRA ticket with the Capillary Product Support team.

Below is the list of frequently used fact tables

Badges Bill Line Items Call Task Customer Status Communication Credits Log Contact Info Coupons Custom Field Data Customer Merge Log Customer Notes Customer Summary (members) Daily Till Summary Email Click Stats Milestones Registration Event Streaks Goodwill Requests Invitation Sent Issue Tracker Journeys Nsadmin Messages Payment Details Points Profile Users Referrals Referrers Response Info Return Bill Line Item Rewards Slab Change Log

Updated 3 days ago