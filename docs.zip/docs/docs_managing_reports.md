# Scraped content from: https://docs.capillarytech.com/docs/managing-reports

Managing Reports

Suggest Edits

This section explains how you can access and manage both standard and custom reports. It covers basic tasks such as downloading and sharing reports, as well as more advanced actions like exploring report details and setting targets for the reports.

Updated 10 months ago