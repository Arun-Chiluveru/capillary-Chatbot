# Scraped content from: https://docs.capillarytech.com/docs/connectplus_overview

CSV to XML conversion template

Suggest Edits

The CSV to XML conversion template allows you to convert CSV files to XML files. XML (Extensible Markup Language) is a language that uses user-defined tags to store data. Users can select any CSV file and map it to XML.

Use case:

A data analyst receives data from various departments through CSV files, which include fields like product ID, product name, price, etc.

However, the system ingests data in a specific XML format. XML has a hierarchical structure and incorporates metadata which makes it easy for humans and machines to understand easily.

By using the CSV to XML conversion template, he can convert all the CSV files into XML to facilitate easy data analysis.

Configuring CSV to XML conversion dataflow

To configure CSV to XML conversion template, perform the below steps/actions:

In the Connect-to-source Block, enter the source server details where the source data is present and the location for saving the processed file. See Connect to source.

In the Decrypt-data block, if the files are encrypted, enter the details to decrypt the data. See Decrypt data.

In the CSV-To-XML-Converter block, enter the conversion details. See CSV-To_XML-Converter.

In the Encrypt-data block, enter the encryption details to encrypt the file. See Encrypt Data

In the Connect-to-destination block, enter the SFTP server details. See Connect to destination.

In the Trigger-block, enter the details to schedule the trigger. See Trigger.

Updated over 1 year ago