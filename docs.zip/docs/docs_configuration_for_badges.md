# Scraped content from: https://docs.capillarytech.com/docs/configuration-for-badges

Different payment modes for rewards in the catalog

Suggest Edits

Brands can now expand their rewards catalog to include options to purchase rewards with cash, fixed points, variable points, or a combination of both, providing customers with greater flexibility and more reasons to engage with the loyalty program. With options including FREE, POINTS, CASH, CONV_RATIO and POINTS_CASH, brands gain enhanced flexibility and control over reward issuance.

This feature enables customers to receive a reward either by redeeming their points or by making a cash payment or both. Cash transactions or any other mode of payment occur outside the system and are not subject to validation within the system.





The supported payment modes are:

FREE: This payment mode incurs zero cost, requiring neither points nor cash.

POINTS: Loyalty points are redeemed from the customer's wallet to issue the reward.

CASH: The reward is issued without redemption or validation, assuming the tender transaction occurred outside the system (upstream system).

POINTS_CASH: In this payment mode, the system issues rewards based on redeeming both cash and loyalty points from the customer's wallet. The assumption here is that the cash transaction has been completed successfully, and the reward is issued based solely on this external transaction.

CONV_RATIO: The rewards system calculates the equivalent miles based on the points provided in the issue reward request basis the conversion ratio of the reward. For example:

If the conversion ratio value is 0.44 and the customer wants to burn 1500 points and the same points worth of miles need to be credited to his account, the rewards system calculates miles worth 1500 points based on the conversion ratio value i.e. 1500*0.44 = 660 miles

If the conversion ratio value is 0.44 and the customer wants 1000 miles to be credited. The reward system calculates the points to be redeemed i.e. 1000/0.44= 2272 points will be deducted.

Defining multiple payment modes for a single reward : Offer rewards with multiple payment options, giving customers the flexibility to choose their preferred payment method. For example,

Customers can get the cinema ticket either in 16,000 Points OR 10,000 ShowPoints + $72

Customers can get the merchandise in 1000 points OR 500 points + 5$ or 10$



During the issue call, the system records the payment mode used to issue the reward at the reward level.

Validations

If payment config is not set, type is not FREE_VOUCHER and intouchPoints is 0, an exception will be thrown saying either define the points greater than 0 or type should be FREE_VOUCHER

CONV_RATIO mode is supported only for CHARITY, MILES, CASH_WALLET, AUCTION, PHYSICAL_REWARD, GIFT_CARD, SWEEPSTAKES type of redemption types.

If type is FREE_VOUCHER and payment mode is set then, it will be FREE i.e. no points will be deducted.

Maximum of 5 mode of payments can be added against a single reward

Except free mode of payment and conversion ratio, all the other mode of payments can be combined as the user will never say that reward is free as well as can be bought with 500 points or 10$ cash.

📘

Note:-

New brands should no longer use the "intouch points" field. Instead, they should only use the new "payment config" block in Create and Update reward API



API documentation

Create Reward with payment configs

Update Reward with payment configs

Conversion ratio (CONV_RATIO)

"paymentConfigs": [
       {
            "paymentMode": "CONV_RATIO",
            "conversionRatio":0.33
        }
    ]

POINTS

"paymentConfigs": [
       {
            "paymentMode": "POINTS",
            "points":100
        }
    ]

CASH

"paymentConfigs": [
       {
            "paymentMode": "CASH",
            "cash":200
        }
    ]

Points and cash (POINTS_CASH)

"paymentConfigs": [
       {
            "paymentMode": "POINTS_CASH",
            "cash":100,
            "points":150
        }
    ]

FREE

"paymentConfigs": [
       {
            "paymentMode": "FREE"
        }
    ]

With Multiple Payment modes

"paymentConfigs": [
        {
            "paymentMode": "POINTS",
            "points": 150
        },
        {
            "paymentMode": "CASH",
            "cash": 500
        },
        {
            "paymentMode": "POINTS_CASH",
          	"points": 200,
            "cash": 500
        },
    ],

Following get APIs will return the payment config details

Get user specific reward by id

Get reward details by id

Get issued reward details for a user

Get all available rewards for user

Issue reward API now accepts payment config and tender blocks for recording cash based transactions for audit and reporting purposes.

Use cases:

A brand, ABC, wants to allow customers to purchase rewards using combination of points and cash rather than allowing customers to purchase rewards using only points. To achieve this, define the payment mode as POINTS_CASH`and issue the reward.

Concert Ticket Purchase: The customer had options to pay with 10,000 points, 5,000 points + $50, or $100, and chose 5,000 points + $50 to secure the ticket.

Hotel Stay Redemption: The member could redeem a hotel stay with 20,000 points, 15,000 points + $100, or $250, and opted for 15,000 points + $100.

Electronics Purchase: The customer had the choice to use 30,000 points, 25,000 points + $150, or $300, and decided on 25,000 points + $150 for the tablet.

Airline Ticket Redemption: The frequent flyer could book the flight with 40,000 points, 30,000 points + $200, or $500, and chose 30,000 points + $200.

Charity Donation: The customer had options to donate using 5,000 points, 3,000 points + $20, 1,000 points + $30, 2,000 points + $25, or $50, and selected 3,000 points + $20.

Updated 7 months ago