# Scraped content from: https://docs.capillarytech.com/docs/edit-or-modify-chart

Edit Chart

Suggest Edits

To edit or modify a chart, follow these steps:

Navigate to Library > Charts.

Select the chart type - Normal, Migration or Funnel.

In Search Charts, search the chart to edit either from the list or search by the name.



Click Edit and modify the required fields.



Click Save.

Updated about 1 year ago