# Scraped content from: https://docs.capillarytech.com/docs/automated-notebook-execution-based-on-etl-completion

Identifier change request

This page provides you with information on how to submit and approve identifier change requests via the Member Care page.

Suggest Edits

Submit change requests

🚧

Contact the Capillary Access Team if you do not have access to submit or approve requests.

You can submit the following change requests:

Change mobile number

Change Email ID

Change external ID

Account merge

Edit profile

Delete member's account

To approve or reject requests, configure notifications, auto-approval, OTP settings, and set escalation flow, refer to Manage ID change requests (Old Member Care UI).

Update customer identifier

Customer identifiers include mobile numbers, email IDs, and external IDs. An organization can have one or more of these identifiers.

Update mobile number

Navigate to the Membercare home page, then click the three-dots menu.

From the ID change request dropdown, select Change mobile number .



Enter the new mobile number.



Click Verify and send request.

Change email ID

Navigate to the Member Care home page, then click the three-dots menu.

From the ID change request dropdown, select Change email id .



Enter the new email ID and click Verify and send request.



Change external ID

Navigate to the Membercare home page, then click the three-dots menu.

From the ID change request dropdown, select Change external id .



Enter the new external ID and click Send request.



Delete member account

Navigate to the Membercare home page, then click the three-dots menu. From the ID change request dropdown, select Delete member's account and submit the request.



After a deletion request is raised for a customer, their status changes to Deletion Pending. The member account is deleted only after the deletion request is approved.

For more information on member account deletion request configuration and request statuses, refer to PII deletion configuration.

Merge Accounts

When duplicate accounts of a customer exist, you can merge those accounts into one. One account will be retained, and the other account will be removed.

Surviving Account: The customer account that will continue to exist after the accounts are merged is referred to as the Surviving Account. Deactivating Account / Victim account: The customer account that will be removed after merging is referred to as a deactivating account. Once deactivated, this account cannot be reactivated, and its data cannot be retrieved. Except for Behavioural events and requests, all other data is transferred to the survivor account.

Approve change requests

👍

Contact the Capillary Access Team if you do not have access to submit or approve requests.

For requests other than account deletion, auto-approval days cannot be configured.

To approve any change requests, do the following:

On the Member Care home page sidebar, navigate to Member Care > Requests > Member requests.

Click on the identifier you want to view, approve or reject.



To approve or reject a request, select the Pending tab. You can click All tab to view all requests, Approved tab to view approved requests and Rejected tab to view requests that were rejected.



You can select the desired date range and view the requests that were created within that specific duration.



Click Approve or Reject icon to approve or reject an identifier request.



Click Yes, approve button to approve the request.



Click Yes, reject to reject a request. It is mandatory to enter the reason for rejection.



Updated 10 months ago