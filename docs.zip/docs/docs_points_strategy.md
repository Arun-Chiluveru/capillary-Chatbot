# Scraped content from: https://docs.capillarytech.com/docs/points-strategy

Points strategy

Suggest Edits

Points strategy is created under the Loyalty+ program. Under Engage+, you can only allocate the existing points strategy to a campaign message. This can be added to a campaign message only through the message creation method. To know more about message creation, refer to the Create message flow.

To add a points strategy, refer to the following.

906

Under add incentive, click Points Strategy.

Select the points allocation method from the following.

Select a loyalty program from column 1.

Select an allocation method and points expiry from columns 2 and column 3.

Click Done.

📘

Point issue strategy: Points issue lets you select different point awards for different customers.

Points expiry strategy: Points Expiry helps in bringing customers back to your stores to redeem their points before expiry. Therefore, keep customers engaged with stores.

Loyalty program: Customer enrollment and engagement program to incentivize customers with points based on their activities.

To know more about points creation, allocation, and redemption strategy, see Loyalty+.

Updated over 1 year ago