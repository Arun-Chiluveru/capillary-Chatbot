# Scraped content from: https://docs.capillarytech.com/docs/contacted-standard-export-template

Exporting audience group

Suggest Edits

Export Framework lets you export metric values of a specific customer list using an Audience filter in a template. For example, you can export transactions made by a specific audience in a particular store. Use the right template based on the data you want to export.

See the following example for a better understanding:

📘

ALAN NEEDS TO EXPORT LOYALTY DETAILS OF CUSTOMERS WHO REGISTERED AT A SPECIFIC STORE

You can get registered customers of a specific store using the Members template. However, the maximum duration that you can have is one year. So you cannot get the entire set of registered customers through one export.

Solution:

Create an audience group using filters to get customers that registered in a specific store. For more information, See Registered Store filter of the loyalty category

In Export Framework, use Members template and select the specific Audience filter

Schedule the export. The exported list will have all customers that registered in a specific store irrespective of the selected date range

Important points to note while creating audience list:

You can get only loyalty and non-loyalty customers through the Members template

You can get all target audience of a campaign through the Users template irrespective of their loyalty status

Date range is not applicable in audience list export and Based on will be set to Audience selected by default

633

📘

Note:

If you want to export the audience of a specific campaign through templates other than Users and Members, it is required to select the campaign name, campaign id, or group name as a filter. Else, you will get an audience list from all campaigns

Custom fields are not selected by default in any template

You cannot get customers with the birth year before 1901

You cannot apply standard filters such as outlier status, fraud status, merge status, and admin TILL

Configuring a customer list export schedule involves the following steps:

Define a name and description for the export job

Set up the frequency and validity of the job

Choose the templates with events data

Tag the audience list to the template

To export audience list:

On Essential Insights, navigate to Data connectors > Export Schedules

Click Create Export Schedule

1333

Schedule Name: Specify a name for the current schedule job

Description: Specify a short description of the schedule job

Schedule Type: The target destination of the export files. Select FTP to save the files in the preferred FTP location, S3 to save the files in the internal S3 server. S3 is only used internally.

Frequency: Choose the frequency of running the current export job - Once, Daily, Weekly or Monthly. You can set a maximum of one-year duration

📘

The duration (From & Till dates) of the schedule job should always be future dates.

OPTION DESCRIPTION Once Runs the export job on the scheduled date(only once).  The data is considered based on the last updated date. In this, the Execute on date will be selected by default, which is the current date. In Export Data from, you need to choose the duration for which you want to capture the data (supports up to one-year duration). You cannot select the current date or future date. IMPORTANT NOTE: If you want to export data for a specific date range, the date range of Execute Date should always be more than the end date filter that you apply in the chosen template (s) - Modify Templates > Filters > Date Note : You can use Date or Time in filters to get the data by event date or event time respectively. Daily Runs the export job on a daily basis for the duration you specify. In Validity, choose the duration for which you want this daily schedule to run. You can select only current and future dates. You will get previous day's data the next day. For example, you will get current day's data the next day. Note : You cannot select past date in Validity Weekly Runs the job on a weekly basis for the duration you specify. In Execute on, select the day of the week when you want to run the weekly schedule In Validity, choose the duration for which you want this weekly schedule to run. You can select only current and future dates. You can select a maximum of 1 year duration. Note : If Execute on is set to Sunday (s), you will get weekly data every Monday. Monthly Runs the job on a monthly basis for the specified duration. In Execute on , select the day of the month when you want to run the monthly schedule, which is from 1-30/31. In Validity , choose the duration for which you want this monthly schedule to run. You can select only current and future dates and a maximum of 1-year duration. Note : If Execute on is set to 1, you will get monthly data that is available until the 1st of every month on the 2nd.

Notify Recipients: Select the recipients for the current schedule and click Select to apply. These users will get recurring notifications (until the validity of the job) whenever the job runs and sends the link of the target location of the exported data.

In Export Templates, click Add/Remove Templates

824

Check the templates that you wanna add to the export job and click Select. The templates should contain events data to download the customer list By default, all the applicable KPIs and dimensions of the template are selected. You need to modify the template to select the customer list and also the KPIs and dimensions that you want to export. Click Modify the template.

673

Note: Once you select a template other than users or members, it is required to add the filter campaign name, campaign id, or group name to get customers of that campaign or group. Else, you will get the details from all campaigns. *10. Click the Filters icon and navigate to the Audience tab.

193

Select your preferred audience list. You can also search for a specific list using the Search box. You will see all the selected audience list (segment) as shown below.

845

Click Save.

Updated over 1 year ago