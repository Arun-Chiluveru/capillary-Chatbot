# Scraped content from: https://docs.capillarytech.com/docs/testpreview-journey

Test Journey

Suggest Edits

The test/preview flow within the journey framework allows users to validate journey workflows before making them live. This aids in understanding how the journey operates in real-time before its full rollout to end customers.

With this feature, you can configure the journey for a set of test customers and trigger events for a test customer to observe how that actual customer will move through the journey. Additionally, during the test, there is no need to wait for actual configured wait times for tests to complete as you can skip the wait times.

Prerequisite

To test the journey, test customers should be added. The journey will apply to these defined test customers, and whoever meets the entry criteria will enter the test journey. This test group will apply to all test journeys.

To add the test customers, perform the following:

From the Journeys page, click on Settings icon and then select Test Customers.

Click on Edit.

Search for the desired contact using their identifiers in the text field.

Click on Add and then Save Changes to finalize the process.



Testing journey

To test a journey, perform the following:

🚧

Attention

Only journeys in Draft state can be tested. Once a journey has been made LIVE, you will not get an option to test the journey.

If you remove customers from the Test users list while configuring a test journey or during processing, those customers will not enter the journey.

Navigate to the journey that you want to test.

Click on Test journey. It will prompt you to confirm whether you want to switch to test mode. Click on Yes, switch to test to confirm.



Once the journey has been switched to TEST mode, trigger the appropriate events for your test customers by making API calls, ensuring that the test customer satisfies the entry criteria of the journey and can enter it. For example, suppose the entry criteria is to make a transaction of 500$. In that case, you can use appropriate and add a transaction of the required amount to enter the customer into the journey. Note: If the journey is complicated, it takes longer to change to test mode. Until then, the journey will be in 'Processing to run test' status.





To search the status of a customer in the journey, enter the customer identifier (mobile with country code or customer/user ID) in the search box. A green line indicates that the customer has entered that particular journey event. A blue colour indicates that the event is yet to happen or is being processed.



If the customer is at the wait block, you can select Skip wait to skip the configured wait time and proceed to the next block immediately.



If you have configured an Event-based wait block, you can trigger a Transaction event for the customer and instead of waiting for the configured number of days, you can skip the waiting period. The customer will then proceed to the appropriate path and block.

Once you are satisfied with your test results, you can stop the test, and your journey's mode will revert to the draft state. Then, you can make the journey live by following the usual process of sending it for approval.



📘

Notes

You can remain in the test mode of the journey for as long as necessary. This means that if you have tested several scenarios in one session and would like to continue testing in another session, you can do so. Your journey will remain in the test mode, and you can always find it on the listing page of Journeys.

If you create another version of a journey by editing a Live journey, you can follow the same steps to test the updated version. The only condition is that your test customers should now satisfy the entry criteria of the new version. Make sure that the incentives added are not repeated. For example, if you use the same reward ID twice, the system will throw an error.

You can continue testing any of your journeys that are currently in Draft mode. Add the user to the “Test customers” group for which you want to run the test.

Updated 11 months ago