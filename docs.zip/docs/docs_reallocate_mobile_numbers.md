# Scraped content from: https://docs.capillarytech.com/docs/reallocate-mobile-numbers

Mask Contents in a CSV

Suggest Edits

The hash-csv-fields block enables you to hash/mask the contents in a CSV file. This can be used when the CSV file contains PII data or any sensitive data. The hashing algorithm supported are:

SHA-256

SHA-512

SHA-1

MD5

RIPEMD-160



Field Description Enabled Select true to enable the hashing. Hashing Algorithm Lists the available supported hashing algorithms. Headers need to be hashed Define the column header names that need to be hashed. The headings should be comma-separated without spaces between them. Syntax: heading1,heading2 Example: email,mobile Delimiter The delimiter used to separate the header names. The delimiters supported are: - Pipe (|) - Comma (,) - Ampersand (&) - Per cent (%)

Updated 30 days ago