# Scraped content from: https://docs.capillarytech.com/docs/audience-group-filters

Audience group filters

Suggest Edits

To create a new audience group:

On the Engage+ page, click the Audience tab.

1001

Click Create New.

Enter an Audience Group name.

Select Apply filter condition, and then click Next.

626

Click Filter to filter customers based on different parameters.

📘

For more information about audience filters, see Audience Filters.

Click Next to proceed.

To add more customers, click Add more customers.

Click Save Group.

959

Cart & catalog promotions

Promotions earned

The filter lets you create audience list with customers who earned specific number of promotions during a selected period.

For example, you wish to filter out users who have earned promotions more than three times in July. Assume the following data is available - Zoha earned 5 promotions in June, Raj earned 2 promotions in July, and Simran 4 promotions in June.

Here, Zoha will be selected as she is the only one who earned more than three promotions in July.

Basic filter options:

Basic Date Considers promotions earned in the specified period. You can choose duration either by Specific dates or Relative days . Promotion earned count Lets you filter customers whose number of earned promotions is in a specific range. You can select a range from minimum to maximum promotions. For example, you can get customers who earned between 5 -10 promotions. You can also use the operators greater than equal, less than equal, equals and in range of.

Behavioral event-based filters

As soon as a behavioural event is created and its data becomes available in Insights, an audience filter for that event can be used to segment users. These filters help create audience groups for bulk communications and refine reports in Insights based on event attributes, including segmentation by the number of times a user performed an event.

For example, if a new behavioural event is introduced to track user steps and the device type used for capturing the activity (e.g., Mobile/Smartwatch), brand managers can create an audience group such as: "Users who have walked more than 500 steps in the last week and used a mobile device to capture the activity."

For more information on audience filter-based reporting, refer to the Audience group filter in reports documentation.

Updated about 2 months ago