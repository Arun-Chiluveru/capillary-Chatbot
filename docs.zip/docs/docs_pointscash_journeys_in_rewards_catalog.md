# Scraped content from: https://docs.capillarytech.com/docs/pointscash-journeys-in-rewards-catalog

Setup Subscription

Suggest Edits

Introduction

Customers can subscribe or unsubscribe from receiving SMS communications for each source of your organization. This module helps you in automating customer subscriptions for InStore, eCommerce accounts, and WeChat.

Two types of subscriptions are supported by Capillary - transaction messages for personalized messages and promotional messages for bulk communications such as campaign messages.

This section provides a detailed procedure on configuring subscriptions for the sources InStore, WeChat, and e-commerce.

Limitations

Only registered customers can request opt-in or out-out services.

Success messages for opt-in or opt-out depend on the message you configure on the respective pages.

When non-registered customers request such opt-in or opt-out service, the request will be silently ignored.

When a customer who is already opted-in, places a request for opt-in no action will be taken and such requests will be silently ignored.

📘

Supported communication channels are email, SMS, and WeChat.

Supported sources are all sources with active accounts that are mapped to the supported channels.

For detailed help on configuring opting in or opting out, see the following topics.

Email Subscription Settings: You can configure email subscriptions through a link that facilitates customers to opt-in or opt-out from org emails.

Mobile Number Subscriptions: You can configure mobile number subscriptions by two options - either through SMS or missed call.

Missed Call-based Subscription Settings: In this, a customer needs to give a missed call to the dedicated number that is configured for opt-in or opt-out.

SMS-based Subscription Settings: In this, the customer needs to send an SMS in the format that is configured for opt-in or opt-out.

📘

WeChat subscription settings are configured by default (if applicable for the org). You cannot modify WeChat subscription settings.

SMS based Subscription Settings

The Capillary Subscription Settings module lets you configure opt-in or opt-out through a missed call or SMS.

For missed call-based opt-in and opt-out, you need to configure different numbers for each action. i.e., opt-in to promotional SMSs, opt-in to transaction SMSs, opt-out of promotional SMSs, opt-out of transaction SMSs.

For SMS-based opt-in and opt-out, you can have just one number for all actions but with different commands. For example, to opt-out, send STOP to 1234; to opt-in send START to 1234.

Access SMS subscription settings page

To configure the SMS Subscription Settings page:

On InTouch Settings, click Subscription Settings > SMS

Click Edit Settings



For orgs with multiple brands, you need to configure settings for each organization unit (OU).

To configure settings at the OU level, check Have different settings for different organizational units.

Enable subscription status syncing across OUs (for MLP enabled orgs)

Orgs with multiple org units can engage a customer through different org units of the org. The customer gives confirmation for opt-ins and opt-outs through the option configured for the org unit.

Opt-in to all OUs if subscription entry from any of the OUs is Opt-in: Check this option to opt-in customers to all org units If they opt-in to any of the org units.

For example, assume the org has four org units - OU1, OU2, OU3, and OU4. if a customer opts into OU3, enabling this option will opt in the customer to OU1, OU2, and OU4 also.

Opt-out from all OUs if the first subscription entry from any of the OUs is Opt-out: Check this option to opt-out customers from all org units of the org if they were to opt-out from any of the org units.

For example, in the preceding example, if a customer opt-outs from OU2, enabling this option will opt out the customer from the other OUs as well - OU1, OU3, and OU4

The following settings are common for both single-brand orgs and multi-brand orgs.

Subscription Settings for Promotional SMSs

For Promotional SMSs subscription through missed call, you need to have a different number for each action and follow the steps specified below.

In Customers can modify preference by, choose to give a missed call

If you are switching the preference, you will see a prompt screen to confirm the change in preference. Click Reset & Proceed to continue.

Note: The current preference settings will be lost once you click Reset & Proceed



OPTION DESCRIPTION SETTINGS Promotion {{SMS Optout}} tag Lets you configure the optout tag. Click Configure to setup the optout tag. You will see the following options _ Define the {{code}} to be sent : Define the {{code}} tag - the command that you want to have in the SMS to opt-out a mobile number from the promotional SMSs of the current org or OU _ Define the {{num}} to which the code to be sent : Define the {{num}} tag - a number to which customers need to send an SMS to opt-out of promotional SMSs of the current org or OU - Define the {{Optout}} tag : Specify the opt-out message that needs to be sent to customers in place of the tag. Use the + icon and insert {{ code }} and {{ num }} as appropriateClick Save Promotion {{SMS Optin}} tag Lets you configure the optin tag. Click Configure to setup the optin tag. You will see the following options _ Define the {{code}} to be sent : Define the{{code}} tag - the command that you want to have in the SMS to opt-in a mobile number _ Define the {{num}} to which the code to be sent : Define the {{num}} tag - Specify a number to which the user needs to send SMS for opting in to the org's promotional SMS - Define the {{Optin}} tag : Specify the opt-in message that you want to send to customers in place of the {{Optin}} tag used in SMS templates. Click the + icon and insert {{ code }} and {{ num }} as appropriateClick Save

Select the desired Optin type:

i. Single: Registered customers with no opt-in preference and customers who are opted-in for org's or OU's promotional are targeted in this type. ii. Restricted Single: Only customers who are opted-in for the org level or OU level promotional SMS are targeted in this type iii. Double: Customers are allowed to manually opt-in to the org's promotional SMS and receive SMSs only after verifying their opt-in status.

In Double, you will need to send a verification message to allow the customers to confirm their opt-in manually. You will see a new field Verification Message. Click the respective Configure option and set the verification message. If you are using Unicode characters in the message, check Allow Unicode Characters

The following table shows the org's preference of sending promotional messages in each type

Type Promotional SMS to Opt In numbers Promotional SMS to no Preference numbers Promotional SMSs to Opted out numbers Single Yes Yes No Restricted Single Yes No No Double In Double type, you need to configure the verification message that will be sent to customers to manually opt-in No by default ( Customers will start getting promotional SMSs only after verifying their numbers ) No by default ( Customers will start getting promotional SMSs only after verifying their numbers ) No

Check to Send Optin confirmation SMS and configure the message to be sent on a successful opt-in

Check to Send Optout confirmation SMS and configure the message to be sent on a successful opt-out

In Sender Number, specify the dedicated number to send promotional SMS (for the current org or OU)

SMS based Subscription Settings for Transaction SMSs

For Transactional SMSs, you can configure only opt-in and opt-out tags. The Optin Type and Optout Type are set by default. You cannot modify it.

Scroll down to the Transactional SMS setting section



To configure the Optout tag, click the Configure option corresponding to the Transactional SMS setting



Define the {{trans_unsub_command}} to be sent: Specify your preferred command to out out of transactional SMSs (for example: STOP).

Define the {{trans_unsub_shortcode}} to be sent: Specify the shortcode to which customers need to send the SMS out of transactional SMSs.

Define the {{Optout}} tag: Specify the opt-out message that will go with the transactional SMSs for SMS-based opt-out.

Click Save to save the changes.

Missed Call based Subscription Settings

The Capillary Subscription Settings module lets you configure opt-in or opt-out through a missed call or SMS.

For missed call-based opt-in and opt-out, you need to configure different numbers for each action. i.e., opt-in to promotional SMSs, opt-in to transaction SMSs, opt-out of promotional SMSs, opt-out of transaction SMSs.

For SMS-based opt-in and opt-out, you can have just one number for all actions but with different commands. For example, to opt-out, send STOP to 1234; to opt-in send START to 1234.

To configure missed call based Subscriptions Settings:

On InTouch Settings, click Subscription Settings > SMS

Click Edit Settings



For orgs with multiple brands, you need to configure settings for each organization unit (OU).

To configure settings at the OU level, check Have different settings for different organizational units The following settings are common for both single-brand orgs and multi-brand orgs.

Subscription Settings, Customer Preference

How brands regard them:

Missed Call based Subscription Settings for Promotional SMSs

You need to have a unique number for each action that you wanted to configure for the missed calls based.

To configure missed call based subscription settings:

In Customers can modify preference by, choose to give a missed call

If you are switching the preference, you will see a prompt screen to confirm the change in preference. Click Reset & Proceed to continue.

Note: The current preference settings will be lost once you click Reset & Proceed



OPTION DESCRIPTION SETTINGS Promotion {{SMS Optout}} tag Lets you configure the optout tag. Click Configure to setup the optout tag. You will see the following options _ Define the {{num}} to be given a missed call : Define the {{num}} tag - a number to which customers need to give a missed call to opt-out of promotional SMSs of the current org or OU. _ Define the {{Optout}} tag : Specify the opt-out message that needs to be inserted for the {{ Optout }} tag used in SMS template. Use the + icon and select num to insert the missed call number tag - {{ num }} - in the message Click SAVE Promotion {{SMS Optin}} tag Lets you configure the optin tag . Click Configure to setup the optin tag. You will see the following options _ Define the {{num}} to be given a missed call : Define the {{num}} tag - Specify a number to which the user needs to give a missed call to opt-in to the promotional SMS of the current org or OU _ Define the {{Optin}} tag : Specify the opt-in message that you want to send to customers in place of the {{Optin}} tag used in SMS template .  Use the + icon to insert the missed call number tag - {{ num }} - in the message Click SAVE

Select the desired Optin type: i. Single: Registered customers with no opt-in preference and customers who are opted-in for org's or OU's promotional are targeted in this type. ii. Restricted Single: Only customers who are opted-in for org's or OU's promotional SMS are targeted in this type iii. Double: Customers are allowed to manually opt-in to the org's or OU's promotional SMS and receive SMSs only after verifying their opt-in status.

In Double, you will need to send a verification message to allow the customers to confirm their opt-in manually. You will see a new field Verification Message. Click the respective Configure option and set the verification message. If you are using Unicode characters in the message, check Allow Unicode Characters

The following table shows the org's preference of sending promotional messages in each type

Type Promotional SMS to Opt In numbers Promotional SMS to no Preference numbers Promotional SMSs to Opted out numbers Single Yes Yes No Restricted Single Yes Yes No Double In Double type, you need to configure the verification message that will be sent to customers to manually opt-in No by default (Customers will start getting promotional SMSs only after verifying their numbers) No by default (Customers will start getting promotional SMSs only after verifying their numbers) No

Check to Send Optin confirmation SMS and configure the message to be sent on a successful opt-in

Check Send Optout confirmation SMS and configure the message to be sent on a successful opt-out

In Sender Number, specify the number from which you want to send promotional SMS

SMS based Subscription Settings

You can have a single number for all actions but with different commands.

To configure SMS based subscription settings:

In Customers can modify preference by, choosing Sending an SMS and configuring other fields as explained in the table below

If you are switching the preference, you will see a prompt screen to confirm the change in preference. Click Reset & Proceed to continue.

Note: The current preference settings will be lost once you click Reset & Proceed



OPTION DESCRIPTION SETTINGS Define the {{code}} to be sent Lets you set the command for Promotion {{SMS Optout}} tag Lets you configure the optout tag . Click Configure to setup the optout tag. You will see the following options _ Define the {{code}} to be sent: Define the{{code}} tag - the command that you want to have in the SMS to opt out a mobile number from the current org's or OU's promotional SMS _ Define the {{num}} to which the code to be sent: Define the {{num}} tag - a number to which customers need to send an SMS to opt-out from the current org's or OU's promotional SMS - Define the {{Optout}} tag : Specify the opt-out message that needs to be inserted for the {{Optout}} tag wherever used in SMS templates. Use the + icon and insert {{code}} and {{num}} as appropriateClick SAVE Promotion {{SMS Optin}} tag Lets you configure the optin tag . Click Configure to setup the optin tag. You will see the following options _ Define the {{code}} to be sent: Define the{{code}} tag - the command that you want to have in the SMS to opt in a mobile number _ Define the {{num}} to which the code to be sent : Define the {{num}} tag - Specify a number to which the user needs to send SMS for opting in to the org's promotional SMS - Define the {{Optin}} tag : Specify the opt out message that will be replaced wherever the {{ Optin }} tag is used in SMS templates. Use the + icon and insert {{ code }} and {{ num }} as appropriateClick SAVE

Select the desired Optin type:

i. Single: Registered customers with no opt-in preference and customers who are opted-in for org's or OU's promotional are targeted in this type. ii. Restricted Single: Only customers who are opted-in for org's or OU's promotional SMS are targeted in this type iii. Double: Customers are allowed to manually opt-in to the org's or OU's promotional SMS and customers will keep receiving messages only after verifying opt-in status.

When you select Double, you will see the Verification Message option. Click the respective Configure option and configure the message. If you want to use Unicode characters in the message, check Allow Unicode Characters

The following table shows the org's preference of sending promotional messages in each type

Type Promotional SMS to Opt In numbers Promotional SMS to no Preference numbers Promotional SMSs to Opted out numbers Single Yes Yes No Restricted Single Yes Yes No Double In Double type, you need to configure the verification message that will be sent to customers to manually opt-in No by default ( Customers will start getting promotional SMSs only after verifying their numbers ) No by default ( Customers will start getting promotional SMSs only after verifying their numbers ) No

Check to Send Optin confirmation SMS and configure the message to be sent on a successful opt-in

Check Send Optout confirmation SMS and configure the message to be sent on a successful opt-out

In Sender Number, specify the number from which you want to send promotional SMS

Missed Call based Subscription Settings for Transaction SMSs

For Transactional SMs, you can configure only opt-in and opt-out tags. The Optin Type and Optout Type are set by default. You cannot modify it.

Scroll down to the Transactional SMS setting section



To configure the Optout tag, click the Configure option corresponding to the Transactional SMS setting



Define the {{trans_unsub_shortcode}} to be given a missed call: Specify the shortcode to which customers want to give a missed call to out out of transactional SMSs

Define the {{Optout}} tag: Specify the opt-out message that will go with the transactional SMSs

Click Save to save the changes

Email Subscription Settings

Subscription Settings for Single Brand Org (InStore)

On Capillary InTouch, navigate to Settings > Subscription Settings (v2)

Navigate to the InStore source and click Email Channel.

Check Have different subscription settings for different organizational units to configure email subscription settings separately for each org unit (applicable only for orgs with multiple org units).



In Select Org Unit, choose the OU (Org Unit) for which you want to configure the email subscription. You will not see this option for single OU orgs.

Configure Settings for Promotional Emails as explained in the following table.

OPTION SUB OPTION DESCRIPTION Optin type Single (by default) Customers who are opted in and the customers with no subscription preference are considered as opted in customers for promotional messages. Restricted Only opted in customers are considered. Send Optin Confirmation email Configure Configure the email that you want to send for the opt-in confirmation. Send optout confirmation email Configure Configure the email that you want to send for the opt-out confirmation. Sender ID for verification and confirmation emails - Choose the sender id from which you want to send promotional messages. Sender name - Specify your preferred sender name for the promotional messages.

📘

Confirmation messages of a customer opt-in or opt-out will not be sent for transaction messages.

Use Go to next org unit to view and edit details of each org unit. Similarly, click Go to the previous org unit to view and edit details of the preceding OU (if available).

Email Subscription Settings for e-commerce

On Capillary InTouch, navigate to Settings > Subscription Settings (v2)

Navigate to the Ecommerce account for which you want to set or modify email subscription settings and click Email Channel.



Configure Settings for Promotional Emails as explained in the following table.

OPTION SUB OPTION DESCRIPTION Optin type Single (by default) Customers who are opted in and the customers with no subscription preference are considered as opted in customers for promotional messages. Restricted Only opted in customers are considered. Double Customers need to opt-in manually. Send Optin Confirmation email Configure Configure the email that you want to send for the opt-in confirmation. Sender ID for verification and confirmation emails - Choose the sender id from which you want to send promotional messages. Sender name - Specify your preferred sender name for the promotional messages.

📘

Confirmation messages of a customer opt-in or opt-out will not be sent for transaction messages.

Use Go to next org unit to view and edit details of each org unit. Similarly, click Go to the previous org unit to view and edit details of the preceding OU (if available).

Email Subscription Settings for WeChat

On Capillary InTouch, navigate to Settings > Subscription Settings (v2)

Navigate to the WeChat account for which you want to set or modify email subscription settings and click Email Channel.



Configure Settings for Promotional Emails as explained in the following table.

OPTION SUB OPTION DESCRIPTION Optin type Single (by default) Customers who are opted in and the customers with no subscription preference are considered as opted in customers for promotional messages. Restricted Only opted in customers are considered. Double Customers need to opt-in manually. Send Optin Confirmation email Configure Configure the email that you want to send for the opt-in confirmation. Send optout confirmation email Configure Configure the email that you want to send for the opt-out confirmation. Sender ID for verification and confirmation emails - Choose the sender id from which you want to send promotional messages. Sender name - Specify your preferred sender name for the promotional messages.

📘

Confirmation messages of a customer opt-in or opt-out will not be sent for transaction messages.

Use Go to next org unit to view and edit details of each org unit. Similarly, click Go to the previous org unit to view and edit details of the preceding OU (if available).

Updated over 1 year ago