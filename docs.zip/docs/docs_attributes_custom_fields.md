# Scraped content from: https://docs.capillarytech.com/docs/attributes-custom-fields

Badges

Suggest Edits

Introduction to Badges

Type of Badges

Getting started

Configuration for Badges

Managing Badges

Updated about 1 year ago