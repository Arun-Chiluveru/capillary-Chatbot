# Scraped content from: https://docs.capillarytech.com/docs/custom-templates

Handling of rejected transactions

In this page, information of how Capillary handled rejected transactions will be available.

Suggest Edits

Basically, whenever a transaction happens, the bill comes to the capillary system and will be processed. However, sometimes, in those transactions, we might get:

Line item that is not present in the master list

Payment method that is not registered in the system

Stores whose details are not yet added in the capillary system

Missing transaction extended field

Missing customer extended field

Whenever these situations occur, those transactions will be stopped from processing (rejected), and will be moved to a centralised sanity queue instead based on below.

After this enhancement, the handling will be as below:

If they are of 1st, 2nd, 3rd type, they will be moved to the sanity queue.

If they are of 4rth, 5th type:

If they are of enum (basically a bunch of options), they will be moved to the sanity queue.

For all the other types, they will be marked as failed permanently.

Remember, all these transactions will be marked either as “pending” or “failed” as per above flow. All these configurations need to be enabled by the brands, otherwise the system will default to current behavior.

Once these transitions are moved to the sanity queue, an event notification will be sent to the respective brands notifying them that we have received these types of transactions. Brands can fetch these transactions from APIs too to check about them as per their policies (daily, weekly, etc..)

In the event notification that will be sent to brands, it contains following information:

Event name

Event datetime

Bill number

Customer identifier

Rejection type, .i.e., can be reprocessed or not

Reason of the rejection

Source details of the bill

Brands can get these transactions from API based on:

Rejection type

All pending transactions for a customer

Then brands need to provide the new data points (new line items, new payment methods, new store, new extended field values) that can be considered for transactions to Capillary. Once they are updated in the Capillary system, all these transactions in the sanity queue will be re-processed once again by our capillary system.

During the reprocessing, the process will happen based on the processed date not the original bill date. The APIs involved in this entire sanity queue are following:

getRejectedTransactions: Fetches all the rejected transactions for the org, based on the input query params.

retriggerTransactionAdd: Checks and updates the status of rejected Transaction. Retriggers the transaction add for the rejected transaction which are completely fixed.

markFailed: Updates the rejected transaction status to PERMANENT_FAILED

getReTriggerStatus: Gives the status of retriggered rejected transactions for the given retrigger Id

API links will be available here:

https://docs.capillarytech.com/reference/getrejectedtransactions

Updated over 1 year ago