# Scraped content from: https://docs.capillarytech.com/docs/organization-management

Reset Password Using Import

Suggest Edits

To reset the passwords for admin users on respective Org, perform the following:

From the Organization settings, navigate to Master Data Management > Data Import > Importprofile, and upload the CSV file containing users for password reset.

Click Submit.



From the Choose profile drop-down, select AdminUsers.

Select a template for the mapping from the Choose template drop-down or select the Create new template check box to create a new template.

Select Submit.

In the Configure Template, select password and select add



Select the appropriate column from the CSV file for each necessary field and configure the field mappings for resetting passwords. For example, from the Username(Email) drop-down, select the column name that has the customer's email information.

Select Submit.

Sample CSV for Password Reset user's

The password must contain:

At least one uppercase letter (CAPS).

At least one numeric character.

At least one special character.

A minimum of 9 characters long.



Updated 6 months ago