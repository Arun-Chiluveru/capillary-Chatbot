# Scraped content from: https://docs.capillarytech.com/docs/block-level-report-of-journeys

Block-Level Reporting in Journeys

Suggest Edits

The Journey Block Level Reporting feature provides detailed insights into the performance of individual blocks within a journey. This enhanced reporting capability helps you to understand how each block is performing and enables you to take action if required.

🚧

Note

By default, this feature is not available for all the orgs. You need to raise a Jira ticket to the sustenance team to enable the feature for your org.

Type of KPIs in the report

The application fetches different types of KPIs, depending on the blocks used in the journey:

Basic channel measures such as Sent, delivered, clicked and opened (wherever applicable)

Basic journey measures such as the number of customers who entered a block, number of customers who exited the journey, number of customers waiting in a wait block and so on

Incentives measures - Issued and Redeemed

📘

Notes

A journey report will be available 24 hours after the Journey goes live. This is based on the ETL sync time as it is based on the date from the Insights backend.

Viewing a report

To view a report of a Journey, perform the following:

From the Journey listing page, open the journey for which you want to see the performance report.

Turn on the View report toggle switch. The report is displayed for the individual blocks.



You can use the date filter the performance date based on the date range. The maximum duration of a report is not limited, but you can adjust the date range as needed. Refer to section Using date filter.



From the meat-ball menu, click the Reset to default view to reset the view.

Using date filter for report

The date filter allows you to view the report for a desired date range. Below are the features of the date filter:

The default date range for the report is from the date the journey went live until the current date.

You can alter the date range for the report by changing the start and end dates.

When you open the report mode, the application displays relevant data based on the selected version. For instance, if you have two versions of your journey and Version 1 spans from August 2 to August 3, the application will display the report for that specific duration when you open Version 1.

FAQs

Can we download a report? At present, you cannot download a report.

Is this available for all organisations by default? No. You need to raise a Jira ticket to enable this feature.

Why might the View Report button be disabled after a journey goes live? The button may be disabled if the ETL Sync is still in progress. The system takes 24 hours after the journey goes live to generate the report.

Are there any limitations to the reporting functionality? Yes, in the initial phase of reporting functionality, certain features may be limited. For example:

Report download flow is not covered

Channel priority and AB testing blocks will not display detailed metrics for sub-blocks.

Updated 8 months ago