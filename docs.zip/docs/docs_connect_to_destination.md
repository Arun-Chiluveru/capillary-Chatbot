# Scraped content from: https://docs.capillarytech.com/docs/connect-to-destination

Card update template

Suggest Edits

The card update template allows you to update the card details.

Configuring card update dataflow

To configure coupon redeem dataflow, perform the below steps/actions:

In the Connect-to-source section Block enter the source server details where the source data is present and the location for saving the processed file. See Connect to source.

In the Decrypt data block, if the files are encrypted, enter the details to decrypt the data. See Decrypt data.

In the Transform Data block, map the API fields with the source file. For information on how to map the fields, see Transform data.

It is mandatory to map the statusLabel and the cardNumber fields with the file.



In the Connect-to-destination block, enter the API endpoint details. For this template the API /v2/card, is used. See Connect to destination.

In the Trigger block, enter the details to schedule the trigger. See Trigger.

Updated 12 months ago