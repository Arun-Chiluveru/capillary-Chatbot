# Scraped content from: https://docs.capillarytech.com/docs/points-standard-export-template

Custom Namespace for Organisation

Suggest Edits

As are moving towards onboarding more brands across verticals such as fuel retail, hospitality, CPG and so on in past years. With this, demands to make the reporting customization have also increased.

We have now introduced the conversion of UI labels in Insights+ for the airline industry. For eg - Currently, across an organization, an airline vertical may not want to see points mentioned anywhere in its reporting view. Instead, you can now enable custom namespace conversion under the organization settings and points will be replaced with miles across the organization in Insights+.

Below images show how the UI labels change once the custom namespace feature is enabled.

Please note: The feature is now enabled for aviation-focused organizations initially on a pilot basis. We will be rolling out soon for other verticals over the next quarters.

To enable a custom namespace -

Go to organization settings.

Under Organization Setup -> Organization Profile

Click Edit.

Select Org Locale.



Click on "Enable Custom Namespace"



Once the settings are applied click submit.

Note : It takes 24 hours for the changes to take place across org.

Updated over 1 year ago