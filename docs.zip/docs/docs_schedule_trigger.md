# Scraped content from: https://docs.capillarytech.com/docs/schedule-trigger

Retro transaction template

Suggest Edits

The retro transaction template allows you to tag retro (old) not-interested transactions to customers and change it to regular transactions. This can occur for a variety of reasons, such as an error in the transaction process, a delay in the transaction being recorded, or a promotion being applied retroactively to a past purchase. For more information on retro transactions, refer to the documentation here.

Configuring retro transaction dataflow

To configure retro transaction dataflow, perform the below steps/actions:

In the Connect-to-source section Block enter the source server details where the source data is present and the location for saving the processed file. For the information on configuring this block, refer to Connect to source documentation

In the Decrypt data block, if the files are encrypted, enter the details to decrypt the data. For the information on configuring this block, refer to Decrypt data documentation.

In the Transform Data block, map the API fields with the source file. For information on how to map the fields, see Transform data.

It is mandatory to map the customerId, transactionId, oldType and newType fields with the file. The value of the fields newType and oldType will be NOT_INTERESTED and REGULAR respectively.



In the Connect-to-destination block, enter the API endpoint details. For the information on configuring this block, refer to Connect to destination documentation.

In the Trigger block, enter the details to schedule the trigger. See Trigger.

For troubleshooting information, refer to the troubleshooting section of the documentation.

Updated 11 months ago