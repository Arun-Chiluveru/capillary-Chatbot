# Scraped content from: https://docs.capillarytech.com/docs/campaign-use-cases

Use case

Suggest Edits

Creating a birthday campaign

A birthday campaign is a type of campaign that issues coupons to customers to celebrate their birthdays. This can be set up by creating a campaign and filtering customers based on their birthday month to issue the coupon. This helps customers receive a personalized discount or offer as a birthday gift, making them feel valued and appreciated.

Let us understand how to set up a birthday campaign where a brand needs to send out specific coupons to customers whose birthdays are approaching within the next xx days.

To create,

On your organization UI, open Engage+, and select New campaign.

Create a new campaign and configure the message.

On the Audience section, create an audience group.

On the New audience group window, perform the following:

a. Select Apply filter condition.

b. Select Next.

c. On the created audience window, select Filter.

d. From the drop-down menu, select User Profile > Demographic details > Birthday.

e. In the no of day section, enter the number of days you want to send out specific coupons to customers whose birthdays are approaching.

f. Select Apply.

g. Select Save group.



Select Continue.

(Optional) On the Content section, you can either create or select a configured creative / incentive to send to the customers.

On the Schedule section, schedule your message.

Select Send for approval.

The campaign will be sent to the respective product manager for approval. Once approved, your birthday campaign will be activated.

Updated 11 months ago