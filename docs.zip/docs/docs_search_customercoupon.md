# Scraped content from: https://docs.capillarytech.com/docs/search-customercoupon

CSV-To-XML-Converter

Suggest Edits

Enter the following details.

Field Description XML Top Header declaration of the XML file. This includes the XML version, character encoding, and so forth. XML file name The name of the XML file. XML Repeating Component The repeating elements of the XML file. This is the section of the XML file where the data is present. Input File Delimiter The file delimiter. This template supports commas (,) and pipes (%>%) XML Bottom The closing tags of the XML file.

Updated 30 days ago