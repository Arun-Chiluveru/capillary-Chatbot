# Scraped content from: https://docs.capillarytech.com/docs/create-call-task-template

Create call task template

Suggest Edits

Call tasks are the messages which are sent to the store staff. These messages are suggestions/instructions for the store staff.

To create a call task content, click the Campaign tab on Dashboard, and then click Create campaign. For details on campaign creation, see the create campaign flow.

Create a new call task content

In the Content section, click Add creative.

Navigate to the Call Task tab, and click Add new Call task.

Enter a Call Task title.

Enter a call task Message. Click +Add Label to use appropriate tags in the message.

Enter a description of the new call task. The description is useful for the store staff.

1032

To use the call task in the Store2Door app, check Use in Store2Door. You can see the preview of the message in the Store2Door app as shown in the following.

893

Click Done.

📘

Note

You can see a sample preview of your message on the right panel.

Updated 3 days ago