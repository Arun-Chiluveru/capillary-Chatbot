# Scraped content from: https://docs.capillarytech.com/docs/audience-reload-from-ftp

Company

Suggest Edits

Company Import

This profile lets you add parent company and child company to the org.

The following is the list of fields supported for the profile.

📘

No template configurations are required for this profile.

Supported fields Field name to be mapped with Datatype Company external ID External Id varchar Company name* Name* varchar Parent company external ID Parent Company External Id varchar Till code or store external ID* Till IUN Or Store Ext Id* varchar Company hierarchy code* Hierarchy Code* varchar

📘

The fields marked with * are mandatory.

Updated over 1 year ago