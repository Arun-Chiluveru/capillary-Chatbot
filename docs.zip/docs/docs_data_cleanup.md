# Scraped content from: https://docs.capillarytech.com/docs/data-cleanup

Loyalty Settings

Suggest Edits

These are the setting in the Loyalty+ module, which are present in the top navigation panel, right corner.

These setting are at an org level, and not at a program level.

Updated over 1 year ago