# Scraped content from: https://docs.capillarytech.com/docs/referral-programs

Configure Tier Downgrade

Suggest Edits

To configure tier downgrade, perform the following steps:

On Intouch, navigate to Menu > Loyalty+ > Programs.

In Programs, select the program you want to edit.

Select Edit Program.



Select edit icon.

In Edit tier, enable Validity.



From Downgrade to drop-down, select the desired option.

The drop-down menu provides you with three options:

One tier below

An appropriate tier based on eligibility

The lowest tier



Click Done.

Extend available points to the new cycle

If the expiry condition for reward currency is configured as a Tier based expiry date, then points earned in the respective tier will expire when the tier is downgraded or renewed after the renewal check.

Enabling this option allows customers to renew points, which will be renewed along with the tier after the renewal check.



Updated 10 months ago