# Scraped content from: https://docs.capillarytech.com/docs/line-faqs

Frequently Asked Questions

Suggest Edits

What happens if the data transformation fails during Audience Synchronization?

A failed transformation can delay audience updates on InTouch. Monitor the process promptly to ensure timely synchronization.

Are there any rate limits on the LINE Message API, and how should limits be managed?

Yes, the API has rate limits. Exceeding them can block requests. For more information, check the rate limit guidelines on the LINE developer platform.

What should be done if LINE user registration fails on InTouch?

Check logs for errors, verify details, and review webhook and integration settings. Reconfigure if necessary.

What are the best practices for configuring Gateway Weight, and how can it be adjusted?

Set the Gateway Weight based on target your audience and volume. You can adjust it dynamically based on campaign performance.

How are message templates managed in Capillary, and can they be reused?

Templates are managed within the Capillary Intouch portal under the Creatives section and can be reused across multiple campaigns.

Can multiple LINE source accounts be configured on InTouch? If so, how are they managed?

Yes, you can configure multiple LINE accounts in InTouch. Manage them individually under Channel Configurations. Refer to the Setting Up a LINE Source Account section for more details.

What steps should be taken if the integration fails due to incorrect Channel ID or Secret Keys

Verify and re-enter the correct Channel ID and Secret Keys from the LINE Developer Platform in InTouch.

Updated 8 months ago