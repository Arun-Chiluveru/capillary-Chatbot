# Scraped content from: https://docs.capillarytech.com/docs/home-page-tour

Home page tour

Suggest Edits

Post login, you will see a Home page. The Home page consists of several elements to help you find the key information about your products, programs, and links to product pages, tickets, support documentation, Capillary Academy, and much more.

The following sections provide detailed information on each section of the Home Page.

1427

Get Started

This section helps you get started with Capillary products. It provides useful links to relevant documentation or support content.

1600

Explore Features

This section provides links to powerful features across Capillary products. They could be major features that were launched recently or even some of the interesting older features.

1600

Loyalty suggestions

This section provides loyalty nudges, which help in taking the right actions for your loyalty programs. These are the same nudges that you see on the Loyalty+ landing page. Having them on the home page provides better accessibility to nudges.



Performance

This section shows the top level stats of the value delivered from the products. These are the same stats that you would see in the Loyalty+ and Engage+ landing pages.

1600

Quick links

This section provides links to live campaigns, Loyalty Programs, Member Care customer requests, and SMS credits view.



Help links

This section provides links to the support content. You can find links to access support documentation, tickets, and Capillary Academy.

1600

Access products/Workbench

You can access all the products like Loyalty+, Member Care, Insights+, and Workbench on the home page. Navigate to Select Product menu and select the desired option.

1893

Updated 8 months ago