# Scraped content from: https://docs.capillarytech.com/docs/optimizing-your-rewards-budget-catalog-inventory

Assigning Permission Set to Users

Suggest Edits

Organisation Owners have access to all permission sets by default, as they hold the highest level of privileges in the system. Admin Users receive their permission sets from Organisation Owners, while Standard Users can be assigned permission sets by either an Admin User or an Organisation Owner. Admin Users can only assign permissions that they have.

The permission sets can be assigned during the following scenarios:

User Creation When adding a new user, the organisation or admin owner can select the relevant standard or custom permission set(s) to be applied. The selected permission set(s) will define the user's access privileges.

User Update For existing Admin and Standard users, you can modify the assigned permission set(s) as needed.

Module Sub Module View Insights Reports ✔ Segments ✔ Export ✔ Settings ✔

Assign V2 Permission Sets

V2 permission sets help give access to users to view and perform different functions within the Intouch platform. These sets are designed to align with the user's roles and responsibilities within the organisation.

To Access User Permissions, follow these steps

Navigate to Organization Setup > User Management.

Click the three-dot menu (•••) next to the user and select Edit.



Step 2: Update Permission Sets

In the Permissions tab, click on Permission Sets.





A note on the Permissions Sets tab states: "Action required: Old permission sets will be discontinued soon. Switch to the new ones to avoid access issues."



Click "Show Old Ones" (if needed) to view existing permission sets. Deselect the outdated ones as needed and select the relevant V2 Permission Sets.

Click Save Changes to update the user's permissions.

Updated about 5 hours ago