# Scraped content from: https://docs.capillarytech.com/docs/user-segment-ei-attributes

Types of promotions

Suggest Edits

There are three different types of promotions:

Available without issue - Benefits are directly provided to customers on meeting the requirements.

Direct issue - Direct issue promotions, also known as LOYALTY promotions in the backend, are a type of promotion where a specific promotion is initially issued to customers based on their behavioural events or transactions. Subsequently, upon meeting the criteria defined in the promotion during their next transaction, the benefits are provided.

Enrol & Issue (Backend: LOYALTY_EARNING) - This promotion type follows a three-step process:

Enrollment: Customers are first enrolled in the promotion.

Issuance: The promotion is then issued to enrolled customers based on specific criteria.

Redemption of promotion/Earning the benefits: Customers receive benefits upon meeting the requirements outlined in the issued promotion.



📘

Note

By default, the promotion types Direct issue, and Enrol & Issue are not enabled for all the orgs. These are part of our advanced Loyalty promotions suite. To enable these features, please contact your Customer Success Representative.

Updated 6 months ago