# Scraped content from: https://docs.capillarytech.com/docs/transactions-standard-export-template

Use cases on data export

Suggest Edits

Use Case 1: Export customers that received messages of a specific campaign (without bounced, Control, etc)

Select the Contacted template, a standard fact template

In Filters, do the following to get customers contacted for a specific campaign Select Campaign Group > Campaign > Type the campaign name in the Search box > Select the campaign using the check-box > Click Include.

231

Use Campaign Delivery Status and do the following to further customers who received the campaign message. You need to select Delivered status and all its applicable sub-statuses (Opened, Clicked, Marked Spam, Marked Unsubscribed) to get the desired list Select the Campaign Delivery Status > Nsadmin Delivery Status > Select all possible statuses of delivered messages - Delivered, Opened, Clicked, Marked Spam, Marked Unsubscribed > Click Include.

229

Use Case 2: Exporting points that are going to expire on a specific date

Refer to the video for detailed explanation on how points that are going to expire on a specific date or month end work.

Updated over 1 year ago