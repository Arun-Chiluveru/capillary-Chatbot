# Scraped content from: https://docs.capillarytech.com/docs/offer-

Offers

Suggest Edits

Introduction to Offers.

Getting Started.

Coupon Management.

Using offers in Campaigns.

Event Notifications.

Reporting.

FAQ.

Updated 6 months ago

What’s Next

Introduction to Offers