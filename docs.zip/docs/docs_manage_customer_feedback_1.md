# Scraped content from: https://docs.capillarytech.com/docs/manage-customer-feedback-1

Invoke Neo Iteratively

Suggest Edits

The Invoke-Neo-Iteratively block allows you to import data from a Neo API and configure the number of times the API is invoked.



The following table lists the fields:

Field Description Enter url Select the Neo API from the drop-down menu. The drop-down lists Dataflows labelled as connectplus . Authorization Authorisation key for the API, if required. NEO API METHOD Method of the API. Supported values: GET and POST . Note: This block supports only POST calls that do not require any body parameters. Split Response Set the value to true using the drop-down to separate each array in a response. For example, if an API returns an array of objects, and each object has its own set of properties, setting the value to true will list each array as an individual response. API Iteration End Condition Conditions for terminating the API call. You can define a custom condition for terminating the API call. Max retries Number of times the API is called. There is no limit for the number of retries.

Updated 30 days ago