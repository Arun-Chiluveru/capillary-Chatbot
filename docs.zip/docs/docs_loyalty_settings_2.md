# Scraped content from: https://docs.capillarytech.com/docs/loyalty-settings-2

Tiers

Suggest Edits

Tiers also called slabs, are levels within a program that customers upgrade, renew, and downgrade based on their engagement with the brand. Each Tier offers unique benefits, with higher Tiers providing greater rewards.

Brands use tier-based programs to reward their loyal customers. Tier programs motivate customers to keep coming back and spending more. As customers move up the tiers, they get better rewards, which makes them happier and more likely to keep engaging with the brand.

📘

Note:

A program can have only one tier strategy.

Updated 11 months ago