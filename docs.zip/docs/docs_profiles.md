# Scraped content from: https://docs.capillarytech.com/docs/profiles

Profile : Current Store

Suggest Edits

The currentStore profile is used to check store level details. You can write rules based on the attributes provided in the table below.

ATTRIBUTE DESCRIPTION SUB ATTRIBUTES Link code Unique code of the store NA Learn More name Name of the store NA

Updated over 1 year ago