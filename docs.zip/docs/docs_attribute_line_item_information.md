# Scraped content from: https://docs.capillarytech.com/docs/attribute-line-item-information

Configuration for Badges

Suggest Edits

Custom Field Information for Badges

Grouping and Ranking of Badges

Updated about 1 year ago