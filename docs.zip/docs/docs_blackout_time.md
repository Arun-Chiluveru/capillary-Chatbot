# Scraped content from: https://docs.capillarytech.com/docs/blackout-time

Blackout time

Suggest Edits

Blackout time window

The blackout time window means in that window no communication will be sent to the brand’s users. And that specified is known as blackout time.

Example: let's take an example

To use this window click here

Updated over 1 year ago