# Scraped content from: https://docs.capillarytech.com/docs/member-care-new-ui

Convert JSON to CSV/Avro Format

Suggest Edits

The Json-to-Csv-Converter block enables conversion from CSV or Avro formats to JSON and from JSON to CSV.



To configure the Json-to-Csv-Converter block, follow these steps:

i. Select the file format to convert from in the Record Reader drop-down.

The available formats are:

Reader Description CSVReader Input data is in CSV format. AvroReader Input data is in Avro format. JSONTreeReader Input data is in JSON format

ii. Select the file format to convert to in the Record Writer drop-down.

The available formats are:

Writer Description CSVRecordSetWriter Export data to CSV format. JsonRecordSetWriter Export data to JSON. CustomerV2RecordSetWriter Export data to Customer V2 format.

iii. Enter the parameter to group by under the groupBy field. For example, if the API has a parameter called orgId, enter the value in the text field to group the responses by the organisation ID.

Updated 30 days ago