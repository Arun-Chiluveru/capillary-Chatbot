# Scraped content from: https://docs.capillarytech.com/docs/attribute-transaction-value

Introduction to Badges

Suggest Edits

Overview of Badges

Badges are a type of visual recognition used in loyalty programs to reward customers for their progress, specific actions or achievements. These serve as a form of gamification and a sense of pride and accomplishment within the user, reinforcing the targeted behaviours and boosting engagement.

Purposes and benefits

Customers want to build deeper relationships with brands beyond transaction and that’s where emotional loyalty comes into play. Customers are recognized and appreciated for the effort that they put in, the money they spend, and their loyalty towards the same brand. Hence, Badges tap into the emotional side of the customers making them hooked to your brand, giving a more fulfilling experience, moving beyond the realm of mere transactions and discounts.

Use cases

Travel and Hospitality Vertical



Fuel Vertical



Fashion and Retail Vertical



CPG Vertical



Sample End Customer (Cx) Journeys

New member/welcome badges

Cx registers in brand’s loyalty program

Upon successful registration, Cx is automatically awarded the “New Member” badge

Cx receive the associated benefits with the badge.

Cx receives a notification about earning the badge and associated benefits

A badge is displayed in Cx’s loyalty program account

Cx feels proud and accomplished after receiving the badge on registering and continues to engage with the brand to receive more badges

Activity based badges

Cx completes specific actions such as making a purchase, writing a review, or referring friends.

Each completed action unlocks a new badge, such as "First Purchase," "Reviewer," or "Referral Champion."

Cx is notified of their earned badges and can view them in their loyalty program account.

Customer views for Badges

Customers can see the available and earned badges in their mobile app. Clicking on a particular badge also gives information about what the customer has to do to earn the badge, the benefits associated with the badge, the earning period and other details.





Customers can proudly share their badges on social media and become advocates for your brands. They feel happy to be recognized by the brands which makes them feel connected to the brand.



Updated 11 months ago