# Scraped content from: https://docs.capillarytech.com/docs/credit-management

Configuring Relations

Suggest Edits

Relations in Neo define how blocks connect and determine the dataflow path during execution. They work like a switch statement, where each condition directs the execution to the next block based on the dataflow logic. You can define relations using DAO functions or JavaScript. All Neo blocks support Relations.

By default, Neo provides two path relations using DAO functions:

isSuccess() – Executes when the operation succeeds.

hasError() – Executes when an error occurs.

You can add, edit, or delete these default path relations based on your requirements. However, at least one path relation must always be defined.

Adding a Path Relation

To add a path relation,

Click + Add Path.

In Path Relation, enter the condition to be checked.

Updated 13 days ago