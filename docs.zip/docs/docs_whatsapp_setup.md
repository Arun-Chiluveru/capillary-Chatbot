# Scraped content from: https://docs.capillarytech.com/docs/whatsapp-setup

WhatsApp setup

Suggest Edits

WhatsApp Client Onboarding



Above mentioned is a 5 step process in which a client is onboarded on WhatsApp and is required before even being able to send the first message through this channel.

Step 1:

Requirement of documents to be shared with the client to capture the required information from them and share it with the BSP. Here is the link to a folder containing all the required documents, pricing and checklists to be asked from your brand.

Step 2:

Configuration through Meta account.

Step 3:

OTP confirmation.

Step 4:

Raise a ticket with the backend or sustenance team to enable the integration and provide them with the following three parameters:

WABA ID or Account SID

Auth token or API Key

WhatsApp Sender ID or Messaging Service ID

1. WABA ID / ACCOUNT SID: To be requested from and shared by the BSP's (Tanla/Twilio/other) POC to the CSMs, mostly on a mail.

2. Auth token / API Key: Following are the steps to retrieve auth token for Karix/Tanla:

Visit the Karix lounge

Input the username, which is the Account name as received from the BSP's mail.

Click on Forgot Password. Enter your Capillary mail and brand phone number to generate the password.

Thereafter, generating the password login into the Karix Lounge and click on API Keys as shown below,



The Alphanumeric mentioned under Keys is the Auth Token/API Key, while the Key Name should be saved for later use (For adding DLT Endpoint).



3. WhatsApp Sender ID / Messaging SID: This is the WhatsApp phone number of the client's official account and it is the same shared to the BSP's (Tanla/Twilio/other) POC when filling in the onboarding details.

Step 5:

Add the Connection IDs

Org settings -> Channel configurations -> Search for Whatsapp -> Add relevant Connection IDs as provided by BSP

Access token

Source Account ID

Complete the account setup through the organisation settings in the product UI.

Adding the DLT Endpoint in the Karix UI

Go to the Karix Portal.

Use the same credentials for login as used above for the Karix Lounge.

On the left-hand side choose WhatsApp Campaigns > Webhook Config > Delivery Rule > Create New.

Click on Create New and add the DLT end point URL in the first space bar. URL to add: "https://dlrs.incrm.ccdelivery.capillarytech.com/karixwhatsappbulk"

Under Header, add the Key retrieved above from the Karix Lounge and Value would be the Auth Token/API Key.

Next choose the following settings and save them,



Note

For a better understanding of WhatsApp, watch the easy-to-learn training on our academy.

Gupshup integration for Whatsapp communication

You can use integrate and use Gupshup Whatsapp BSP to send communications through Whatsapp from Capillary platform.

To integrate, perform the following:

Onboarding

Enter the below details in the onboarding details form.

Business name and FB manager ID

Country Details and Use cases

WhatsApp Phone numbers ( UAT and PROD )

WhatsApp Business profile setup - Display name, Type of company, Industry etc.

Callback URLs

Business Contact Details

If the Live Agent Dashboard feature is required, enter the following details in the Live Agent Dashboard form:

Primary use cases and WhatsApp number

URL Preference

Email id of the admin

Whether the Gupshup bot is enabled on the clients number. If yes, API key and bot name should be mentioned

CRM used by the business

If the Instant Bot Enablement feature is required, enter the required details in the Keyword based Responses form. This feature allows businesses to interact with their clients via WhatsApp 2-way messaging. This feature is intended to reduce the time for a business to configure a bot to interact with its customers.

Updated 8 months ago