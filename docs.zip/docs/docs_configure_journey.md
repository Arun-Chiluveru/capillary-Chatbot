# Scraped content from: https://docs.capillarytech.com/docs/configure-journey

Configure journey

This section provides you with information on how to configure a journey.

Suggest Edits

To configure a journey perform the following steps:

1. Configure entry trigger

An entry trigger defines which customers will enter the journey.

An entry trigger is used to differentiate between customers and move them onto different entry paths based on their behavior to enhance their engagement with the brand. A user enters the journey only after the entry condition is satisfied by them.

Key features:

Enables brands to segregate their customers based on their transactional and behavioral patterns

Enables brands to create hyper-personalized journeys for their customers which in turn results in higher customer retention.

Customer behavior can be either transactional or behavioral, and brands can configure their exact requirements within the entry trigger.



User events trigger

In a User event trigger which is also called a user-initiated trigger, the customer enters the journey based on any transactional or non-transactional activity (behavioural events). With the help of user events, brands can include multiple paths within a journey depending on customer activity.

Transactional events are standard whereas behavioral events are configurable by individual brands to suit their requirements. While adding transactional triggers, the brand has to choose between the following events:

Transactional events

Event Name Description Customer Registration Triggers a user's entry into a journey based on the customer registration event. Configure the associated rules and actions as needed. Current Transaction Triggers a user's entry into a journey when a transaction is completed . Coupon Redemption Triggers a user's entry into a journey when a coupon is redeemed . Use this event to configure actions based on coupon redemption. Customer Update Triggers a user's entry into a journey based on the customer update event. Reward Issued Triggers a user's entry into a journey whenever a reward is issued . Target Enrollment Triggers a user's entry into a journey when they are enrolled in a target . Target Value Achieved Triggers a user's entry into a journey when the predefined target value is achieved . Partner Program Linked Triggers a user's entry into a journey when they are linked to a partner program . Promotion Issued Triggers a user's entry into a journey when a promotion is issued to them . Points Issued Triggers a user's entry into a journey when points are issued . Coupon Issued Triggers a user's entry into a journey when a coupon is issued . Tier Upgraded Triggers a user's entry into a journey their tier is upgraded . Tier Downgraded Triggers a user's entry into a journey when their tier is downgraded .

Behavioral events

These events include both standard as well as customized events. The standard events include events based on attributes such as price, quantity, productType, cardId, and productName. For more information on behavioural events, see behavioural events.

Further, you can also define conditions, filter the adience and define differnt patths accordingly.

Example Use Case

Requirement: The brand wants to configure a journey where the user enters the journey immediately upon being registered as a customer. Solution: Use the Customer Registration event as the entry trigger for the journey. This event is triggered when a new user completes the registration process and their customer profile is created.

Requirement: Brand wants to configure a journey where the user enters the journey when they achieve a target set as part of the loyalty promotion they are enrolled in. Additionally, only users whose whose total transaction amount is greater than 10000 should enter the journey. Solution: -

Use the Target Value Achieved event as the entry trigger for the journey. This event is triggered when a user reaches the target value defined as part of their loyalty promotion.

Define an additional condition to filter users based on their life time transaction amount: Set the Lifetime Transaction Amount in the entry criteria filter.



Audience list trigger

Brands can add a selected audience list to a journey. They can either choose an already created list from the audience manager or they can click on create audience group

Configuring an entry trigger

On the Journey canvas page, click Entry trigger and define the entry trigger for the customer to enter the journey.

Select the type of entry trigger - User event or Audience List

For User events trigger, perform the following:

From the Who have performed the event drop-down, select the event - Current Transaction, Coupon Redemption or Customer Registration

Click +Add entry paths. This defines further criteria for the customer to enter the journey.

Click +Add condition and define the conditions.

You can click +Add condition to add further conditions and combine them with the AND operator.

Click Add group to add conditions and combine them with the OR operator.

For including Stores in the condition, you also have the option to upload a .csv file with the stores list. See Uploading store CSV

To create further conditions for the filtered customers, click + Path and define the conditions. Note: In case of multiple paths, the journey will proceed to the 1st matching path condition from top to bottom.

For the Audience list, perform the following

Click +Audience group.

Select an existing audience group or create an audience group. To create a new audience list, refer to Audience Management. You can select multiple audience groups.

Click Done.

If you want to exclude customers from a specific group entering the journey, enable Exclude Audiences, click +Audience Groups and select the audience group.

To change the entry trigger type, click Change

Click Done

To edit an entry trigger, hover on the entry trigger block and click the edit icon.



2. Add the building blocks

For information on building blocks, see Building blocks of a journey.

3. Schedule the journey

Click on the Schedule trigger card below the entry trigger. A side-bar will be displayed wherein which start and end of the journey can be configured



In the Starts section, there are two options.

Immediately after approval - Starts the journey as soon as it is approved by the respective stakeholder

On a specific date- Starts the journey from a specific day. The date can be added within the calendar that is displayed once this option is selected



In the Ends section, there are two options

Never - Runs journey continuously and never ends.

On a specific date- The journey ends on a specific date. The date can be added to the calendar that is displayed once this option is selected.

4. (Optional) Configure exit trigger

An exit trigger is to remove a customer from a journey if they satisfy a given condition. Brands can configure transactional and behavioural events that can cause a customer to exit a journey. This ensures that customers do not get spam/out-of-context engagements. This leads to a higher click rate on engagements and in turn leads to successful conversions.

Use Cases

A brand wants to target customers who have purchased shoes from them and want to motivate them to buy clothes as well. If a customer has already purchased from the clothes category, they should not receive promotional messages to buy clothes which can be configured in the exit trigger.

Brands want to motivate users by asking them to upgrade to members. Customers who purchased the membership should be exited from the membership promotional journey

Adding an exit trigger

In the journey canvas page, click Exit trigger.

In the Define: Exit trigger page, select how you want to make a user exit a journey. Here, two ways to exit a customer are supported

Filtered audience exit

User Event

The two types of exit triggers have different use cases, determining which to use depends on the situation.

When to use a Filtered Audience exit

Use Case: The brand has used the Audience list as an Entry trigger in Journeys. The requirement is that anyone who does not satisfy the audience list at any point in time should get exited from the journey.

How to use a Filtered Audience Exit:

To enable this, Toggle the option Filtered Audience exit to “ON”. By default, it will be set as No.

If this is enabled, customers will exit the journey if they no longer satisfy the audience-filtered criteria configured in the entry trigger.

📘

NOTE

This can be used only when the entry criteria is set as Audience list.



When to use a User Event-based exit

Use Case: Brand has used a User-based event as an Entry trigger in Journeys. The requirement is that when a particular customer does any event (standard event such as transaction/coupon redemption) or a behavioural event, they exit from a journey.

How to use a User Event Exit trigger:

Select the User Event Exit trigger and Click Next.

From the Who have performed the event drop-down, select the event. You can select either transactional or behavioural events.

Define the conditions for the customer to exit the journey. This is similar to the defining conditions in the entry event. You can define only one condition/path for the exit trigger.

Click Done.

To edit the exit condition, hover over the block and click on the edit icon.



How to reset an exit trigger

This feature enables brands to reset their exit trigger within a journey. With this feature, a brand can remove an existing condition from its journey that allows customers to exit the journey.

Use Cases

A simple reset button not only allows brands to remove a pre-configured existing trigger but in case of multiple triggers, brands can remove all of them with the click of a button. It saves time and the hassle of removing each condition manually.

Resetting an exit trigger

Once the journey canvas is opened, navigate to the exit trigger.

Upon hovering over the exit trigger, a reset icon will appear.



Click on the reset icon to reset the entire configuration of the exit trigger.

5. Configure journey settings

You can configure the below two settings for the journey.

Entry settings

Customer entry to the same journey

This feature allows brands to enable the same journey for customers several times if they match the entry condition. It enables consistency of engagement and targets customers at the right time. This helps to:

Reduce the hassle of recreating the same journey multiple time

Maintain consistency in engagement

Just once - Allows the customer to enter the journey only once. Example use case: A welcome email to a new customer of a brand. In this scenario, the user is allowed to enter the journey only once during onboarding.

More than once - Allows the customers to enter the journey multiple times. There is no limit set.

Example use case: A "Step Challenge Journey" rewards users for walking 10,000 steps daily for five consecutive days. The journey includes:

An email encouraging participation.

Daily reminders to log steps.

A reward upon successful completion. If users complete the challenge and later rejoin a new session of the challenge, they can re-enter the journey multiple times as long as they meet the entry conditions (e.g., signing up for a new challenge). You can use the search option and search for the customer who has entered the journey. The search result displays the date and time at which the customer entered the journey.

To save the changes, click Save.



Allow global control customers to enter the journey

You can enable this to include the Control audience (a control audience is a group of individuals who are intentionally left out of a campaign, in order to serve as a group for comparison) in the journey. By default, the control audience is not included in the journey.

Communication Settings

You can enable the toggle switch Ignore subscription status for all communication channels to send messages including transactional messages to all customers, even if their promotional subscriptions are configured to not receive messages. This bypasses the promotional subscription status settings.



Link Tracking Settings

You can enable the toggle switch to shorten URLs in communication messages.



6. Send Journey for Approval

🚧

Before sending a journey for approval, ensure the following:

New Credit management system is enabled for your org. If it is not, kindly raise a ticket to the Sustenance team.

Credit rates for all channels that are used for communication in the journey are configured.

After you have configured steps 1 to 5 above, you need to save the journey and send it for approval by clicking on "Send for approval".



Once the journey has been sent for approval, the approver can approve the journey and the journey will go live as per the schedule configured in Step 3 above.



Approver can also reject the journey if the journey needs certain modifications. In that case, journey will go to "Rejected" state and you will have to make changes to the journey by clicking "Edit"



Updated about 1 month ago