# Scraped content from: https://docs.capillarytech.com/docs/create-viber-content

Create viber content

Suggest Edits

Viber is an app-based instant messaging platform. You can create a new message or use existing templates and customize the message content as required.

You can create channel content for a campaign while creating a message. To navigate to the Content section, see create a campaign.

To navigate to the Viber message creation page, follow these steps.

In the Content section, click Add creative.

Navigate to the Viber tab

1147

Create a new Viber message or select from the existing template(creatives).

To create a new Viber message, follow these steps.

Click Create new.

1147

Enter the message name.

In Text Message, enter the message content (up to 1000 characters) text. You can also add labels to the text message such as coupon code, customer's full name, store name, store address, and more. You can also use Liquid language in the messages.

In Image, upload the image from the local device or gallery if required. The image you upload needs to have the following properties.

Image dimension: 300 x 400 pixels.

Image size should not exceed 10 MB.

To include links in the message (if required), do this.

In Button text, enter the label name (up to 20 characters) for the button.

In Button URL enter the URL to open when the recipient clicks on the button. Only secured URL is supported ( https://...).

Click Done.

1040

To create a Viber message using an existing template, follow these steps.

Select your preferred template from the list. You can also use the template name in the search option to fetch a specific template.

Modify Text Message, Image, and Button(text and URL) if required.

Click Done.

Updated 6 months ago