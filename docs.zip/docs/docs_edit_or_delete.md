# Scraped content from: https://docs.capillarytech.com/docs/edit-or-delete

Edit or Delete Custom Report

Suggest Edits

Edit Report

Normal, Migration, Funnel Report

You can modify custom reports to change the alignment of charts, add or remove charts and alter the date range.

To edit a custom report:

In Insights+, from the left panel, expand the Reports drop-down and click on All Reports.

Locate the report from the list, or type the report name in the Search reports box. You can also search the report using the KPI (used while creating the report) or chart type or report type (normal, migration, funnel and external). Click on the desired report.



Click the More Options icon > Edit.



On the Edit report screen, click Next.

Click +Add/remove charts and select the chart you want to add/ remove.





Click Done.

To align the charts, drag a chart and drop it at the desired position.



Click Save Report to save your changes.

External Report

To Edit, perform the following:

Open the report > click More Options > click Edit.

Make the required changes.

Click Next .

Click Save report.



Copying Databricks Notebook URL

To copy a Databricks notebook URL, from the Databricks homepage, navigate to your Workspace > Users > click on the report and copy the URL.



Delete Report

Prerequisite

You can delete a report only if you have edit level access or admin access.

To delete a custom report:

Open the report that you want to delete.

Click the More Options icon > Delete.



Click Yes to confirm.

Updated 7 months ago