# Scraped content from: https://docs.capillarytech.com/docs/configure-gift-vouchers

Configure gift vouchers

Suggest Edits

This section provides detailed instructions on how to configure each type of gift voucher. According to the type of voucher that you want to create, navigate to the respective section after Step 6.

You can have an overall 250 active promotions for an org (all types of promotions). However, it can be increased based on the requirement.

To create a Gift Voucher, follow these steps.

Open the campaign to add a gift voucher, navigate to the gift voucher tab.

Click Create voucher.

In Vouchername, enter a name for the voucher.

In the Voucher description, enter a brief description of the voucher.

In Voucher Duration, set the start date and end date of the voucher using the calendar boxes.

In Voucher type, choose the desired voucher type.

Loyalty Gift Vouchers

After selecting the voucher type, there will be various configurations that allow you to have a better control over the gift vouchers.

Voucher expiry & additional information

Define the expiry and add custom information required for the voucher

The first option allows you to set an expiry duration for the voucher.You can either select Along with voucher or set a number of days from issual of the voucher.

You can also add custom fields that are required for the voucher.



Cart Conditions and benefits

Define cart, store conditions and the maximum benefit on the cart.

You can define the cart evaluation condition for customers to qualify for the voucher and the actual benefit the customers could get with the voucher.

Enter the Voucher value and add in the condition for the voucher to get issued of any.



Cart Conditions

Click on add condition

Select whether you want the conditions to be applied on cart or on store.

On cart



Amount



Add condition to include the cart if the amount is greater than the required amount.(fill the amount according to the requirement)

To add the additional conditions click on ‘Additional condition’

Either you can select attributes or you can upload SKU files.







You can also add the condition based on the store.(Choose add condition to put up conditions on both)



Count of items in the cart

Issual settings

Set validations to be done at the time of issual of the voucher.

Enable Customer activation required to allow customers to manually activate the voucher to auto-apply for a transaction. For example, you can allow customers to activate 5% off on groceries. Whoever activates the offer will get flat 5% off on grocery items in their next transaction.

You can the maximum no. issual per customer. For example the limit is 3, so each customer can be issued the same voucher 3 times.



This is applicable only for Loyalty voucher, Loyalty earning voucher, and Rewards voucher.

Redemption settings

Configure redemption limits for the customers

Configure redemption settings for vouchers by the customers.The number of times a voucher can be redeemed by a customer is by default set as 1 and cannot be changed. Set the number of earn instances that can be redeemed in a single cart.



Communication

Set expiry reminder

You can send out a reminder message to customers for their vouchers to get expired. Select a creative in which you want to send out the message.

We have 3 channels integrated here. i.e. SMS, E-Mail, Push Notifications



Click Save and save all the settings.

The voucher is created. You can also hover over the three dots after the voucher is created and change the settings as required.

Loyalty earning gift vouchers

Earning criteria

Select type of activity on the basis of which you want the customer to earn. It can be of 2 types -

Single activity

Customer who are eligible for earning this gift voucher, who have performed the activity - (a)Transaction,(b)Registration,(c)Profile update

You can add conditions on

Stores

Event

Restrict earning period :Select when you want the restrict this earning period either 'along with the voucher' or 'x days from issual'.

Milestone based

Select the milestone group to whom you wanted to give gift voucher.

Under that select the target which you want to achieve.

Number of times a customer can earn the voucher

Here you can select for how many times you want the customer to earn the voucher.



Reward linked gift vouchers

Earning criteria

Set the no. of times for which the customer can earn the voucher



Communication

You can communicate with the customer by adding creative on earning.

You can use SMS,EMail and Push notifications.



Updated over 1 year ago