# Scraped content from: https://docs.capillarytech.com/docs/reporting-custom-report

Custom Report

Suggest Edits

Custom reports empower users to generate tailored reports that cater to their specific requirements and needs. Four types of custom reports can be created: Normal, Migration, Funnel, and External reports. These reports are immensely beneficial for tracking and analyzing business performance.

Updated 10 months ago