# Scraped content from: https://docs.capillarytech.com/docs/introduction-to-engage

Introduction to Engage+

Suggest Edits

Engage+ Overview

Capillary Engage+ is a marketing automation solution that helps to create significant and personalized multi-channel marketing campaigns. You can create a campaign for different marketing objectives, such as Sales promotion, New Store openings, Brand anniversaries, Birthdays, and many others.

Engage+ lets you reach out to your customers over direct channels such as email, SMS, WhatsApp, and Line and social media channels such as Facebook. You can also trigger messages to InStore outlets. It is equipped with AI-powered filters for more personalized and smart targeting.

Updated over 1 year ago