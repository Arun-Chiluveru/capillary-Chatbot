# Scraped content from: https://docs.capillarytech.com/docs/group-loyalty

Create Tiers and Configure Tier Upgrade Conditions

Suggest Edits

Creating a tier

To create and configure tiers, follow these steps:

On Intouch, navigate to Menu > Loyalty+ > Programs.

In Programs, select the program you want to edit.

Select Edit Program.



Create a base tier:

Navigate to the Tiers tab. You will see a default or base tier.

Select Edit icon to modify the name of the tier.



Name the tier.



Describe the tier in brief.



Select an appropriate color for the tier if required.

📘

You can configure each tier with a color of your preference.



📘

You cannot set conditions for the default tier.

Review the Changes and add necessary details.



Click Done to save.

Configuring tier upgrade

From the second tier that you create, you need to configure the eligibility criteria for the tier upgrade and define the upgrade condition for each tier. This needs to be done by going to the Advanced Settings tab.

📘

The eligibility criteria type that you set for tier upgrade remains the same for all the subsequent tiers that you create.

Make sure you create tiers in sequence. You cannot create a new tier between existing tiers and cannot delete an existing tier.

Click Create New Tier and perform the following:

Name the tier.

Describe the tier.

Select an appropriate color for the slab if required.

In Edit tier, select Go to advance settings.

In Eligibility Criteria, select the base consideration for tier upgrade.

Current points

Lifetime points

Lifetime purchases

Tracker value - A minimum of one tracker needs to be available for the Tracker value option to be available.

In Upgrade type, select type of tier upgrade. This is applied when a customer fulfills the eligibility criteria.

Issue points and then upgrade to the next tier

Upgrade to the next tier and then issue points

Issue points, upgrade tier, and then issue remaining points

Select Add Secondary Criteria , to add another eligibility criteria. For example, if you have the primary eligibility criteria on lifetime purchases, you can also add another tracker value.



Select Done.

Validate downgrade conditions for a return transaction

Enabling this option allows you to downgrade a customer if the customer returns the transaction that upgraded the customer to a higher tier.



Updated 7 days ago