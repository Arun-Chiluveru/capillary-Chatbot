# Scraped content from: https://docs.capillarytech.com/docs/using-offers-in-campaigns

Using Offers in Campaigns

Suggest Edits

You can use the offers created in Offer Management for other services such as campaigns, loyalty, or any third-party service. This article explains how to consume the available offers in Loyalty and Campaigns. Note: The offer once consumed by a service is not available to use for any other service.

Assign Offers in the DVS (bounce-back) campaign

You can claim multiple offers in a DVS campaign and use them as needed based on the context. Offers claimed for a specific campaign are exclusively linked to that campaign and are not accessible for other outbound campaigns.

Note: The DVS (Bounce Back) campaign is set up in the old campaign manager.

Refer to the following steps to use offers in the DVS campaign:

Navigate to engage -> campaign. Click on Open old campaign manager.

Click on New Action.



You will see options for Adding a new coupon series and claiming a new coupon series when defining rules and actions.

To create a new offer within the Campaign module go to the Campaign module and click the Create Offer.

Complete all required fields as specified in the Create Offer part.

To use existing offers click Claim Offer.

Select offers that you want to use for DVS Campaigns and click Claim.



You can see all the offers claimed for DVS in the drop-down.

select the desired offer for each condition and click Submit.



Assign Offers in Outbound Campaign

You can claim only one offer in an outbound campaign. An offer claimed by an outbound campaign is exclusively associated with that campaign and not available for other outbound campaigns. Refer to the following to use offers in the outbound campaign:

Refer to the following to use offers in the outbound campaign:

Navigate to Engage -> Incentives.



To create a new offer within the campaign module: Click "Create Offer" and follow the steps outlined in the "Create Offer" section. These offers will then be visible within the Campaign module.

To use existing offers:

Select New campaign and follow the steps outlined in the "Create campaign" section.

select content -> Add incentives -> Add offer



Select the offer that you want to use.



Click on Claim.

Assign offers in the Loyalty Program

You can claim multiple offers in a Loyalty Program and use whatever is required based on the context. Offers that are claimed for a Loyalty Program are associated only with that loyalty program and are not available for any other services.

Refer to the following steps:

Navigate to Loyalty->programs->offers.



Click Create Offer To create a new offer within the Loyalty Program and follow the steps specified in Create Offer. These offers will be visible only within the Loyalty module.



Click Claim Offer To use existing offers. Select the offer that you want to use and click Claim.



📘

Note

You can choose the preferred offer rule when configuring rule sets.

Updated 6 months ago