# Scraped content from: https://docs.capillarytech.com/docs/points-deductions

FAQs

Suggest Edits

Loyalty Programs (Single & Multi-Loyalty)

Tiers

Points

Trackers

Return transactions

Points only for the net amount (not on delivery fees, taxes, etc..)

Is there a functionality to set across the board for all transactions not to include delivery fee and tax value to be included as points?

Answer:



Updated over 1 year ago