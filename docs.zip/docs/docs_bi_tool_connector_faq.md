# Scraped content from: https://docs.capillarytech.com/docs/bi-tool-connector-faq

Loyalty details

Suggest Edits

The Loyalty tab on the Customer Singe View page shows the complete loyalty summary of the customer.



Overall points summary

The Overall points summary tab shows current points, lifetime points, redeemed points, and expired points , return points, adjusted points, promised points and lifetime purchases of the customer.



Programs (program level details)

In the Programs tab, you can see the loyalty details of the customer for each program. By default, the selected loyalty program will be the org-level program.

If your org is MLP enabled, you can create individual programs based on zone, concept, or cards. You can toggle between these programs to see more details about each program.

The selected program will show the following details:

Tier Details: It shows the tier details for the selected program like what steps are needed to upgrade the tier, the current tier, and many more.



Program Points Summary: It shows a points summary of the selected program. You can see details of all the types of available points like current points, lifetime points, redeemed points, return points, adjusted points, and promised points and lifetime purchases. Clicking on View Detailswill redirect you to the Incentivestab where you can see the details like points issued, redeemed time and the event associated with the points.



Trackers

Clicking the Trackers dropdown shows the trackers that are currently active for the selected user profile.



Coalition Loyalty

The Coalition Loyalty dropdown shows all the active coalition programs for the selected user profile. Coalition programs are the programs created outside Capillary based on partnerships with some external brands or partners, who have their own loyalty program.



Supplementary Membership

You can see the details of active supplementary programs the customer is associated with. Supplementary programs are small loyalty programs that run along with loyalty programs but for a shorter span. A customer can enroll in more than one supplementary program at a time.

999

Targets

The Targets dropdown shows the target loyalty details set for the customer. You can choose the different target groups of the customer, and the target achievement for different periods.



Updated over 1 year ago