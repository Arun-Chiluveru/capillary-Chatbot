# Scraped content from: https://docs.capillarytech.com/docs/time-personalization

Time personalization

Suggest Edits

So by implementing time personalization in our campaign we can target our customers in the time slots when they are most likely to respond.

let's say there is a set of customers who prefers to respond in the evening and based on that we can create various time slots and can send communication to them according to that time slot.

Steps to use Time personalization

In the message, creation flow go on step 3 the "Schedule" section.

Select 'On a specific date'



Now select the specific date and specific time.



📘

The time personalisation can only be configured when someone schedule the message to be sent 'on a specific date' in the message schedule section.

Now toggle on the Time personalization option. Messages will be delivered on a day and time when a customer is most likely to read them.



You can set the no. of days up to 7 from that message's approval date.

After setting this you can send it for approval.

Updated over 1 year ago