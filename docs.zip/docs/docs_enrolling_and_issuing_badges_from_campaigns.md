# Scraped content from: https://docs.capillarytech.com/docs/enrolling-and-issuing-badges-from-campaigns

Customerglu games

This page provides you with information on configuring games on CustomerGlu.

Suggest Edits

Integration documentation

Click here



Configuration documentation

Click here



Sample game experience

Roll the dice : click here

Daily spin the wheel : click here

Spin the wheel: click here

Quiz: click here

Personality quiz: click here

New streak: click here

Multi-step: click here

Survey: click here

Slot Machine: click here

Gift box: click here

Scratch and Win: click here



Gamification Inspiration Playbook

Click here



CustomerGlu offerings

Click here



Setting up rewards and incentives

On the Capillary loyalty platform, you can create a variety of rewards, such as badges, points and coupons. These rewards are redeemable for real-world prizes or virtual items. Incentives can be set up to encourage players to participate and reach specific goals. This can be achieved using behavioural events in Loyalty.

Brands can set up the game and encourage customers to play it using any of the following methods:

Scanning the QR code

Sending an email containing the game URL

Playing the game within the app

To configure a game and reward the customer, follow these steps:

Set up the games on the CustomeGlu platform.

Configure behavioural event in Loyalty and link it to the eventname on CustomerGlu. For information on configuring behavioural events, refer to the Behavioural event documentation.

Configure a writeback URL in CustomerGlu to automatically trigger the configured behavioural event whenever a customer plays a game.

Record the relevant data generated during gameplay and use webhooks to transmit this data to the Capillary platform.

Set Up Rules and Targets in Loyalty Events. Perform the following:

Navigate to Loyalty events.

Locate the configured behavioural event.

Set up rules and targets for specific customers.

Upon meeting the specified criteria, customers will automatically receive their rewards (points, coupons, badges etc.) in the Loyalty program.

Tracking the behavioural events:

You can see the history of Behavioral Events data of the customer on Membercare. For more information, refer to the Member Care documentation.

Updated 7 months ago