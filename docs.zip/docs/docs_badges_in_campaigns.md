# Scraped content from: https://docs.capillarytech.com/docs/badges-in-campaigns

Badges in campaigns

Suggest Edits

You can add badges as an incentive when configuring a campaign. For information on configuration, refer to the documentation on issuing badges in campaigns.

Updated 8 months ago