# Scraped content from: https://docs.capillarytech.com/docs/attribute-discount

Getting Started

Suggest Edits

Viewing Badges

Enabling & Creating a Badge

Glossary of terms

Updated about 1 year ago