# Scraped content from: https://docs.capillarytech.com/docs/reject-message

Reject message

Suggest Edits

Once a campaign and a message are created, the message is sent for approval. The campaign and the associated message (awaiting approval, approved, stopped, completed rejected) are displayed under the campaign tab. The user with a message-approving privilege role can edit, approve, stop and reject a message.

To reject a message, refer to the following -

1084

On the dashboard click the Campaigns tab.

Search the campaign, and then click on it.

Click on the message that you want to reject.

Preview the message details and then click Reject.

697

The message status will be changed based on the message delivery schedule.

980

Updated over 1 year ago