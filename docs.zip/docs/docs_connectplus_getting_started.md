# Scraped content from: https://docs.capillarytech.com/docs/connectplus_getting_started

Coupon redeem template

Suggest Edits

The coupon redeem template allows you to redeem active coupons of a loyalty customer.

Configuring coupon redeem dataflow

To configure coupon redeem dataflow, perform the below steps/actions:

In the Connect-to-source section Block enter the source server details where the source data is present and the location for saving the processed file. See Connect to source.

In the Decrypt data block, if the files are encrypted, enter the details to decrypt the data. See Decrypt data.

In the Transform Data block, map the API fields with the source file. For information on how to map the fields, see Transform data.

🚧

Make sure that you include at least one identifier detail, such as a mobile number or email address. At least one identifier value is mandatory.

In the Connect-to-destination block, enter the API endpoint details. For this template the API /v2/coupon/redeem, is used. See Connect to destination.

In the Trigger block, enter the details to schedule the trigger. See Trigger.

Updated over 1 year ago