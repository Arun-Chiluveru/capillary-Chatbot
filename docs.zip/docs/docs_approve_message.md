# Scraped content from: https://docs.capillarytech.com/docs/approve-message

Approve message

Suggest Edits

Once a campaign and a message are created, the message is sent for approval. The campaign and the associated message are displayed under the campaign tab. The user with a message-approving privilege role can approve or reject a message.

To approve a message, refer to the following.

986

On the dashboard click the Campaigns tab.

Search the campaign, and then click on it.

Click on the message that you want to approve.

Preview the message details and then click Approve.

698

The message status will be changed based on the message delivery schedule.

1108

Updated over 1 year ago