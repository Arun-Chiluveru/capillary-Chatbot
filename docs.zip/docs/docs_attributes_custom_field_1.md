# Scraped content from: https://docs.capillarytech.com/docs/attributes-custom-field-1

Enrolling and Issuing Badges from Campaigns

Suggest Edits

Enrolling customers in a Badge through Campaign

To enrol your customers in a Badge through a Campaign, follow the below steps:

Go to Campaigns > New Campaign> Create a message.



Navigate to the Creatives+Incentives section and click on Add Incentives > Enrol Badge.



From the LIVE and UPCOMING badges list, select the Badge in which you want to enrol the audience. Make sure you are selecting only ACTIVE badges and the badge end date doesn't end before the campaign duration. Note: All the badges, regardless of ownership, are displayed. The ownership of badges indicates the module where the badge will be used. For example, Loyalty, Loyalty Promotion, Journeys, etc. This is defined during the creation of a badge. You can also select New badge and create a new badge if required. Only Enrol & Issue badges can be created and owner type can be any.



If you have selected any Badge as an Incentive, you need to add at least one tag related to the Badge such as the Badge expiry date OR days until expiry. To add the label, navigate to Add creatives > Select the creative > Add Label > Badges.



Note: Adding an expiry label is not required for badges that do not have an expiry.



Issue badges to customers through Campaign

How to issue badge to customers?

To issue badges to your customers through a Campaign, follow the below steps:

Go to Campaigns > New Campaign> Create a message.



Navigate to the Creatives+Incentives section and click on Add Incentives > Issue Badge.



From the LIVE and UPCOMING badges list, select the Badge that you want to issue to the audience. Make sure you are selecting only ACTIVE badges and the badge end date doesn't end before the campaign duration. Note: Only "Direct Issue" type badges and badges owned by audience campaigns are displayed. You can also select New badge and create a new badge if required. Only Direct Issue badges can be created and owner type can be only Audience Campaigns.



If you have selected any Badge as an Incentive, you need to add at least one tag related to the Badge such as the Badge expiry date OR days until expiry. To add the label, navigate to Add creatives > Select the creative > Add Label > Badges.



Updated 7 months ago