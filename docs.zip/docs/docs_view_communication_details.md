# Scraped content from: https://docs.capillarytech.com/docs/view-communication_details

File transfer templates

Suggest Edits

This template allows you to download files from SFTP, FTP server, perform operations on the files and push it to SFTP, FTP server or S3.

Configuring file transfer templates

To configure the file transfer templates, perform the below steps/actions:

In the Connect-to-source Block, enter the source server details where the source data is present and the location for saving the processed file. See Connect to source.

In the Decrypt data block, if the files are encrypted, enter the details to decrypt the data. See Decrypt data.

In the Join-Data block, enter the required details and define the conditions to merge the two files and join the data. See Join Data.

Configure hash-csv-fields block if you want to mask the data present in the CSV file.

In the Rebuild-Headers or Define headers and transform data sections, enter the required details and define the conditions to transform the headers. See Rebuild headers / Define headers and transform data. NOTE: The headers for rebuilding, defining, and transforming data are identical except for their names in the user interface.

In the Encrypt-data block, enter the encryption details to encrypt the file. See Encrypt Data.

In the Connect-to-destination block, enter the SFTP server details. See Connect to destination.

In the Trigger block, enter the details to schedule the trigger. See Trigger.

Updated 3 months ago