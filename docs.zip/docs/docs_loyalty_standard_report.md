# Scraped content from: https://docs.capillarytech.com/docs/loyalty-standard-report

Actions

Suggest Edits

Here's a look at all the actions available in Workflows:

Award Points to Referee

A referrer is an actor who refers other customers to transact with the brand. A referee is an actor referred by a referrer. Brands can configure to incentivize either a referee or referrer or both. To award points to the referee, you need to have points earned condition, points expiry condition (if required), and channels through which you want to communicate or notify the customers when points are awarded. You need to configure earn condition, expiry condition, and channels through which you want to communicate on the points earned by the referee.

👍

Note

The Award Points to Referee action is available only for workflows within the default loyalty program.

512

Earn condition

Click on the Earn Condition drop-down to choose the desired points earning condition for the referee. To create a new earning condition and use it:

Click + Add condition.

510

In Name, enter a relevant condition name.

In Description, enter a short description of the condition.

In Module using this condition, choose the module where you want to use the condition. In this case, it is Loyalty+.

In Allocate based on, choose on what basis points need to be allocated.

Loyalty Registration: To issue points when the referee registers. This should be based on the configuration settings for the referral program.

Loyalty Transaction: To issue points when the referee makes a transaction.

In Allocation type, choose whether to issue fixed points or prorated points.

Fixed: A fixed number of points will be allocated irrespective of the transaction amount.

Prorated: Points are issued as a percentage of the transaction amount or custom field value.

To have a common allocation to all tiers, check the Same for all Tiers. To allocate points differently for each tier, uncheck Same for all tiers. You will see an option to configure for each tier. Set your preferred values for each tier based on the Allocation type chosen.

416

Set Enable delayed accrual to green to allocate points to the current account after a certain period. This is usually the transaction return period that is configured for the org. So, customer can redeem points only if the transaction is not returned. Use this especially in cases where transaction return is allowed.

454

You need to set the number of days after which points are accrued in Accrue points after. An example is shown in the following screenshot.

454

In Delayed accrual, points for a transaction are added as promised points immediately. When the specified period (usually the allowed return period) is completed, these points will be credited to the current account.

Expiry condition

For the points that will be issued for referee, you need to set the expiry condition - when the awarded points should lapse. Click on the Expiry Condition drop-down to choose the desired expiry condition for the points earned by the referee. To create a new expiry condition and add it, click on the respective + Add condition. In the drop-down box, choose the expiry condition (if created already). To create a new expiry condition and add it, follow these steps.

Click + Add condition

In Name, enter a relevant condition name.

In Description, enter a short description about the condition.

In Module using this condition, choose the module where you want to use the condition. In this case, it is Loyalty+.

In Expire points based on, choose the criteria for point expiry. You have three options, Event date, Rolling expiry from event date, and Membership event date. For more information, see here.

Event date: Points expire on the configured date based on the last activity (transaction/registration) done by the customer.

Rolling expiry from event date: The current date of points expiry is reset to a new date based on the recent transaction date.

Membership event date: Points expire automatically when the membership expires.

Enable Same for all Tiers and the condition becomes relevant for all tiers. If disabled, you have to configure conditions for each tier. For more information, see here.

Click Done to save the condition.

Configure communication channel(s)

Once you set the points earning and expiry conditions, it is important to communicate the points earned by the referee. Loyalty+ supports two different configurations for communications.

Mandatory channels

Here you can select the channels through which the communication has to be sent out for sure. Then, configure the message for each channel you select.

1350

Priority channels

Here, you can set the channels through which the communication needs to be sent out based on the priority and availability. For example, if you set the priority in the order SMS, email, and mobile push, the system will first check if the customer's mobile number is available,

If available, it will send an SMS communication and ignores the rest.

If not available, it will check whether the customer has email ID

If email ID is available, it sends out an email notification to the customer.

If not, it will check if the customer is active through mobile push and process the message accordingly. Once the priority channels are set, configure the message for each channel. For more information on communication channels, see here.

Award Points to Referrer

A referrer is an actor who refers other customers to transact with the brand. A referee is an actor referred by a referrer. Brands can configure to incentivize either a referee or referrer or both.

To award points to the referrer, you need to have points earn condition, points expiry condition (if required), and channels through which you want to communicate or notify the customers when points are awarded.

👍

Note

The Award Points to Referrer action is available only for workflows within the default loyalty program.

The following are the options available for the Award points to referrer action.

512

Earn condition

Click on the Earn Condition drop-down to choose the desired points earning condition for the referrer.

To create a new earning condition and add it, follow these steps.

Click + Add condition.

510

In Name, enter a relevant condition name.

In Description, enter a short description of the condition.

In Module using this condition, choose the module where you want to use the condition. In this case, it is Loyalty+.

In Allocate based on, choose on what basis points need to be allocated.

Loyalty Registration: To issue points when the referrer registers. This should be based on the configuration settings for the referral program.

Loyalty Transaction: To issue points when the referrer makes a transaction.

In Allocation type, choose whether to issue fixed points or prorated points.

Fixed: A fixed number of points will be allocated irrespective of the transaction amount.

Prorated: Points are issued as a percentage of the transaction amount or custom field value. For more information, see Create points allocation strategies.

To have a common allocation to all tiers, check Same for all Tiers. To allocate points differently for each tier, uncheck Same for all tiers. You will see an option to configure for each tier. Set your preferred values for each tier based on the Allocation type chosen.

416

Set Enable delayed accrual to green to allocate points to the current account after a certain period. This is usually the transaction return period that is configured for the org. So, customers can redeem points only if the transaction is not returned. Use this especially in cases where transaction return is allowed.

454

You need to set the number of days after which points are accrued in Accrue points after. An example is shown in the following screenshot.

454

In Delayed accrual, points for a transaction are added as promised points immediately. When the specified period (usually the allowed return period) is completed, these points will be credited to the current account.

Click Done to save the condition.

Expiry condition

Points that will be awarded for referrer need to have an expiry condition which indicates when the award will expire.

Click on the Expiry Condition drop-down to choose the desired expiry condition for the points earned by the referee. In the drop-down box, choose the expiry condition (if created already).

To create a new expiry condition and add it, follow these steps.

Click + Add condition

In Name, enter a relevant condition name.

In Description, enter a short description of the condition.

In Module using this condition, choose the module where you want to use the condition. In this case, it is Loyalty+.

In Expire points based on, choose the criteria for point expiry. You have three options, Event date, Rolling expiry from event date, and Membership event date. For more information, see here.

Event date: Points expire on the configured date based on the last activity (transaction/registration) done by the customer.

Rolling expiry from event date: The current date of points expiry is reset to a new date based on the recent transaction date.

Membership event date: Points expire automatically when the membership expires.

Enable Same for all Tiers and the condition becomes relevant for all tiers. If disabled, you have to configure conditions for each tier. For more information, see here.

Click Done to save the condition.

Configure communication channel(s)

Mandatory channels: From here, you can choose the communication channels that will invariably be used and through which the communication will definitely be sent out.

Priority channels: According to priority and availability, you can specify how to send the communication. For example, if you set the priority in the order of SMS, email, and mobile push, the system will first check if the customer's cell phone number is available,

If available, it will send an SMS communication and ignore the rest.

If not available, it will check whether the customer has an email ID

If an email ID is available, it sends out an email notification to the customer.

If not, it will check if the customer is active through mobile push and process the message accordingly.

Finally, configure the message for each communication channel you have chosen.

For more information on communication channels, see here.

Forward to Set

The general expressions that you define at the parent set level allow you to evaluate conditions at the transaction level. However, you need to use Forward to set to evaluate line-items, payment mode, or tracker values of the transaction. When you use Forward to set on a condition, it creates a subset where you can define rules on the transaction items.

You can either use line-item unrolling or payment method unrolling, or both of them in a single action.

The following are the options available for the Forward to set action.

313

Evaluate rules at the line-item level (Enable line-item unrolling)

Enable the toggle button to evaluate rules on transaction line items. When enabled, L+ evaluates the defined rules for every line item of the transaction.

You will see the options shown in the following image.

316

Use line item proportions: Enable this option when line item amounts may not add up to the transaction amount. Enable this when there is a bill-level discount that you want to distribute to the line items of the transaction.

Maximise points allocation: Enable this option to maximize points for the eligible payment methods - payment methods marked as eligible under Advanced Settings.

Points are allocated for the total eligible amount rather than on a prorated basis. Individual line item amounts are not considered when this option is enabled.

Evaluate payment modes (Enable payment method unrolling)

This option lets you run rules on individual payment methods. When you on Enable payment method unrolling, the rules defined in the forwarded set would be evaluated multiple times - it repeats for every payment method in the transaction.

📘

Forward to set is also used for trackers.

When Enable line item unrolling is enabled, the rules defined in the forwarded set would be evaluated multiple times (they will be repeated for every item in the transaction).

When Enable payment method unrolling is enabled, the rules defined in the forwarded set would be evaluated multiple times (they will be repeated for every payment method in the transaction).

When you choose Forward to set action, you can either use line item unrolling or payment method unrolling, or both of them. If you just need to evaluate more expressions, you can disable both and click Save to proceed to configure the new sub-set. In the following screenshot, Set3 is the new subset created.

512

Evaluate multiple conditions (at the event level)

If you just need to evaluate more expressions before executing an action:

Disable both Enable line item unrolling and Enable payment method unrolling

Click Save to proceed to configure the new subset. You will see a new sub-set.

313

The general expressions that you define at the parent set level allow you to evaluate conditions at the transaction level. However, you need to use Forward to set to evaluate line-items, payment mode, or tracker values of the transaction. When you use Forward to set on a condition, it creates a subset where you can define rules on the transaction items.

You can either use line-item unrolling or payment method unrolling, or both of them in a single action.

The following are the options available for the Forward to set action.

313

Evaluate rules at the line-item level (Enable line-item unrolling)

Enable the toggle button to evaluate rules on transaction line items. When enabled, L+ evaluates the defined rules for every line item of the transaction.

You will see the options shown in the following image.

316

Use line item proportions: Enable this option when line item amounts may not add up to the transaction amount. Enable this when there is a bill-level discount that you want to distribute to the line items of the transaction.

Maximise points allocation: Enable this option to maximize points for the eligible payment methods - payment methods marked as eligible under Advanced Settings.

Points are allocated for the total eligible amount rather than on a prorated basis. Individual line item amounts are not considered when this option is enabled.

Evaluate payment modes (Enable payment method unrolling)

This option lets you run rules on individual payment methods. When you on Enable payment method unrolling, the rules defined in the forwarded set would be evaluated multiple times - it repeats for every payment method in the transaction.

📘

Forward to set is also used for trackers.

When Enable line item unrolling is enabled, the rules defined in the forwarded set would be evaluated multiple times (they will be repeated for every item in the transaction).

When Enable payment method unrolling is enabled, the rules defined in the forwarded set would be evaluated multiple times (they will be repeated for every payment method in the transaction).

When you choose Forward to set action, you can either use line item unrolling or payment method unrolling, or both of them. If you just need to evaluate more expressions, you can disable both and click Save to proceed to configure the new sub-set. In the following screenshot, Set3 is the new subset created.

512

Evaluate multiple conditions (at the event level)

If you just need to evaluate more expressions before executing an action:

Disable both Enable line item unrolling and Enable payment method unrolling

Click Save to proceed to configure the new subset. You will see a new sub-set.

313

Renew Tier

Tier renew is retaining the current tier that the customer is enrolled in and providing all the privileges of the tier.

To configure the Renew Tier action, follow these steps.

Select Renew Tier and click Save.

343

After you select Renew Tier, you will see the following screen. Click on the Save option.

992

📘

There are no specific options to be set in Renew tier action.

Send mail

You can send an email to your customers when they satisfy a certain condition. It could be regarding the rewards they earned or just a general notification. You can design the email from the scratch or use an existing template from creatives library.

To configure the Send mail action, follow these steps.

In When, select Send mail and click Save.

549

Click on Add creative to configure the email message.

523

To create the message from the scratch, click Create new. To use an existing template, hover on the desired template and click Select.

1656

Enter Subject, design email body, and click Done. You can Preview the email before saving and use the respective icons to see how the email renders in laptop/desktop, mobile phone, and tablet.

Configure Sender information. By default, the the default sender ID will be selected. If you wish to send from a different sender ID: i. Click on the more options icon and select Edit. ii. Uncheck Use default sender ID. You will see options to choose a sender ID.

543

iii. Choose your preferred sender Domain, Sender ID, and Sender Label. iv. Click Save to continue.

You can also set the delay in sending email from the event time. For example, you want to communicate something to the customer two days post a transaction. i. Click on Add delay while sending. ii. Choose your preferred period in the drop-down - Sec, Mins, Hours, or Days. iii. In Delay by enter the duration. iv. Click Save to continue

📘

Delay time should be greater than 120 seconds or 2 minutes.

509

Send messages

You can notify customers when an action is executed successfully. Notifications can be sent through different channels such as SMS, email, WeChat, and Mobile Push.

Notification channels are of two types:

Mandatory Channels:, Channels that are mandatory for sending the notifications

Priority Channels: Channels that needs to be triggered based on the priority and availability. For example, if SMS is set as priority 1, Mobile Push as priority 2 and email as priority 3, the system first checks whether SMS is configured and then checks if the mobile number is available for the customer. If any one fails, then it will try to send the notification through mobile push and so on.

Channels that are selected in Mandatory Channels will not appear in Priority Channels and vice versa.

To configure notifications, follow these steps.

Click the Advanced Settings of the campaign you want to make the changes.

Click on Communication Channels and you will see the following screen.

1360

Select Mandatory Channels and Priority Channels for the notifications and click Save

1014

Send mobile push

You can send push notifications to your customers by customizing the notifications with creatives. You can design the notification from the scratch or use an existing template from the creatives library.

To configure the Send mobile push action, follow these steps.

Select Send mobile push and click Save.

344

Click on Add creative to configure the mobile push message.

340

Choose one account for which you want to configure the mobile push message

299

To create the message from scratch, click Create new. To use an existing template, hover on the desired template and click Select.

1107

Enter Title, and the message body. You can Preview the message before saving it and use the respective icons to see how the message renders mobile phone.

1150

📘

Android and iOS platforms are both supported, so you can set up push notifications for both.

i. Select + Add Label to use the dynamic tags to personalize the text for the customer-rich experience.

1145

ii. Select Upload Image to set the cover image of the push notification message.

1145

📘

The maximum file size acceptable is 5 MB

iii. Check Add action link to content to add a hyperlink of the page where the customer will be directed to.

Deeplink: Link use to direct the customer within the mobile application on a specific page.

External Link: Link used to direct the customer to the external web page

474

iv. Check Add primary button to notification to enter a CTA (Call to action) label.

1045

v. Check Add secondary button to notification to enter a secondary CTA (Call to action) label.

1061

You can also set the delay in sending mobile push from the event time. For example, you want to communicate something to the customer after a specific interval of time. i. Click on Add delay while sending.

345

ii. Choose your preferred period in the drop-down - Sec, Mins, Hours, or Days. iii. In Delay by entering the duration.

316

📘

Delay by value should be greater than 120 Seconds or 2 minutes.

Click Save to continue.

Send SMS

You can send an SMS to your customers when they satisfy a certain condition. It could be regarding the rewards they earned or just a general notification. You can create an SMS from the scratch or use an existing template from the creatives library.

📘

The message configuration varies for customers in India. You can use only DLT complaint message templates.

To configure the Send SMS action, follow these steps.

Select Send SMS and click Save.

348

Click on Add creative to configure the SMS.

344

To create the message from scratch, click Create new. To use an existing template, hover on the desired template and click Select.

1105

Configure SMS text, and click Done. You can preview the SMS before saving it to see how the SMS renders on a mobile phone. i. Select + Add Label to use the dynamic tags to personalize the text for the customer-rich experience. ii. Select Allow Unicode characters to allow the support of a much wider character set, and includes pretty much every character in the world, including Indian languages, some of the stranger European characters (like í), all the Cyrillic alphabet (e.g. Arabic, Russia, Punjabi, and Greek), all the Asian ones (Chinese, Japanese, etc), and also some of the emoticons out there!

1149

Configure Sender information. By default, the default sender ID will be selected. If you wish to send from a different sender ID: i. Click on the more options icon and select Edit. ii. Uncheck Use default sender ID. You will see options to choose a sender ID.

351

Select Shorten all URLs to shorten links used in SMS,

352

📘

As an SMS has a character limit, it is usual that the links that you use in SMS could occupy lot of characters. Hence, we highly recommended using shorten links or tiny URLs in such instances.

You can also set the delay in sending SMS from the event time. For example, you want to communicate something to the customer two days post a transaction. i. Click on Add delay while sending. ii. Choose your preferred period in the drop-down - Sec, Mins, Hours, or Days. iii. In Delay by entering the duration.

Click Save to continue.

📘

Delay time should be greater than 120 seconds or 2 minutes.

348

Send Wechat

Tag Customer

Transaction point allocation & Allocate Points action

Transaction points allocation lets you create various allocation strategies and use the desired one when configuring rule sets. You can allocate points on the transaction amount. You can also have common points allocation across tiers or different allocations for each tier.

To configure the Transaction point allocation action, follow these steps.

Select Transaction point allocation and click Save.

346

In the Earn condition, choose the desired condition from the drop-down list. To create a new condition, click on + Add Condition.

975

In the Zero earn condition, choose an appropriate condition from the drop-down. Note: The configuration for the zero earn condition is not determined by these options and depends on the other configurations explained here.

766

Select the Expiry condition from the drop-down menu. To create a new Expiry earn condition from scratch, click + Add condition.

769

In Prorate on, choose on what basis you want to issue a percentage of points - transaction amount or event value. This is applicable only for prorated points allocation. If bill amount, choose a current event, if tracker, choose current aggregate or previous aggregate

Amount: Choose this to allocate prorated points on the transaction amount.

Current aggregate: Choose this to allocate prorated points on the value of the tracker post the current transaction. This is disabled in Evaluations start and Evaluation end sets.

Previous aggregate: Choose this to allocate prorated points on the value of the tracker before the current transaction. This is disabled in Evaluations start and Evaluation end sets.

In the Points rounding strategy, you can choose which points rounding strategy you prefer using from the drop-down list. Points rounding strategy informs how many decimal points to use when allocating points to customers.

Actual: Issues the actual number of points as configured in the prorated condition. For example, the customer will receive 19.9 points for the transaction amount of 199, if the points allocation condition is set as 10%.

Floor: Evaluate and assign the values without considering the decimal value. For example, assume customers should receive 10% of points for transactions. If a customer has purchased for $199, instead of 19.9 points, the customer will receive 19 points.

Round: Determine the number of decimal points you want to support for decimal points. Zero is for no decimal, one is for one, two is for two, and three is for three decimal points.

593

Select Delay strategy: Following are the different delayed-accrual (or point conversion strategies) that are currently available for the brands to use.

As defined in the allocation strategy: Points are assigned based on the conditions defined in the allocation strategy. If no conditions are defined, points will be directly issued as current points.

Fixed delay days from item return period: Based on the return period configured against the product, issue the promised points as current points once the return period expires. For example, assume for a transaction with a return period of 7 days, the customer is promised to get 1000 points. These promised points will be converted into current points after 7 days i.e. after the return period is over.

Available only for transaction-based customer activities.

Fixed delay days from the line-item extended field: Based on the value of the line-item extended field that is selected in the drop-down. Say, there is a line-item extended field called "ABC" & this is selected in the drop-down of "delay strategy" during the point allocation action after selecting this delay strategy. Now, say a user made a transaction & the value of this field is arrived as 10. Then the points that are being allocated from that action will have a delayed accrual of 10 days.

Available only for transaction-based customer activities, and the line-item extended field should mandatorily come from the transaction payload.

On external trigger: Issue points at the event of “transaction add” as promised points and convert them at the event of “transaction update”. For example: In hospitals, promised points will be issued immediately when you make a booking and will be converted into current points when the bill is settled.

Available only for transaction-based customer activities.

Based on the behavioral event attribute: Based on the date that is coming via the attribute of the behavioral event. Assume, there is a behavioral "ABC" that has 3 attributes (X, a date type attribute; Y, a customer identifier attribute; Z, a numerical attribute). During the point allocation from a promotion (that is created based on this behavioral event), if the delay strategy is selected as "Based on the event attribute", then there will be a drop-down where the attribute should be selected. The following are vital points:

In the drop-down of "delay strategy", only the date type of the attribute of the behavioral event will appear.

Under the prorate drop-down, only the double-type attributes of the behavioral event will appear.

If the date coming is a past date as per the event processing date, the conversion will happen on the same day.

This option will be available only for promotions based on behavioral events.

Following are the accrual strategies available for transaction-based activities:

581

Following are the accrual strategies available for behavioral event-based activities:



Zero earn condition

In the Zero-earn condition, points are not allocated in the following cases:

Bill Number Prefix: When the bill number starts with a prefix defined in the IGNORE_POINTS_FOR_BILL_NUMBER_STARTS_WITH configuration.



Customer Label: When the BLOCK_POINTS_ALLOCATION label is set for a customer. You can configure this from Organisation settings > Miscellaneous > Customer Status Configuration.

📘

Note

In these cases, the customer tier will be upgraded if eligible, despite no points being allocated.

Configure communication channel(s)

Mandatory channels

Here you can select the channels through which the communication has to be sent out for sure. Then, configure the message for each channel you select.

959

Priority channels

Here, you can set the channels through which the communication needs to be sent out based on the priority and availability. For example, if you set the priority in the order SMS, email, and mobile push, the system will first check if the customer's mobile number is available,

If available, it will send an SMS communication and ignore the rest.

If not available, it will check whether the customer has an email ID

If an email ID is available, it sends out an email notification to the customer.

If not, it will check if the customer is active through mobile push and process the message accordingly.

954

Once the priority channels are set, configure the message for each channel.

For more information on communication channels, see here.

Upgrade tier

You can upgrade the tier for the customer based on a tracker value or any specific event value and provide all the privileges of the tier.

To configure the Upgrade to tier action, follow these steps.

Select Upgrade to tier and click *Save.

344

After you select Upgrade to tier, you will see the following screen. Hover to Slab to upgrade and choose the desired option from the drop-down.

399

Toggle Award points to green to enable the criteria to award the points to the customer.

395

In the Earn condition, choose the desired condition from the drop-down list. To create a new condition, click on + Add Condition.

696

Select the Expiry condition from the drop-down menu. To create a new expiry earn condition from scratch, click + Add condition.

719

In Prorate on, choose on what basis you want to issue a percentage of points - transaction amount or event value. This is applicable only for prorated points allocation. If bill amount, choose a current event, if tracker, choose current aggregate or previous aggregate.

Event default value: Choose this to allocate prorated points on the transaction amount.

Current aggregate: Choose this to allocate prorated points on the value of the tracker post the current transaction.

Previous aggregate: Choose this to allocate prorated points on the value of the tracker before the current transaction.

550

Select the channels through which the communication has to be sent out for sure.

i. Mandatory channels: You can select the channels through which the communication has to be sent out for sure. Then, configure the message for each channel you select.

934

ii. Priority channels: Here, you can set the channels through which the communication needs to be sent out based on the priority and availability. For example, if you set the priority in the order SMS, email, and mobile push, the system will first check if the customer's mobile number is available,

If available, it will send an SMS communication and ignore the rest.

If not available, it will check whether the customer has an email ID

If an email ID is available, it sends out an email notification to the customer.

If not, it will check if the customer is active through mobile push and process the message accordingly.

929

Click on Save.

Upgrade using tier

You can upgrade customers using the tier conditions when they satisfy a certain condition. It could be regarding the rewards they earned or just a general notification.

To configure the Upgrade using tier action, follow these steps:

In Action, select Upgrade using tier.

1389

In User entity, choose Individual to issue points to customers who met the condition. OR Choose Group to issue points to the group (Deprecated).

To issue points, enable Award points.

1395

In the Earn condition, choose the earning condition that you want to associate using the drop-down list. To create a new condition, click on + Add Condition.

In Expiry condition, choose the expiry for the points using the drop-down list. To create a new expiry earn condition, click + Add condition.

In Prorate on, choose on what basis you want to issue percentage of points - transaction amount or event value. This is applicable only for prorated points allocation. For bill amount, you can choose the Current event, for tracker, you can choose Current aggregate or Previous aggregate.

Event default value: Choose this to allocate prorated points on the transaction amount.

Current aggregate: Choose this to allocate prorated points on the value of the tracker post the current transaction.

Previous aggregate: Choose this to allocate prorated points on the value of the tracker before the current transaction.

Issue Coupon

This action allows you to issue coupons based on a specific activity.

The coupons used here are the ones which are claimed by loyalty in strategies.

📘

NOTE:

All quantity values, whether initially provided as integers or decimals, will always be converted to integers. Decimal values will be rounded accordingly. For example, 4.7 will be rounded to 5, while 3.2 will be rounded to 3.

Coupon issue types

1. Fixed Quantity:

Fixed quantity lets you allocate a predetermined number of coupons either uniformly across all tiers or uniquely for each tier.

Same for all tiers: Set a single, fixed quantity of coupons to be issued across all tiers. For example, if you allocate 10 coupons, each customer, regardless of tier, receives 10 coupons for completing an action.





Different for each tier: Set a different quantity of coupons for each tier. For example, Tier 1 customers are issued 20 coupons, Tier 2 are issued 30 coupons, and Tier 3 are issued 50 coupons for completing an action.





2. Transaction Step Function

The transaction step function dynamically allocates coupons based on transaction amounts, either uniformly across all tiers or uniquely for each tier.

📘

Note:

The Transaction Step Function is triggered only when a Transactional Event is performed by the customer. For all other events Fixed Quantity is supported.



Same for All Tiers: Set a specific transaction amount and fixed quantity of coupons to issue across all tiers. For example, for every transaction worth ₹1000, each customer, regardless of their tier, will be issued 10 coupons for completing the transaction.





Different for Each Tier: Set a specific transaction amount and different quantity of coupons for each tier. For example, for every transaction worth ₹1000, Tier 1 customers receive 20 coupons, Tier 2 receive 30 coupons, and Tier 3 receive 50 coupons for completing the transaction.





❗️

The maximum number of coupon that can be allocated to the customer is 500.



Issue Catalog Reward

You can use the Issue Catalog Reward option to reward customers for specific events. For example, you can issue rewards to customers who register for your loyalty program or, in a health and fitness app, to those who burn 500 kilocalories in a day.

Once you create a reward in Marvel Reward UI, you can issue it based on different events. Rewards can be triggered by:

Promotions: Customers automatically receive rewards when they join promotional campaigns.

Milestones: Rewards are issued when customers reach specific milestones, like spending a certain amount or completing a set number of purchases.

Events: Customers earn rewards by initiating transaction, customer, or measurable behavioral events (with the datatype integer or double).

You can issue rewards through Issue Catalog Reward using the following:

For milestones, streaks, and behavioural events, use Loyalty Promotions flow.

For other events, use Loyalty Program workflows.

Follow these steps to issue a catalog reward:

From the Add Action window, click on Issue Catalog Reward.



Click Save. The Add action: Issue catalog reward window opens.



A note appears in the window stating: The behavior of the “Issue Catalog Rewards” action differs when configured in the “Point to Reward Conversion” customer event compared to other events. This means the behaviour of Issue Catalog Rewards differs between the [Point to Reward Conversion](https://docs.capillarytech.com/docs/auto-points-conversion-to-reward) and other events such as the Customer Registration Transaction Add, Points Redemption etc.

The table below shows the difference in the behaviour of Issue Catalog Rewards action for Customer Registration and Point to Reward Conversion events.

Aspect Customer Registration Point to Reward Conversion Reward Quantity Quantity is defined manually or based on the event. Quantity is automatically calculated based on the points earned in the event. Reward Calculation You define how many rewards to issue. Example: 1 reward for registration The system calculates the reward quantity by dividing the total points by the reward value. Points Requirement Points may or may not be required for issuing the reward. Points are required, and rewards are issued based on accumulated points. Example: 1,000 points = 10 rewards if each reward is worth 100 points. Flexibility You can control the number of rewards issued manually. The system automatically adjusts the number of rewards based on points earned.

Choose the Reward you want to issue from the dropdown. The active catalog rewards with Live and Upcoming statuses appear here.



Choose one of the following from the Reward quantity same as dropdown:



a. Add Manually i. Select Add Manually to specify the number of rewards you want to issue to a customer. ii. In Add manually field, enter the number of rewards.



b. Transaction Extended Field i. Select Transaction Extended Field to set the number of rewards a customer receives based on the value captured by the transaction extended field. ii. Select the transaction attribute or value that determines the reward quantity using the Select transaction extended field drop-down. For example, if the transaction extended field Gross Weight value is 50, the system issues 50 rewards.



c. Points Issued on Event i. Select Points Issued on Event to give rewards based on the points a customer earns during an event. For example, if a customer earns 10 points during an event, they get 10 rewards. The system uses the points earned to decide the number of rewards.



(Optional) Choose the Fulfilment status from the drop-down. Fulfilment status allows you to track and assign a specific status to a reward when it is given to a customer. By setting a fulfilment status, you can let the customer know the reward status whether it is been shipped, is on the way, or being processed.



(Optional) Add additional information about the issuance of the reward under Notes. This information is shared with the vendor responsible for fulfilling the reward.



Click on +Reward transaction custom fields. A list of custom fields available for the organisation is displayed. These are the customer fields created for the Reward (using scope ISSUE_REWARD when using API) and allow you to send extra information, such as customer details or specific requirements when issuing a catalog reward. This feature is useful when passing data to a vendor who will fulfil the reward.



Select the required custom fields by checking the box or use the Search option to find it, then click Select. The selected custom fields are displayed.



Choose a Mapping type from the drop down.



a. Add Manually - Select Add Manually to manually add extra information against a reward transaction custom field. The information can be added against the Mapped entity field. For example, if you want to add information to the vendor to Issue the reward after 10 days, you can select an appropriate custom field and manually add this message.



b. Transaction Extended Field - This mapping type sends information to the vendor through a transaction extended field. For example, if you want to share the GST number of a transaction with the vendor, you can select the appropriate custom field and map it to the GST number transaction extended field. The system resolves the transaction extended field information against the customer in the backend. To use this, select Reward Transaction Custom Field and choose the relevant transaction extended field from the Mapped Entity drop-down.



c. Customer Extended Field: This mapping type is used to share information with the vendor through a customer extended field. For example, if you want to provide the customer’s communication address to the vendor for sending the reward, you can select the appropriate custom field and map it to the address customer extended field. The system resolves the customer extended field information against the customer in the backend. To use this, select Reward Transaction Field and, from the Mapped Entity drop-down, choose the relevant customer extended field



Note: You can add, edit, and delete the Reward transaction custom fields.

Click Done to issue the reward.



Note: The UI currently does not display the source of coupon issuance, and you cannot filter rewards by fulfilment status. However, you can retrieve the fulfilment status using the Get Purchased Rewards for User API.

Customer status & label

This action lets you configure the "customer status & label" for your customers directly from the workflows. This action will be available in both the loyalty programs & loyalty promotions.

For example:

If you want to change the "label" of all the customers who made transactions worth more than 10,000 as "high-value", it can be done with this action directly from workflows.

If you want to change the "label" of all the customers who made more than 5 returns to "suspecting", it can be simply done with this action.

To use this action, do the following steps. Go to workflow -> action, and there you'll find:

An action "change customer status & label"



Now select the status & label you want to configure. Note that, the label is unique across status. This means that, when you are selecting the label, you are selecting the status also.



You'll find that configured action in the display once it is done.



In this way, you can change the status & label of your customers directly from workflows.

Updated 2 months ago