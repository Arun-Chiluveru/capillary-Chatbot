# Scraped content from: https://docs.capillarytech.com/docs/dashboard

Attributes - Custom Field

Suggest Edits

Profile - currentCustomer()

Profile: currentCustomer : Allows you to write conditions based on the properties of the customer who is currently performing the activity.

Custom Fields : Custom fields are columns that store special or custom information related to customers, transactions, transaction line-items, coupons, category and so on.

The following are different entries for which you can create custom fields.

Loyalty registration

Loyalty transaction

Customer feedback

Zone custom fields

Store custom fields

Points redemption

Voucher redemption (coupon redemption)

Customer advanced feedback

Customer preferences

Customer Card To know how to create a Custom Fields, click here

Attributes : Attributes based on Custom Fields for Customer profile are listed below in the table.

Attribute Data Type Description Sub-Attributes customFieldValueIncludes boolean checks If customer has some custom field present with particular value Sub-Attributes 1: custom Field Name Sub-Attributes 2: Value of custom field customFieldValueExists boolean checks If customer has some custom field present Sub-Attribute 1: Custom field Value customFieldValueExcludes boolean checks If customer has some custom field is not present with particular value Sub-Attributes 1: custom Field Name Sub-Attributes 2: Value of custom field

customFieldValueIncludes

Profile : currentCustomer Attribute: customFieldValueIncludes Data Type : Boolean Description : checks If the customer has some custom field present with a particular value. Sub-Attributes: Custom Field Name, Custom Field Value Syntax: currentCustomer.customFieldValueIncludes(“custom_field_name”,”custom_field_value”)

Example 1: Lets see we have created a custom field by the name of cities and value includes delhi, Indore, bangalore etc. Now a marketing manager wants to provide incentive to those customers who are from bangalore. The rule : currentCustomer.customFieldValueExcludes("cities","Bangalore")

Example 2: Suppose the college team in your city has won a major championship and you want to celebrate the event by offering discounts to customers who had included that sport as their favorite. To issue coupons to customers who had included SportX as their favorite, use the following condition: currentCustomer.customFieldValueIncludes("Favorite_Sport","SportX") If the value returned is SportX, then the coupon is issued.

Example 3: A marketing Manager of a corporate gifting company wanted to select the customers from selected companies to send the communication of the latest festival offers. Custom field name : corporate Custom field value : KPMG, Magnus India,Polaris, Time of India,RENAISSANCE, Epicenter Technology, Capillary, "NESS TECHNOLOGIES". Out of all the values, they want to send communication to KPMG, CAPILLARY, TOI Rule: currentCustomer.customFieldValueIncludes(“corporate”,”KPMG”)||currentCustomer.customFieldValueIncludes(“corporate”,”TOI”)||currentCustomer.customFieldValueIncludes(“corporate”,”capillary”)

Another: rule to check if customer age is between 25-40 or 40-90 and gender is Male and current transaction basket contains POLO and number of transactions done is greater than 1. (currentCustomer.customFieldValueIncludes("age","25-40")||currentCustomer.customFieldValueIncludes("age","40-90"))&&(currentCustomer.customFieldValueIncludes("gender","Male"))&&(currentTxn.basketIncludes("Producttype","polo"))&&(currentCustomer.numberOfVisits>1)

customFieldValueExcludes

Profile : currentCustomer Attribute : customFieldValueExcludes Data Type: Boolean Description : checks If customers do not have some custom field present with a particular value. Sub-Attributes: Custom Field Name, Custom Field Value Syntax: currentCustomer.customFieldValueExcludes(“custom_field_name”,”custom_field_value”)

Example: As a marketing manager I want to check if the customer is from homeclub_number and value 12 or 11. currentCustomer.customFieldValueExcludes("homeclub_number","12")||currentCustomer.customFieldValueExcludes("homeclub_number","11")

Example: write a rule to evaluate a current customer credit_customer field value is 1 and current slab name is homeclubMember and number of transactions made till now is 1 and the current transaction basket includes Tablets, from category_descriptions custom field. currentCustomer.customFieldValueExcludes("credit_customer","1")&&(currentCustomer.slabName=="HomeClub Member"&&(currentCustomer.numberOfVisits==1)&&((currentTxn.basketIncludes("Category_Description","Tablets"))

Example: Write an expression to evaluate that current customer, DVS custom field value is Home lovers and preferred language is not Arabic. currentCustomer.clusterValueIncludes("DVS","Home Lovers")&&(currentCustomer.customFieldValueExcludes("preferredlanguage","Arabic"))

customFieldValueExists

Profile : currentCustomer Attribute : customFieldValueExists Data Type : Boolean Description : checks If the customer has some custom field present Sub-Attributes: Custom Field Name Syntax: currentCustomer.customFieldValueExists(“custom_field_name”,”custom_field_value”)

Example: Write a rule to check if current customer has a custom field by the name billdelayed. currentCustomer.customFieldValueExists(“billdelayed”)

Updated over 1 year ago