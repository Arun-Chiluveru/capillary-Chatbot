# Scraped content from: https://docs.capillarytech.com/docs/overview-1

Types of Reports

Suggest Edits

There are two types of reports:

Standard reports - Standard reports are predefined reports created by Capillary and are not editable. These reports use standard KPIs which are helpful across brands. The standard reports are available to use by everyone.

Custom reports- Custom reports empower users to generate tailored reports that cater to their specific requirements and needs.

You can perform the following using Insights+:

Create reports

Download reports

Schedule and share reports

Set targets at KPI level and

Analyse reports based on audience groups

Updated 10 months ago