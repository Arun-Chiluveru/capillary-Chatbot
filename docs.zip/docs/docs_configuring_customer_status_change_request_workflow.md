# Scraped content from: https://docs.capillarytech.com/docs/configuring-customer-status-change-request-workflow

Loyalty+ Reporting

Suggest Edits

Along with Loyalty+, Capillary provides you with an excellent reporting tool called Insights+, which you can use to monitor different facets of your loyalty programs. You can read more about the Insights+ platform here. Read on to get information on the various Loyalty+ Reports.

Updated over 1 year ago