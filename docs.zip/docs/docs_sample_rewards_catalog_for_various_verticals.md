# Scraped content from: https://docs.capillarytech.com/docs/sample-rewards-catalog-for-various-verticals

Manage Custom Permission Sets

Suggest Edits

Custom permission sets can be created only by organisation owners.

List of Configurable Permissions

The tables below provide information on the permissions that you can configure for each module when creating a custom permission set. The permissions that do not have a tick mark are the actions that are not available in the permissions.

Campaign Permissions

Modules Sub Modules View Create Edit Approval Campaign ✔ ✔ ✔ ✔ Workflow ✔ ✔ ✔ Messages ✔ ✔ Incentive ✔ ✔ ✔ Audience ✔ Report ✔ Creatives ✔ Config ✔ Journeys

Loyalty+ Permissions

Modules View Create Basic ✔ Program ✔ Promotion ✔

Member Care Permissions

Modules Sub Modules View Create Edit Delete Approval Customer ✔ ✔ ✔ ✔ ✔ Customer Profile ✔ ✔ ✔ ✔ Customer PII ✔ ✔ ✔ Customer Retro Transaction ✔ ✔ ✔ Customer Cards ✔ Customer Goodwill ✔ Customer Group ✔ Requests ✔ ✔ ✔ Requests Goodwill Points ✔ ✔ ✔ Requests Goodwill Coupons ✔ ✔ ✔ Requests ID Change ✔ ✔ ✔ Requests ID Reallocation/Merge ✔ Requests PII Deletion Requests Cards Requests Retro Transaction Requests Transaction ✔ ✔ ✔ ✔ ✔ Group ✔ ✔ ✔ Group Goodwill ✔ ✔ ✔ Group Transactions

Insights+ Permissions

Modules View Create Reports ✔ ✔ Segments ✔ Export ✔ Settings ✔

Creating a Custom Permission Set

To create permission sets, perform the following:

Click Create permission set.



Enter the Permission set name and Description for the permission set.



Select Start from scratch and click Next.



Select the relevant modules and assign the permissions.





Click Done. The new permission sets are created.

Editing a Custom Permission Set

To edit a permission set,

From the list of Permission sets, click the kebab menu (⋮) of the permission set you want to edit and select Edit.

Make the changes as required and click Save Changes.



Deleting a Custom Permission Set

To delete a permission set, from the list of Permission sets, click the kebab menu (⋮) of the permission set you want to delete and select Delete. You can only delete a custom permission set.

Updated about 1 month ago