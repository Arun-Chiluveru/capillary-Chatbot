# Scraped content from: https://docs.capillarytech.com/docs/onboard-users-to-intouch

View import jobs

Suggest Edits

You can fetch details of import jobs by duration, profile and status.

Fetching Import Details.png

To generate reports of the data import across an organization

On the Settings page, click Master Data Management > Search Import File

In the Organization drop-down box, choose the organization for which the report has to be generated. Choose All if you wish to generate reports for all organizations

Set the date range for which the report has to be generated in Start Date and End Date fields

In the Profile drop-down box, choose a profile if you wish to generate report for a particular profile. By default ALL profiles will be selected.

In the Select Status drop-down box, choose the import status, if you which to generate report for a particular import status

Click Submit to generate report

363

A sample report is shown in the following figure. More fields of the table can be viewed by scrolling the horizontal navigation bar under the report.

965

Updated over 1 year ago