# Scraped content from: https://docs.capillarytech.com/docs/tracker-value-standard-export-template

Fraud Management

Suggest Edits

Introduction

Fraud management is the process of detecting, preventing, and responding to fraudulent activities, using predefined rules, and scoring systems. As a part of this, we analyze customer behavior to detect anomalies and identify suspected users. Then, the brand can monitor these suspected users and take restrictive measures as required.

Updated 4 months ago