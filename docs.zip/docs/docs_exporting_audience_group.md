# Scraped content from: https://docs.capillarytech.com/docs/exporting-audience-group

Register customers

Suggest Edits

Orgs usually build microsites using Sharingan app and allows registering customers directly through microsites. In cases where a customer cannot access the microsite, the org staff or Capillary admins can register or update the profile information on a specific microsite through Member Care.

The following are the steps to register or update a customer.

Choose the microsite on which you want to register/update a customer through Member Care. Navigate to the respective page and register or update a customer.

Prerequisites

You need to have permission to register or update a customer on Member Care.

The microsite on which you want to register or update your profile should have the respective event configured.

Set the microsite on which you want to register/update customer

Before proceeding, you need to set the microsite on which you want to register/update a customer through Member Care. You will see form fields configured for the microsite that you set on the Action Settings page.

To set the microsite on which you want to register/update a customer, follow these steps.

On Member Care, navigate to Settings > Action Settings.

534

In New Customer, select the microsite that you want to use to register a customer. For example, membercareReg.

In Edit Customer, select the microsite that you want to use to update customer information. For example, membercareEdit.

Click Save.

📘

Note:

In the preceding screenshot, the membercareReg and membercareEdit are the pages created using Sharingan App. Hence, the page design and form fields can differ for each microsite.

Register customer

Before registering, ensure that you have set the microsite on which you want to register.

To register a customer on a microsite through Member Care, follow these steps.

Navigate to the New Customer Registration page using any of the following processes.

Customer Registration page (directly): On Member Care, click Search > Customer Registration.

586

From Customer Search page: If you are already on the Customer Search page, click the ⋮ icon and New Customer.

845

From Customer Profile page: If you are already on a customer's profile page, click the Select Actions drop-down and select New Customer.

1106

In New Customer Registration, enter the customer details. The following image shows a sample registration page of a microsite. The page design and form fields might differ for each microsite.

544

In Name, enter the name of the customer.

In the Email Address, enter the email ID of the customer. For example, [email protected], where username123 is the username, capillarytech is the domain and com is the Top Level Domain (TLD). Username: The username portion of the email address can consist of alphanumeric characters (letters and numbers) along with hyphens, underscores, plus signs, and dots. Domain: The domain portion of the email address can consist of alphanumeric characters (letters and numbers) along with hyphens, underscores, and dots. TLD: The TLD must consist only of alphabetic characters (letters). When you enter an email id, the system changes the entered email id into the format <alphanumeric along with hypen, underscore, plus, dot>@<alphanumeric along with hypen, underscore, dot>.<alphabetic>and performs the email validation.

In External ID, enter the supported external ID of the customer (if applicable for the org).

In Mobile Number, enter the mobile number of the customer.

In Country, select the country where the customer resides using drop-down options.

Click Save. You will see the message - Customer registered successfully. Then, It redirects to the customer profile page.

Update customer profile

You can modify existing customer details other than the primary identifier. However, secondary identifiers can be modified if the relevant configuration is enabled on the Registration Configuration page.

Before updating a customer, set the relevant microsite page on which you want to update profile details.

To modify customer details on a microsite through Member Care, follow these steps.

On Member Care, navigate to Search > Customer > Customer Search.

Search and open a customer profile using customer details such as name, mobile number, email ID, and external ID.

In Select Actions, select Edit Customer using the drop-down option

1111

In Update Profile, modify the customer profile details.

275

Click Save. You will see the message - Profile updated successfully. Then, It redirects to the customer profile page.

📘

Note:

The customer profile update will fail if the customer identifier’s value is the same as an existing customer identifier value.

Updated over 1 year ago