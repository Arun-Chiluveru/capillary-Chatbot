# Scraped content from: https://docs.capillarytech.com/docs/members-standard-export-template

Getting Started

Suggest Edits

Databricks

Databricks is Capillary's data warehouse which provides solutions like working on SQL queries, scheduling data exports on FTP, and visualizing data with the help of notebooks. Along with this databricks allow users to connect and share data across BI tools and different databases.

Notebooks

Notebooks are a common tool in data science and machine learning for developing code and presenting results. In Databricks, notebooks are the primary tool for creating data science and machine learning workflows and collaborating with colleagues. Databricks notebooks provide real-time coauthoring in multiple languages, automatic versioning, and built-in data visualizations.

Accessing databricks

📘

Note

To get access to databricks, contact Capillary access team.

For databricks org access, contact your manager.

Links:

India databrick

EU databrick

SG/Asia-2 databrick

US databrick

Updated 2 months ago