# Scraped content from: https://docs.capillarytech.com/docs/loyalty-promotions

Badges in Membercare

Suggest Edits

Badges are a type of visual recognition used in loyalty programs to reward customers for their progress, specific actions or achievements. Customer can view their badges details from membercare.

To view a badge in Membercare, follow these steps:

Navigate to Membercare >> Incentives >> Badges. Under the Badges section, you can see all the details of the badges which are available for the customer.

Select the filter tabs to filter the badges based on the type

These are the available filters for badges:

Available to Enrol

TheAvailable to Enrol section includes the badges of the type Enrol and Issue where customer can enrol and then issue the badge. Customers can browse these badges, read their descriptions, and review the badges details. Only Enrol and Issue type of badges can be viewed here.

Available to Issue

The Available to Issue section includes the badges that can either be directly issued using the Direct Issue type or are already enrolled and ready to be issued to customers using the Enrol and Issue type. All badges from both the Enrol and Issue and Direct Issue types can be viewed here.

Issued

The Issued section includes badges that have been successfully issued to customers and are now active in the customer's profile. Customers can view these badges in their profiles, including detailed information about their benefits, validity periods, and status. When the validity period of an issued badge ends, these badges will expire.

Expired

The Expired section includes badges that are no longer active and have completed their validity periods. These badges remain accessible for reference purposes, allowing customers to review past achievements.

Click on a particular Badge to see the details of the badge, Badge's timeline and Additional details of the Badge. A quick view card on the left shows the following details. For example: Badge Name : VIP Creation Date and time : Nov 21, 2024 1:44 AM Summary of badge timeline : 6 times issued

Badge

You can view these information about the badge:

Badge Details

Badge's timeline

Additional details

Badge Details

Detailed information of the badges which includes, Badge ID, Description, Status, Start date, End date, Type, Owned by, Claimed by.

Attribute Description Badge ID Unique ID of the badge which is generated when you create the badge. Description Description of the badge. Status Status of the badge whether it is Active , Inactive or Expired . Start Date Timestamp indicating when the badge is active. End Date Timestamp indicating when the badge expires. Type Type of badge. Direct issue : A direct issue badge is directly awarded to customers without enrolling the customer to that badge. or Enrol and issue badges : Enrol and issue badges require customers to be enrolled in the badge first and then issue the badge to that customer. Owned By Module under which the badge is owned, including categories such as Loyalty , Loyalty Promotion , Referral Campaign , Broadcast Campaign , Journey , and Milestones . Claimed By Module where the badge was claimed. For example, Loyalty , Loyalty Promotion , Referral Campaign , Broadcast Campaign , Journey , and Milestones .

Badge's Timeline

Detailed timeline of all badge items which include Issual or Enrolment. Including badge issual, badge revocation, benefits linked with the badge and badge expiration. Multiple badge

Attribute Description Status Status of the badge item whether it is Live , Expired , Revoked . The status is independent for each issual or enrolment. Example: If the status of Issual 1 is LIVE, it is specific to that issual and not for the overall badge status. Issual/Enrolment expires on Indicates when the badge issual or enrolment will expire. Possible Values: On fixed date : Badge will expire on a specified date. After specific period from badge issual : Badge will expire after a specific period from the badge issual date. Along with badge : Badge expiry will be same as badge end date. Never expires : Badges will never expire. Expires on Timestamp indicating when the badge will get expired. Issual/Enrolment ID Unique ID of the badge which is generated when you issue or enrol the badge to a customer. Issued/Enrolled by Modules under which the badge is issued or enrolled, including categories such as Loyalty , Loyalty Promotion , Referral Campaign , Broadcast Campaign , Journey , and Milestones . Benefits linked Benefits linked with the badge. Revoked on Timestamp indicating when the badge is revoked.

Additional Details

Additional information about the badge. For example: Terms and Condition.

Updated 3 months ago