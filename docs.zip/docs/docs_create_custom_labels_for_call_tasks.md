# Scraped content from: https://docs.capillarytech.com/docs/create-custom-labels-for-call-tasks

Create custom labels for call tasks

Suggest Edits

You can create custom labels for each call task status. These labels will show up as statuses in Call Task campaigns.

To create a custom label for a call task status, follow these steps.

On the Engage+ home page, click on the setting icon and navigate to the Call task page.

856

In Status, choose the status for which you want to create a custom label.

In the Custom label, enter your preferred name for the chosen status.

Click Add to save the status mapping.

Updated over 1 year ago