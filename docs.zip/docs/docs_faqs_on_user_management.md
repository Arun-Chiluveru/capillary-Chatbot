# Scraped content from: https://docs.capillarytech.com/docs/faqs-on-user-management

Configuring Conditions

Suggest Edits

You can use logical operators to control a block's execution when it receives input from multiple parent blocks, which are blocks that precede and provide input to a child block.

Neo supports two logical operators: AND and OR. The AND operator ensures that the child block executes only when all parent blocks meet their conditions. In contrast, the OR operator allows execution when any one parent block provides input. Additionally, for an OR operator, only one parent executes at a time, if multiple parents try to execute simultaneously, the dataflow throws an error.

By default, Neo selects the AND operator.

Choosing an Operator

Click the radio button next to the desired operator.

Operator Behavior

AND Operator – The block executes only after receiving input from all its previous blocks.

OR Operator – The block executes as soon as it receives input from any of its previous blocks. The OR gate ensures that only one previous block executes at a time.

Updated 13 days ago