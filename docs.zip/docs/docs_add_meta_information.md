# Scraped content from: https://docs.capillarytech.com/docs/add-meta-information

Add Meta Information

Suggest Edits

📘

Applicable to all promotion types.

You can add any relevant information to a promotion using the promotion custom fields. It could be to store any promotion-related information such as T&C, Image URL, and offer URL.

See how to create custom fields in Cart Promotion Settings.

Add meta-information

Navigate to Additional Information.

Enter the values for required fields. Ensure that you enter all the mandatory fields to proceed.

532

Enter the field values and click Continue.

Updated over 1 year ago