# Scraped content from: https://docs.capillarytech.com/docs/searchfilter-campaigns

Search/Filter campaigns

Suggest Edits

You can search for campaigns by name. There are different filters available to fetch campaigns by created duration, status, marketing objective, and the user who created.

Search by campaign name

To search for a specific campaign, follow these steps.

On the Campaigns tab, scroll down to the Campaigns summary table.

In Search Campaigns, enter the name of the campaign to fetch. You will see campaign suggestions as you type.

749

Filter Campaigns

You can filter campaigns by active duration, status, marketing objective, and created user.

Filter by campaign duration

In the duration box, set the duration using Start Date and End Date. You will get the list of all campaigns that are/were active during that date range.

📘

It is not necessary to match the start date and end date of a campaign with that of the selected date range. You will see campaigns that were active even for one day in the selected date range.

801

Filter by campaign status

To see campaigns of a specific status, follow these steps.

Click (Advanced options).

Select the statuses by which you want to see campaigns - Live, Upcoming, and Lapsed.

Click Apply.

241

Filter by marketing objective

To filter the campaigns list by marketing objective, follow these steps.

Click (Advanced options).

In the Marketing objective, choose the objective by which you want to filter the campaign list.

Click Apply.

241

Filter by a user who created

To filter the campaigns list by created user, follow these steps.

Click (Advanced options).

In Created by, choose the user by which you want to filter the campaign list.

Click Apply.

241

Updated over 1 year ago