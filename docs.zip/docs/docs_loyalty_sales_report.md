# Scraped content from: https://docs.capillarytech.com/docs/loyalty-sales-report

Attributes - Customer Identity

Suggest Edits

Attributes on Customer Name

String Operators widely used with name attributes

The basic range of string operations serves to resolve the string attribute into a boolean outcome. These operators are inserted after the string attribute using the (.) notation e.g. currentCustomer.email.contains(".com")

Operator Definition contains Used to see if the string contains the defined value Matches This is used to perform regular expression-based matching on the string Exists Some proper value exists for this string (i.e. source passed a value that was not an empty string) notExists The string is either Null or Empty isNull checks if the string is Null i.e. it was not passed from the source isNotNull checks if the string is NOT Null

Name

Profile: currentCustomer Attribute: name Meaning: Customer's Full Name [ name = firstName + " " + lastName ] Type: String Sub-Attribute : NA Format: currentCustomer.[(Attribute).(Sub Attribute)].[ Operators ][VALUE]** Syntax : currentCustomer.name[Operator][Value]

Profile Attributes Sub- Attributes Operator Example currentCustomer Name NA contains currentCustomer.name.contains("akhil reddy") currentCustomer Name NA matches currentCustomer.name.matches("sak") currentCustomer Name NA == currentCustomer.name == "tripti"

Example 1 Write an Expression to check if the customer name has substring “nar”. Expression: currentCustomer.name.matches(“naresh silla”) Here, Profile -> currentCustomer Attribute -> name Sub Attributes -> NA String Operators -> matches Value -> naresh silla

Example 2 Write an Expression to check if the customer name is “Santosh kumar” Expression: currentCustomer.contains("Santosh kumar")

Example 3 Write an Expression to check if the customer name contains “shreya” Expression: currentCustomer.name.contains==“Shreya”

First Name & Last Name

Profile: currentCustomer Attribute: firstName Meaning: Customer's First Name [ name = firstName ] Attribute : lastName Meaning: Customer's Last Name [name = " "+lastName] Type: String Sub-Attribute : NA

Format: currentCustomer.[(Attribute).(Sub Attribute)].[ Operators ][VALUE] Syntax for First Name Attribute: currentCustomer.firstname[Operator][Value] Syntax for last Name Attribute : currentCustomer.lastname[Operator][Value]

Example 1 Example 1: Write an Expression to check if the customer name has the substring “nar”. Expression: currentCustomer.firstname.matches(“nar”) Here, Profile -> currentCustomer Attribute -> name Sub Attributes -> NA String Operators -> matches Value -> nar

Example 2: Write an Expression to check if the customer name is “Santosh kumar” Expression: currentCustomer.firstname.contains("Santosh")

Example 3: Write an Expression to check if the customer last name contains “desai” Expression: currentCustomer.lastname==“ desai” )*

Email

Profile : currentCustomer Attribute : Email Type : String Sub-Attributes : NA Operator: contains, exists, isEmpty, isNotNull, isNull, matches, notExists, “==” Meaning : Customer's email id or checks which organization is in the email of Customer Syntax : currentCustomer.email[Operators][Value]**

Attribute SubAttribute Operator Example email NA contains Contains - used to see if the string contains the defined value. Example: currentCustomer.email.contains("ashish.chelikani") email NA exists Exists - Some proper value exists for this string (i.e. source passed a value that was not an empty string) currentCustomer.email.exists() email NA isEmpty isEmpty - Similar to notExists currentCustomer.email.isEmpty(“”) email NA isNotNull isNotNull - checks if the the string is NOT Null i.e. some value was passed from is equal to 1source (even an empty string counts) currentCustomer.email.isNotNull(“”) email NA isNull isNull - checks if the string is Null i.e. it was not passed from source currentCustomer.email.isNull(“”) email NA notExists notExists - The string is either Null or Empty email NA == ( == ) returns true if both operands have the same value; otherwise, it returns false . The not-equal-to operator ( != ) returns true if the operands don't have the same value; otherwise, it returns false . currentCustomer.email==" [email protected] " email NA matches Matches - this is used to perform regular expression-based matching on the string. currentCustomer.email.matches(" [email protected] ")

Example: Write a condition to check if the customer email contains the string “SHR” Profile: Current Customer Attribute: Email Sub-Attribute: NA Operator: contains Rule: currentCustomer.email.contains(“SHR”)

Example: Write a rule to check if the current customer number of visits is equals to 1 and current customer email is not null. Profile: Current Customer Attribute: numberOfVisits and email Operator : == & isNotNull Rule: currentCustomer.numberOfVisits==1&&(currentCustomer.email.is.NotNull(“”))

External ID (externalId)

Profile : currentCustomer Attribute : externalId Type : integer/Alphanumeric Sub-Attributes : NA Operator: contains, exists, isEmpty, isNotNull, isNull, matches,notExists, “==” Meaning : Lets say to issue coupons to customers whose external ID contains a certain serial numbers (say 1234), use the following condition: customerCustomer.externalId.contains("1234") Syntax : currentCustomer.externalId[Operators][Value]

Profile Attribute Sub-Attribute Operator Meaning currentCustomer externalId NA contains Contains - used to see if the string contains the defined value Example: currentCustomer.externalId.contains("") currentCustomer externalId NA exists Exists - Some proper value exists for this string (i.e. source passed a value that was not an empty string) currentCustomer.externalId.exists() currentCustomer externalId NA isEmpty isEmpty - Similar to notExists currentCustomer.externalId.isEmpty(“”) currentCustomer externalId NA isNotNull isNotNull - checks if the the string is NOT Null i.e. some value was passed from source (even an empty string counts) currentCustomer.externalId.isNotNull(“”) currentCustomer externalId NA isNull isNull - checks if the string is Null i.e. it was not passed from source currentCustomer.externalId.isNull() currentCustomer externalId NA notExists notExists - The string is either Null or Empty currentCustomer externalId NA == ( == ) returns true if both operands have the same value; otherwise, it returns false . The not-equal-to operator ( != ) returns true if the operands don't have the same value; otherwise, it returns false . currentCustomer.externalID=="17783" currentCustomer.externalId!="" currentCustomer externalId NA matches Matches - this is used to perform regular expression based matching on the string. currentCustomer.internalId.matches("abc1223")

Example: Write a rule to check if the current customer number of visits is equals to 1 and current customer externalId is not null. Profile: Current Customer Attribute: numberOfVisits and externalId Operator : == & isNotNull Rule: currentCustomer.numberOfVisits==1&&(currentCustomer.externalId.NotNull(“”))

Example: Write a rule to check if the current customer contains a string “TRN13” Profile: Current Customer Attribute: externalId Operator : contains() Rule: currentCustomer.externalId.contains(“TRN13”)

Example: Write a rule to check if the current customer externalID exists Profile: Current Customer Attribute: externalId Operator : exists() Rule: currentCustomer.externalId.exists()

Mobile

Profile : currentCustomer Attribute : mobile Type : integer Meaning : Mobile number of a customer. Sub-Attribute: NA Operators: contains, exists, isEmpty, isNotNull, isNull, matches,notExists, “==” Syntax: currentCustomer.mobile.[Operators][Value]

Example: Write a rule to check if the mobile number of the current customer contains 98939756. Profile: Current Customer Attribute: mobile Operator : contains() Rule: currentCustomer.mobile.contains(“98939756”)

Example: write a rule to check if the current customer's mobile number exists. Profile: Current Customer Attribute: mobile Operator : exists Rule: currentCustomer.mobile.exists()

hasInstoreProfile

Profile : currentCustomer Attribute : hasInstoreProfile Type : Boolean Meaning : returns True, if the current customer is registered and has a instore Profile Sub-Attribute: NA Syntax: currentCustomer.hasInstoreProfile() Example: currentCustomer.hasInstoreProfile==true

Example: write a rule to check if the current has a Instore Profile Profile: Current Customer Attribute: hasInstoreProfile Type: Boolean Rule: currentCustomer.hasinstoreProfile()

hasWeChatProfile

Profile : currentCustomer Attribute : hasWeChatProfile Type : Boolean Meaning : returns True, if the current customer has a WeChat Profile Sub-Attribute: NA Syntax: currentCustomer.hasWeChatProfile()**

Example: write a rule to check if the current has a Instore Profile Profile: Current Customer Attribute: hasWeChatProfile Type: Boolean Rule: currentCustomer.hasWeChatProfile()

Updated over 1 year ago