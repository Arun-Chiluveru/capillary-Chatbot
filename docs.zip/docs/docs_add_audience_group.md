# Scraped content from: https://docs.capillarytech.com/docs/add-audience-group

Analyse reports Based on Audience Groups

Suggest Edits

Introduction

Insights+ gives the ability to filter or analyse the reports based on audience grouping. Audience is a group of customers, filtered on the basis of demographics, campaigns, transactions, and other activities. The audience filter can be applied to both standard and custom reports. Up to 3 audience group data can be simultaneously compared using Insights+. By leveraging audience analysis, businesses can gain insights into customer behavior, preferences, and engagement patterns.

In Insights+, audience groups can be compared, but their creation has to be done in Engage+. For more information on creating audience groups, click here.

📘

Note

Before comparing audience groups in Insights+, ensure they are created in Engage+ first.

Applications of audience group filter in reports

The audience group filter in reports serves several purposes:

Refine a report to display specific audience-related information.

Analyze customer behavior to improve sales and enhance brand value.

Utilize various audience group filters powered by Capillary's AI stack (AIRA) to forecast customer activities.

Determine target audiences based on their preferences for timing, products, and store locations.

Generate effective offers based on audience activity towards a specific brand or product.

📘

Note

All audience groups, including uploaded, combined, and filter-based groups, can be used as filters in reporting.

Applying an audience group filter in a report

To apply an audience group filter in a report, perform these steps.

On the Insights+ page, navigate to the desired report.

Open the report and click Add audience group to see the list of audience groups.



In the Audience Group list, search and select the audience group by name.



📘

Note

In a report, you can apply up to three audience group filters.

Click on the Audience group name to see a brief description of the audience group.



Click Done to apply changes. The applied audience groups are displayed at the top of the report.



1146

📘

Note

To create audience filters using the data from extended fields, please contact the Insights Sustenance and Data Science team.

Use cases

The following are the use cases that help you understand the feature.

Scenario 1

Consider a scenario where an organization wants to compare the purchasing patterns (based on products purchased) year-over-year (YoY) of a high-value customer group. This like-for-like (LFL) analysis can be accomplished using audience group filters.

Perform the following:

From the Insights+ page, open the sales report of interest.

Select an audience group filter from the compare audience list that has the Transaction date and time filter applied to it.

Now, you can see the product performance (based on product category) for an audience group (audience_demo) between a specific time duration (e.g. for January 2023 and January 2024).

If you do not have the audience group in the list, you can create an audience group filter from Engage+ with the Transaction date and time.



Scenario 2

Consider a use case where an organization wants to re-target an audience list with a minimum spend offer. To decide the appropriate minimum spend threshold for the offer, perform the following:

From the Insights+ page, open or create a report with an average transaction value-based banding of customers.

Select the audience list to see the distribution of customers with various bands to decide the minimum spend.

Now, you can see the shopping done by customers during a campaign (New Year Campaign) with value-based banding (<5000, 5000-7000, 7000-9000, and 9000).

If you do not have the audience group in the list, you can create an audience group filter from Engage+.

1154

📘

Note

The audience list keeps refreshing (in case of recurring campaigns), and while generating the reports, the audience version available nearest to the report end date is considered. In case, the report end date is prior to the date of audience creation, the report will use the first available instance of the audience. This can be used to perform pre-campaign analysis of the audience. For example, if a campaign began on June 1st, 2024 and the audience was created on June 2nd, 2024, you can also get reports for the reporting period before June 2nd, 2024 (i.e., May 1st, 2024 to May 31st, 2024). In this case, the report would use the first available instance of the audience i.e., of June 2nd, 2024.

Updated about 2 months ago