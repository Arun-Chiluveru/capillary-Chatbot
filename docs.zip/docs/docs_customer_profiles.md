# Scraped content from: https://docs.capillarytech.com/docs/customer-profiles

Introduction to Loyalty+

Suggest Edits

Loyalty+ is a platform that helps you incentivize your customers on the basis of their enrollment and engagement in the form of coupons and points. It lets you influence your customer lifecycle by rewarding them for different activities including transactions, and profile updates. Through effective loyalty programs, you can motivate your customers to become more loyal and increase repeat transactions.

Loyalty+ helps you treat your customers differently, track their behavior, monitor their interactions, and incentivize them accordingly creating genuine connections. Through effective loyalty programs, you can maximize customers' lifetime and maximize ROI.

With Loyalty+, you can grade your customers with loyalty tiers and depending on their purchase value and incentivize them separately by providing better benefits to highly loyal customers. It upsurges customer engagement with your brand and drives their interactions. The embedded rule sets with an expression editor provide complete flexibility in creating simple to any complex conditions that you want to evaluate to trigger an action. You can perform several actions such as activity-based tier upgrade, points allocation, communication, issue coupon, renew tier, issue points to referrer or referee, and more.

Loyalty programs are beneficial to both customers and brands as they not only provide benefits to customers but also build relationships with them.

Updated over 1 year ago