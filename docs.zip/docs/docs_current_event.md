# Scraped content from: https://docs.capillarytech.com/docs/current-event

Managing Badges

Suggest Edits

Deactivating and Activating Badges

Issuing Badges and Revoking via Loyalty Workflows and Promotions

Enrolling and Issuing badges from Campaigns

Historical Data Migration of Badges

Retro Enrolment and Issue of Badges

Updated 12 months ago