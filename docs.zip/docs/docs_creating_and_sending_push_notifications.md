# Scraped content from: https://docs.capillarytech.com/docs/creating-and-sending-push-notifications

Creating and Sending Push Notifications

Suggest Edits

To send push notifications, use Campaigns or Journeys on Engage+.

Push Notifications on Campaigns

Campaigns are designed to promote products or features and increase customer engagement through targeted messages. Push notifications within campaigns enhance both engagement and reach effectively.



To create or edit push notifications for a campaign, follow these steps:

Create a new campaign or edit an existing one.

In the Content section of your campaign, click on Add Creative and choose Push notification from the options.





Choose the Mobilepush Account to send the content.

Create a new template or choose from existing templates.

View the notification preview on the right side.

Click on Done to save the changes.

Push Notifications on Journeys

Journeys allow you to integrate push notifications into a sequence of interactions that take users through a personalized experience. Push notifications within journeys provide timely and relevant prompts based on user interactions.



To create or edit push notifications for a journey, follow these steps:

Create a new journey.

While configuring the journey, choose M-push to trigger push notifications.

Hover over the MPUSH block and click on the settings icon next to it.



Provide a unique Engagement Name and click on Add Creative.



Choose the Mobilepush Account to send the content.

Create a new template or choose from existing templates.

View the notification preview on the right side.

Click on Done to save the changes.

For more detailed information on using campaigns and journeys on Engage+, refer to the Capillary Documentation.

Updated 8 days ago

What’s Next

Optimizing delivery