# Scraped content from: https://docs.capillarytech.com/docs/getting-started-databricks

Incentive details

Suggest Edits

The Incentives tab on the Customer Single View page shows the complete summary of incentives that a customer received.

Points

Points tab shows details about all the points of the selected loyalty program with the time and date of the event. For MLP enabled orgs, you can use the loyalty program drop-down box to see points details in different programs.

You can view information about the points issued or redeemed time and the event associated with the points.



Points Schedule

The Point Schedule tab displays the schedule details for granting loyalty points to the customer.

You can click on the program to view information about the points expiry schedule, conversion schedule and trigger-based points.

Expiry schedule - Displays the points expiry schedule.

Conversion schedule - Displays promised points conversion schedules of a customer for across all programs of the org.

Trigger based points - Displays the summary of trigger-based points programs.



Coupons

The Coupons tab shows details about all the coupons of the selected loyalty program with the details of the event. For MLP enabled orgs, you can use the loyalty program drop-down box to see coupon details in different programs.

You can click on a coupon for more details such as coupon ID, store name, expiry date, coupon series, discount value, redeemed number of coupons, coupon status and transaction number associated with the coupon.

To search for a coupon, click the search icon and search using coupon series or coupon ID.



Cart promotions

Cart promotions enable brands to run modern-day promotions with a primary focus on items on the cart.



Gift Vouchers

The Gift vouchers tab enables brands to distribute or issue payment vouchers to their customers. The vouchers give you information about the gift vouchers issued, such as promotion ID, earned promotion ID, earned source etc.



Badges

The Badges are a type of visual recognition used in loyalty programs to reward customers for their progress, specific actions or achievements. These serve as a form of gamification and a sense of pride and accomplishment within the user, reinforcing the targeted behaviors and boosting engagement. To know more about Badges, visit here.



Updated 5 months ago