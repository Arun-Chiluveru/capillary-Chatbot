# Scraped content from: https://docs.capillarytech.com/docs/points-expiry

Loyalty guides

Suggest Edits

Guide, is something which shows direction. It could be for passing an exam, cracking an interview, achieving a goal, cooking a dish, etc..

In this section, you will find various guides that helps you to achieve / understand various items on a whole level. We will try to add as many guides as possible.

Have a good read!!

Updated over 1 year ago