# Scraped content from: https://docs.capillarytech.com/docs/delete-chart

Delete Chart

Suggest Edits

To delete a chart, follow these steps:

Navigate to Library > Charts.

Select the chart type - Normal, Migration or Funnel.

In Search Charts, search the chart to delete either from the list or search by the name.



Click Delete.



Confirm Yes to delete the chart.



Updated about 1 year ago