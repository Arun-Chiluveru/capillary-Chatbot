# Scraped content from: https://docs.capillarytech.com/docs/standard-templates-1

Modifying template & creating schedule (Step 3 of 3)

Suggest Edits

Once you select the required templates, you can modify each template to add or remove default dimensions, modify FTP location for each template, and customize the columns to be exported. You will also need to select the required custom fields.

📘

Note:

You cannot export customer level custom fields through transaction templates. However, you can export customer level extended fields through transaction templates.

Custom fields are not selected in a template by default.

To modify a template:

Once you select a template, you will see the option to modify it. Click Modify.

To save the file in a specific location, click, enter the folder name or path, and click Save. For more details, scroll down to the Choose the default location of the file in FTP location section.

In Based on, choose whether you want to export data based on Last Updated date or Event Date (not applicable for audience list export).



Last Updated: Use this to fetch records that are updated during a specified period.

Event Date: Use this to fetch records based on the actual event date. An event could be registration, transaction, points redemption, and so on.

For example, if a customer is registered on 1st Apr 2019, but it is synced to our system through Data Import on 15th Apr 2019, the event date of registration is Apr 1, 2019, and the latest updated date is Apr 15, 2019.

📘

Important Note:

It is important to understand the applicable date types based on the type of template:

Fact Template: Both Event Date and Last Updated date are applicable

Dimension Template: Both the Event Date and Last Update date are not applicable

Custom Template: Event Date is applied by default. You can modify the template to choose the desired date type

In the Preview table, you can see the fields that will be downloaded for the template. See the preceding note for more details

For each available KPI, you will see the KPI name as in the system. In Rename Field, you can set your preferred name to see in the exported file. For example, for the bill_conversion _date.day_of_month, I could have Daily Bill Conversion. You can also use Chinese names if required.



Click Save to save the template. Similarly, you can configure all the selected templates.

Click Create to complete the export job creation.

📘

The filename of an exported file will have the following naming convention.

schedulenametemplateName_timestamp. For example, DailySlabChangeSlabChangeLog2019-10-29-12-30-021572356331802.

Change the default location of the file in FTP location

By default, the data of each template is saved in the location set in FTP configurations. However, you can export the file to a specific folder in the default path as explained in the following procedure.

On the Modify Template page, click on the location icon.

817

You will see the default path with an option to enter the file location. You can add up to two folders.

Enter the path and click Save.

436

Updated 10 months ago