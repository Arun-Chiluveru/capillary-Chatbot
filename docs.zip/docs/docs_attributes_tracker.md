# Scraped content from: https://docs.capillarytech.com/docs/attributes-tracker

Badges Event Notification

Suggest Edits

You can configure event notifications for badges and send an event notification to the downstream application whenever a customer earns a badge. The event name is badgeEarned.

For a sample payload, refer to the documentation on Badges event notification.

Updated 7 months ago