# Scraped content from: https://docs.capillarytech.com/docs/faqs-1

FAQs

Suggest Edits

Messages

Offer

DLT

Cart Promotions

Updated over 1 year ago