# Scraped content from: https://docs.capillarytech.com/docs/advanced-filter

Advanced Filter

Suggest Edits

The Advanced Filter feature allows you to retrieve charts based on specific KPIs and dimensions. It aids to locate the charts with the KPIs and dimensions of your interest from the list of previously created charts.

To apply Advanced Filters:

From the left panel, click Library > Charts.

Click Advanced Filter.



In the Advanced Filter window, expand the List of KPIs drop-down box. From the KPI list select the desired KPI. The maximum KPI selection limit is 20. If you have more than 20 KPIs, select the appropriate KPIs from the sub menu.



Click List of Dimensions with Attributes to expand the drop-down box. Select the desired dimension and click Select. The maximum selection limit is 20 dimensions.



Click Apply.



A list of charts having the selected KPI and dimension combination is displayed.

Example: You want to locate charts having Currency Redeemed as KPI and Latest date updated as dimension. For that:

i. Expand the KPI drop-down box and select Currency Redeemed.

ii. Expand the dimensions drop-down box and select Latest Date Updated.

iii. Click Apply.

The system lists all the charts with the given KPI and dimension combination. Select the desired chart.

Updated about 1 year ago