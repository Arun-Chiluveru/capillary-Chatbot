# Scraped content from: https://docs.capillarytech.com/docs/configuring-issue-badges-request-workflow

Connect the streak to loyalty promotions

Suggest Edits

Linking a loyalty promotion to a streak follows the same process as linking milestones to a loyalty promotion.

More details on linking a promotion to a milestone

Customer activity in promotions: Target period elapsed.

Rules supported for Streaks in promotions:

currentEvent.streakName=="Name of the streak level provided in the UI"

currentEvent.streakExists("Name of the streak level provided in the UI")

currentEvent.isStreakAchievedEvent (similar to isTargetAchievedEvent)

Notes

Rules supported for the Milestones/Targets will also work for the "STREAKS" type of targets

(currentEvent.StreakName=="Streak level name" && currentEvent.isStreakAchievedEvent), this rule helps in configuring different benefits for achieving the different levels in the streak.

Customer activity is the "target period elapsed" while creating the promotion for streaks.

Target points allocation is the action to be used when the brand wants to give points based on different levels of the streak.

Under the "Milestones/Streak" & "Targets(s)" section of the target-point allocation action:

Select the option that exactly matches your streak name.

Under the "Streak-level" drop-down, select the appropriate level of the streak for which you are creating the target-point allocation action.



Once the streak is successfully created, and linked to a loyalty promotion, then the specified streak promotions will go live and start tracking customers for their activities.

Updated 11 months ago