# Scraped content from: https://docs.capillarytech.com/docs/viewing-badges

Grouping and Ranking in Rewards Catalog

Suggest Edits

Grouping and ranking are essential features in reward management that enable brands to organize and present rewards in a structured and visually appealing manner. These features empower users to curate customized catalogs that effectively showcases rewards to their audience, enhancing the overall user experience.

Grouping Rewards:

Grouping rewards allows brands to categorize them into distinct sections based on common themes, types, or purposes. This feature enables users to create a structure within their reward catalog, making it easier for customers to navigate and find relevant rewards. For example, rewards can be grouped into categories such as "Featured Rewards," "Exclusive Offers," or "Seasonal Rewards."

Ranking Rewards:

Ranking rewards enables brands to assign ranks for reward groups as well as ranks for the individual rewards in that group. By assigning ranks, brands can ensure that the most relevant or valuable rewards are prominently displayed to customers. This feature allows brands to highlight specific rewards or promotions based on their strategic objectives or user preferences. For instance, brands can prioritize certain reward groups assigning them higher ranks and can also prioritize rewards within a group.

What's New

Multiple Group Tagging: Link a single reward to multiple groups.

Group-Specific Ranks: Define ranks for rewards within each group.

Optional Features: Group tagging and rank assignment are optional and independent of individual reward ranks.

Enhanced API Responses: Return detailed group tags and ranks in API responses.

Benefits:

Enhanced User Experience: Grouping and ranking rewards create a more organized and user-friendly catalog, making it easier for customers to browse and engage with rewards.

Effective Promotion: By highlighting specific rewards through grouping and ranking, users can drive attention to key rewards or offers, increasing customer engagement and conversion rates.

Improved Navigation: Grouping rewards into categories and ranking them based on priority streamlines the browsing experience for customers, helping them find relevant rewards more efficiently.

For example, in the below screenshot, Recommended Products have a higher priority than Home & Kitchen Category. Within each defined group, rewards are sorted based on their rank.



Use Cases

Flexible Reward Tagging: Mark a reward with multiple groups and define ranks within each group to showcase rewards effectively.

Example: Reward 1 is tagged with Group 1 (Rank 1) and Group 2 (Rank 3). When fetching rewards for Group 1, Reward 1 appears first due to its higher rank within the group.

Individual Rank Sorting: When fetching rewards with sortOnRank=true, sort by individual rank first. If no rank is defined, use the creation date.

Example: Reward 1 (Rank 1) appears before Reward 2 (Rank 2) when sorted by individual rank, followed by rewards with no rank sorted by creation date.

Group-Specific Sorting: When fetching rewards for a particular group, sort based on the rank within that group. Rewards without a defined rank in the group will follow default sorting.

Example: For Group 2, sort as Reward 2 (Rank 2), Reward 1 (Rank 3), and Reward 5 (Rank 4).

Default Sorting: If no group or rank is defined, sort rewards by creation date.

Example: Rewards not tagged to any group are sorted by creation date, with more recent rewards appearing first.

Example Scenario

Groups Defined:

Group 1: Rank 1

Group 2: Rank 2

Group 3: Rank not defined

Rewards:

Reward 1: Group 1 (Rank 1), Group 2 (Rank 3); Created March 1; Individual Rank 1

Reward 2: Group 1 (Rank 2); Created March 2; Individual Rank 2

Reward 3: Group 1 (No rank); Created March 3; Individual Rank not defined

Reward 4: Group 3 (No rank); Created March 1; Individual Rank 3

Reward 5: Group 2 (Rank 4), Group 3 (No rank); Created March 4; Individual Rank 4

Reward 6: No group; Created March 1; Individual Rank not defined

Reward 7: No group; Created March 3; Individual Rank not defined

Retrieving Rewards:

With sortOnRank=true: Order by individual rank first.

Order: Reward 1, Reward 2, Reward 4, Reward 5, Reward 3, Reward 6

For Group 1:

Order: Reward 1 (Rank 1), Reward 2 (Rank 2), Reward 3 (No rank)

For Group 2:

Order: Reward 2 (Rank 2), Reward 1 (Rank 3), Reward 5 (Rank 4)

For Group 3:

Order: Reward 5 (No rank), Reward 4 (No rank), Reward 5 appears first due to recent creation date.

No Group:

Order: Reward 7 (Created March 3), Reward 6 (Created March 1)

Points to Note:

Group:

Group names must be unique and non-null.

Group rank is optional and non-mandatory, allowing flexibility in sorting.

Groups can be deactivated with the isActive flag.

Reward:

Group tagging and reward ranking are optional.

Individual reward rank is a separate feature from group-specific ranks.

Refer to the API documentation below:

Create Group

Update Group

Get Group by ID

Get all Groups

Create reward with Group and Reward Rank

Update reward with Group and Reward Rank

Get brand specific reward

Get brand rewards

Get available brand rewards

Get user specific rewards

Get user specific reward by id

Get purchased rewards for user

Get purchased rewards for user (New API)

Updated 8 months ago