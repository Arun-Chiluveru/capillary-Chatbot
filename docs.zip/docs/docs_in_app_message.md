# Scraped content from: https://docs.capillarytech.com/docs/in-app-message

In-app message

Suggest Edits

In-app messages are messages that appear as pop-ups when a customer is active on the app. They differ from push notifications, which display when a customer is inactive or active. The in-app messages are powered by Capillary's SDK. You can use the In-app messages when configuring campaigns.

Use Cases:

Marketeer intends to display an in-app communication to the customer when they first launch the app within a specified period, such as from June 1st to June 30th.

Marketeer aims to present an in-app communication to the customer when they share a product with a friend.

Configuring In-App Messages

On Engage+, go to the Home page and click on Creatives.

Select in app message.



Select the In-app Message Account to send the content. These accounts are set up by the Capillary CSM or configuration team.



Click Create New to configure a new message from scratch or Duplicate to modify an existing message.



In the Creative Name text-box, enter a name for the new in-app message.

Select the creative layout. This determines how the creative will be displayed on the screen. Choose the model for the creative layout. Options include center top banner, bottom banner, or full screen.

Select Android or IOS as applicable. After configuring content for any, you can copy the title and content and configure content for the other.

In the Title text box, enter a title for the in-app message.



Configure the media. You can add either a text message or an image.

For the message, in the Message text box, enter the message. You can also click Add label, to include dynamic tags.



If adding an image, click image and select an image from your computer or gallery. The image size should be 5 MB and in PNG, JPG, or JPEG format.



If required, add a deeplink (link to any page in the mobile app) to the content of the in-app message or image. The deep links are added by the Capillary CSM/config team and is available for selection in the drop-down.



Select Call to action if you want to add a primary button in the notification message.

Enter a button label. Select Deep-link or External link. Deep-link redirects the button action to a page within the mobile app. The external link redirects the button action to an external web page.

Click Save.

Click Create to finalize the in-app message.



The in-app message is now created.

Updated 9 days ago