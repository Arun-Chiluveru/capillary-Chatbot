# Scraped content from: https://docs.capillarytech.com/docs/attributes-namefirst-namelast-name

Profile : Current Tracker

Suggest Edits

Profile : currentTracker currentTrackerCondition (Tracker Profile) - Inside the Tracker set, this profile allows you to write conditions based on the properties of that particular tracker case.

Attributes based on Current Tracker:

Profile Attribute Link currentTracker trackedValue Learn More currentTracker trackerConditionName Learn More currentTracker trackerConditionPeriod Learn More currentTracker trackerCurrAggr Learn More currentTracker trackerName Learn More currentTracker trackerInitialPrevAggr Learn More

Updated over 1 year ago