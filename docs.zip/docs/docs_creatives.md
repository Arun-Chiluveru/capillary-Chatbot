# Scraped content from: https://docs.capillarytech.com/docs/creatives

Creatives

Suggest Edits

Creatives are a library of templates for all the different channels that Engage+ supports. You can access creatives across the org for any campaign or loyalty. With Creatives, you can manage your messages effectively and can bring in consistency in terms of design, structure, and styles adding a more professional look to your messages. This not only adds brand value but saves a lot of time and effort that is involved in recreating from scratch. You can completely customize the look and feel for each message across channels according to the intent and just modify the content while using it in a campaign or Loyalty communication. You can use creative management for multiple usages of templates like

Create SMS Template

Create Email Template

Create Mobile Push Template

Create Call Task Template

Create Line Template

Create Viber Template

Updated over 1 year ago