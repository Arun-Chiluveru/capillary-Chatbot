# Scraped content from: https://docs.capillarytech.com/docs/message-schedule

Message Schedule

Suggest Edits

Objective

Set a message delivery schedule. The message will be delivered based on the selected schedule. The schedule is a message delivery time frame. The schedule also includes repetitive and periodic delivery of campaign messages.

Updated over 1 year ago