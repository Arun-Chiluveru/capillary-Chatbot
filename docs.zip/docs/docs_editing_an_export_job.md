# Scraped content from: https://docs.capillarytech.com/docs/editing-an-export-job

Create Search Filter for Entities

Suggest Edits

Use Cases

Overview

Creating a Search Filter

Perform Search

FAQs

Updated about 9 hours ago