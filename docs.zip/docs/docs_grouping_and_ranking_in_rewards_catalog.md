# Scraped content from: https://docs.capillarytech.com/docs/grouping-and-ranking-in-rewards-catalog

Authentication

This page provides you with information on enabling basic auth and creating API client key and secret.

Suggest Edits

Capillary supports three types of authentication:

Basic

OAuth

Authentication for end-customer web and mobile apps

Basic authentication

In basic authentication, the till ID and password (in MD5 format) are used for authenticating the APIs. For information on creating a till ID and password, see Add till.

Enabling basic authentication

To enable or disable basic authentication, perform the following:

Log on to InTouch of your cluster.

Navigate to the Profile icon > Organization Settings > Tools > Authentication.



Click the API client tab.

Click Modify .



Use the Enable Basic Authentication toggle switch to enable or disable basic authentication. By default, basic authentication is always enabled.



OAuth authentication

OAuth (Open Authorization) is a standardized framework that enables secure and controlled access to resources, such as data and services, without requiring the sharing of sensitive credentials, like passwords.

In OAuth, API client key and secret or access token are used for API authentication.

Creating an API client key and secret

Perform the following:

Log on to InTouch of your cluster.

Navigate to the Profile icon > Organization Settings > Tools > Authentication.



Click the API client tab.

Click Register.



In Client name, enter a name for the client.



In the Description, enter a short description of the client.

In Token expiry duration, set the default expiry for the tokens created for the client. By default, the maximum duration of an access token that you can set is configured as 60 minutes. An error message is displayed, if you try to set the token expiry duration for more than 60 minutes. This is for /v3/oauth/token/generateonly. For information on creating an access token, see Generating access token.



📘

If required, you can raise aticket and set the maximum token expiry duration that you can set to 30 days. You can set the duration in minutes, hours or days. An error message is displayed if you try to set the maximum duration for more than 30 days.



🚧

For security reasons, Capillary does not recommend setting the token duration for more than 60 minutes.

In Default till code, enter default till code for the API and click Validate. If a till code is not passed in the API header, the default till is used for API attribution.

Select the default till code check box to use this till code for API attribution, If an invalid till is passed in the API header.

From the Access group drop-down, select the appropriate access group for your API client. For information on access groups, see Access group. This access group restriction is applicable only for the API client and not the till.



Click Next. The Client key and Client secret are generated for the client.



Copy the Client key and client secret and use it for authentication (OAuth).

🚧

After the client key and secret are generated, if you exit the API Credentials page, you cannot access the client secret again for that client

Click Done to close the screen.

To create more API client accounts, click New API Client.





🚧

After the client key and secret are generated, if you exit the API Credentials page, you cannot access the client secret again for that client

Creating an access token

You can use the API client key and secret and create an access token for authentication. For information on creating an access token, see Generating access token.

Updated over 1 year ago

What’s Next

Access group