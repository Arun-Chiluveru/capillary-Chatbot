# Scraped content from: https://docs.capillarytech.com/docs/line-configuration

Configuration

Suggest Edits

Once you have set up your LINE developer account and created a Provider, Channel and Webhook, configure Capillary to work with LINE.

The configuration procedure includes the following steps:

Setting up LINE Source Account on InTouch

Registering a LINE User on InTouch

Creating a LINE Gateway

Registering a User Without a LINE Profile on Capillary

Setting Up a Webhook in the LINE Developer Account

Setting Up a LINE Source Account on InTouch

Setting up a LINE source account on InTouch involves configuring the LINE channel details obtained from the LINE developer platform.

This step is required to establish a functional connection between your LINE account and Capillary.

To set up a LINE source account, follow these steps:

Log in to InTouch and navigate to Organization Settings > Channel Configurations.



From the Channel List, select LINE.

👍

Tip

Use the search function to find it quickly .

Click on Add Account in the top right and enter an Account Name.



Enter the Source Account ID, Channel ID, and Channel Secret from the channel created on the LINE Developers Console.

Click Submit to save the changes.



Registering a LINE User on InTouch

To register a LINE user on InTouch, set up the LINE app, create an account if you don’t already have one, and scan the channel's QR code to connect with the LINE channel.

Ensuring that both sources are correctly mapped is crucial for integration between LINE and InTouch.

To register a LINE user on InTouch, follow these steps:

Download and install the LINE app.

Create an account by providing your mobile number, if you do not have an existing LINE account.

Scan the QR code for the target LINE channel using the LINE app.

📘

Note

The QR code for the channel is available on the LINE Developer Platform.



On your mobile device, click Add to send a request to the LINE channel when prompted.

📘

Note

The request can be viewed using the Webhook URL. userid is the unique identifier of a LINE account for the user.

On InTouch, register a customer using the customer registration API and the mobile number associated with the LINE app. Set the source as INSTORE.

Once the INSTORE profile for the customer is created, use the customer registration V2 API to register the same user with the source set as LINE.

Check the Member Care section for the registered customer to confirm that both sources (INSTORE and LINE) are mapped to the same customer.



📘

Note

The addition of a LINE user on InTouch can be automated as needed.

Creating a LINE Gateway

Creating a LINE Gateway is required for managing message delivery through the LINE channel

To create a LINE gateway on InTouch, follow these steps:

Login to InTouch and navigate to the Gateways page.

Under Gateway Settings, choose LINE from the Gateway drop-down menu.

Define the Gateway Weight (the ratio in which messages will be delivered).

Define the Start and End Time.

Click on Submit to create a LINE Gateway.



You can now include the customer in any campaign lists and contact them via the LINE channel.

Setting Up a Webhook on the LINE Developer Platform

To set up a webhook on the LINE developer platform, follow these steps:

Configure the Webhook Setup the webhook URL for the specific LINE channel. This webhook will capture events for when the user opts in or out of the channel.

Manage Subscription Status

Use the LINE user ID from the API response to update the subscription status on Capillary via middleware.

If the user does not exist in the system create an INSTORE and LINE profile using the customer registration API.



Updated 8 months ago

What’s Next

Sending Campaign Messages