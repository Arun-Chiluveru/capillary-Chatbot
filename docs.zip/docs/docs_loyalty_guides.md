# Scraped content from: https://docs.capillarytech.com/docs/loyalty-guides

Loyalty+ settings

In this, information of the settings present in the Loyalty+ page of CRM will be available.

Suggest Edits

To go to Loyalty+ settings,

Open the CRM portal by logging in.

Go to Loyalty+ module by clicking on the 3*3 dots symbol present on the left side of the page.

Once the Loyalty+ page is loaded, on the right top corner, you can see the settings symbol.

Click on that symbol, you will be on Loyalty+ settings page.

Creation/deletion/editing of custom fields.

First of all, what are custom fields?

Custom fields are the fields which won't be available by default to all organisations unlike the standard fields which will be available by default. As they name suggested, they are meant for customisation as per the brand's needs.

To understand with an example, a field which is very much required for a diamond brand (like Joyalukkas) might not be necessary for an electronics brand (like Croma).

So for Joyalukkas, a custom field (let's say, diameter of the diamond) need to be created for their activities & actions. These fields are relatively very easy to create, and have 3 primary actions:

Creation of custom field

Editing the custom field

Deleting the custom field

Following media helps in understanding how to do that:



Updated over 1 year ago