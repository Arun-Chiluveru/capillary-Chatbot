# Scraped content from: https://docs.capillarytech.com/docs/push-notifications

Push Notifications

Suggest Edits

Overview

Push notifications are messages sent to a user’s device, alerting them to new content, updates, or important events. Push Notifications effectively reach customers, keeping them engaged and informed about your campaigns.

Push notifications serve several key purposes:

Informing: Delivering important updates or alerts to users in real-time.

Engaging: Encouraging user interaction with the app through time-sensitive and relevant messages.

Re-engaging: Encourage inactive users to return to the app with personalized content or offers.

Promoting: Highlighting new features, products, or promotions to drive user engagement.

Types of Push Notifications

Standard Push Notifications

Basic text-based notifications that appear in the notification center. These are useful for simple alerts, reminders, and updates.



Image Notifications

Notifications with an embedded image that appear in the notification center. These are useful for visual promotions and driving engagement.



Rich Notification

Advanced notifications that include interactive elements such as Call to Action (CTA) buttons, quick replies or input fields. These enable user interaction within the notification to encourage user engagement.



Use Cases

Initial Onboarding

Push notifications effectively encourage users to complete their profile and pending onboarding tasks.



First Purchases

Use push notifications to encourage users to make their first purchase.



New Features and Updates

Push notifications inform users about new features and updates in the app.



Limited Offers and Promotions

Inform users about offers and discounts on your products to drive immediate action.



Elements

This section explains the essential elements of push notifications: deep external links, obtaining user permissions, managing push tokens, and adhering to platform regulations. Understanding these elements will help you create effective and compliant push notifications.

Deep Links and External Links

Deep Link

A deep link sends users directly to a specific in-app location or landing page. When users click on an interactive element, such as a rich notification or link, it redirects them to the specified app screen or functionality.



External Link

An external link sends users to an external website. When users click on an interactive element, such as a rich notification or link, it redirects them to an external website or app.



Push Notification Regulations

Push notifications can be intrusive as they appear directly on customers’ phones through your app. Each platform (Android and iOS) have specific guidelines for sending push notifications.

Ensure that push notifications comply with the Apple App Store and Google Play Store policies for using push messages for advertisements and promotions.

Apple App Store 4.5.4 Push Notifications must not be required for the app to function, and should not be used to send sensitive personal or confidential information. Push Notifications should not be used for promotions or direct marketing purposes unless customers have explicitly opted in to receive them via consent language displayed in your app’s UI, and you provide a method in your app for a user to opt out from receiving such messages. Abuse of these services may result in revocation of your privileges. 4.10 You may not monetize built-in capabilities provided by the hardware or operating system, such as Push Notifications, the camera, or the gyroscope; or Apple services and technologies, such as Apple Music access, iCloud storage, or Screen Time APIs.

Google Play Store Unauthorized Use or Imitation of System Functionality: We don’t allow apps or ads that mimic or interfere with system functionality, such as notifications or warnings. System-level notifications may only be used for an app’s integral features, such as an airline app that notifies users of special deals, or a game that notifies users of in-game promotions.

Updated 20 days ago

What’s Next

Getting Started