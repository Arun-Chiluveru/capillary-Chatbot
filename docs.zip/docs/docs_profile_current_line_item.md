# Scraped content from: https://docs.capillarytech.com/docs/profile-current-line-item

Glossary of Terms

Suggest Edits

Term Description enrolEventDate Refers to the specific date when the actual event occurred for enrolling a customer in the badge program. This date marks the occurrence of the event that initiates the customer's enrollment in the badge system. IssueEventDate Refers to the specific date on which the customer performed an activity or took an action to qualify for and receive a badge. This date marks the occurrence of the relevant activity that triggers the issuance of the badge.

Updated about 1 year ago