# Scraped content from: https://docs.capillarytech.com/docs/share-report

Share Custom Report

Suggest Edits

You can share a custom report with other Insights + users of your organization. You can grant either view-only access (View permission) or both view and edit access (Edit permission). Additionally, you can revoke a user's access to a report when necessary.

To share a custom report:

On the Insights+ page, navigate to the custom report you want to share and open it.

On the top-right of the page, click the More Options icon and click Share Report.



Select your intended users and grant them the Viewer or Editor access.



Click Done.

To edit the permissions, open to the desired report, click Edit > Share. This displays all the recipients, with whom the report is currently shared. Click and expand the permissions dropdown and select from Viewer, Editor and Remove options.



Click Done.

Updated 7 months ago