# Scraped content from: https://docs.capillarytech.com/docs/managing-badges

Issue Catalog Reward from Loyalty Workflow

Suggest Edits

You can issue rewards through Issue Catalog Reward using the following:

For milestones, streaks, and behavioural events, use Loyalty Promotions flow.

For other events, use Loyalty Program workflows.

For more information, refer to the Loyalty Workflow documentation.

Updated 4 months ago