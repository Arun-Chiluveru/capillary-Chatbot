# Scraped content from: https://docs.capillarytech.com/docs/advanced-capping

Attributes - Custom Field

Suggest Edits

currentCustomFieldValue

Profile : currentEvent Event in workflow : Customer Update** Attribute : currentCustomFieldValue Type : Boolean Meaning : Value of custom field after updating Sub-Attribute: Custom Field Name and Field Value Syntax: currentEvent.currentCustomFieldValue("Custom Field Name","Field Value")** Example: currentEvent.currentCustomFieldValue("age","26")**

Example: If the event is "Customer Update", Write a rule to check that the custom field "gstin" number value is changed from 342WER to "8932FHDKS" Profile: currentEvent Attribute: currentCustomFieldValue custom field name: gstin Updated custom field value : "8932FHDKS" Rule: currentEvent.currentCustomFieldValue("gstin","8932FHDKS")

previousCustomFieldValue

Profile : currentEvent & Event in workflow: Customer Update Attribute : previousCustomFieldValue Type : Boolean Meaning : Customer's mobile number before updating Sub-Attribute: Custom Field Name and Field Value Syntax: currentEvent.previousCustomFieldValue("Custom Field Name","Field Value") Example: currentEvent.previousCustomFieldValue("age_group","value")**

Example: Example: If the event is "Customer Update", Write a rule to check that the custom field "gstin" number value is changed from 342WER to "8932FHDKS" Profile: currentEvent Attribute: currentCustomFieldValue custom field name: gstin Previous custom field value : "342WER" Rule: currentEvent.currentCustomFieldValue("gstin","8932FHDKS")

Updated over 1 year ago