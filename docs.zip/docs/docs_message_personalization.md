# Scraped content from: https://docs.capillarytech.com/docs/message-personalization

Message personalization

Suggest Edits

Message Personalization helps in reaching out to end customers in the most effective manner based on products purchased and shopping store(s). This enables Intelligent Personalization strategies to engage loyal customers regularly and contributes towards cross-selling and upselling of products.

For example, you can use personalization when a store running offers need to share personalized offers with customers who shop at the store, based on the products they purchase.

📘

To enable campaign personalization for an organization, you need to raise a request with the account managers/CS team. The CS team can then create an internal request to the product team as a ticket.

Create Personalized Message

To create a personalized message, to enable Optimization Strategy and Personalization.

1033

Click Next to proceed. You will see the options available for Personalization.

528

Store/Geo: This option lets you target customers who will shop at your preferred stores and zones.

Products: This option lets you target customers who will purchase a specific product.

Both Store/Geo & Products: You can select both options to target customers who purchase a specific product(s) in your preferred stores.

Send messages to customers who shop at a particular store or zone

Select Store/Geo from the personalization options.

524

Click Create personalization.

Click Creative to configure the message (for a channel) that you want to send and click Done. You will see an option to select a store.

556

Click Select store to add your preferred stores.

329

Select stores that you want to associate with the message using the following options. The message is sent to customers only when they shop in any of the selected stores.

Stores: Click Stores and select your preferred stores from the list.

Zone: Click Zones and select your preferred zones from the list. It considers all stores of the selected zone.

📘

You can select both stores and zones if required.

316

📘

You can also search for a store or zone using the Search box.

You can see the number of stores and zones (categories) selected above Done button.

Click Done to save the changes and proceed.

Send a message to customers who shop for a particular product

Select Products from the personalization options.

522

Click Create personalization.

Click Creative to configure the message (for a channel) that you want to send and click Done. You will see an option to select products.

430

Select products that you want to associate with the message. The message is sent to customers when they purchase any of the selected products. You can select products by category and sub-category. Select the option by which you want to select products and check your preferred categories or sub-categories as shown in the following two screenshots.

340

331

Click Done to save the changes and proceed.

Send message to customers who shop at a particular store and bought a specific product

In the personalization options, select both Store/Geo and Products.

523

Add Creative. You will see two options - select store and select product. Refer to the previous sections to know how to select preferred stores and products.

565

Updated over 1 year ago