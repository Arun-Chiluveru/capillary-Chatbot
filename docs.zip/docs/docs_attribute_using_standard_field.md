# Scraped content from: https://docs.capillarytech.com/docs/attribute-using-standard-field

Viewing Badges

Suggest Edits

Viewing badges list (Badge universe)

The badges home page lists all the badges configured for the brand along with their details such as badge name, owner of the badge, duration, status, issue expiry, badges issued, last updated on and last updated by.



Below is the description of all the fields on the above screen:

Column No Description 1 Name of the badge Owner of the badge : The module for which the badge is created. It can be Loyalty, Loyalty Promotions, Milestones, Campaigns, Journeys. Defining an owner is mandatory 2 Duration : Start date and end date of the badge Status : Status of the badge based on the duration of the badge, it can be upcoming, live and ended 3 4 Issue expiry : This is the expiry of the badge once the badge is issued to the customer. This expiry is specific to the customer based on the type of issue expiry (fixed date/along with badge end date/relative/never expires) 5 Badges issued : No of badges issued from the badge series. This data is synced every 2 hours. 6 Last updated on : The date on which badge was last updated Last updated by : User by which badge was last updated

Badges on the listing page can be filtered by the below parameters:

Filter Description Status Status of the badge based on the duration of the badge, it can be upcoming, live and ended Activation Status This is the activation status of the badge on top of the status of the badge. A badge can be active or inactive. Live, upcoming, ended badges can be active but only live and upcoming badges can be inactive.



You can filter badges based on the Badge issue type, Owned by and Claimed by by selecting the Advanced filters

Advanced filters

icon.



To view the the owner and claim details for a particular badge, click on the i icon against the badge owner

For a badge to be claimed by a particular module, first the owner has to be defined and then that module can claim it.

A badge can have multiple owners and claims

Once an owner is defined, it can’t be removed or replaced, but more owners can be added to the badge.

Once a claim has been added for a badge, it can’t be removed or replaced, but other modules can still claim it.

The claim gives the information of exactly where the badge is being used/claimed. For example, in the below screenshot, the badge has been claimed in supermarket loyalty program : TransactionAdd and CustomerRegistration events



If a badge owner is defined, but claims are not yet added then it will be shown as below : Not claimed



We can see the list of badges that were claimed from Audience Campaigns and Journeys using the tooltip and the 'View Badge' option.



Viewing badge detail

You can click on a badge to view all the details of the particular badge.

In the Configuration tab, there are three sections:

Basic details

Images : Unissued, In progress and Issued

Name : Name for the badge. This is a mandatory field.

Description : Detailed description of the badge. This is an optional field.

Duration

start date of the badge. Once a badge is live, start date of the badge can’t be changed. This is a mandatory field and has to be in the future only as per current date and time.

expiresOn : Expiry of the badge which defines by when can the badge be issued. This can be changed even when the badge is live. This is a mandatory field.

Badge issue type

Enrol & Issue : Selected customers are enrolled for these badges, which are then issued once they fulfil the issual condition

Directly issued without enrolment : Badges are not restricted to any specific audience. They can be issued directly to anyone who fulfils the issuance criteria

Enrolment expiry : This is the duration within which a customer must complete the activity for the badge

Owner and Claimed by :

Owner : The module(s) for which the badge has been created

Claimed by : Module(s) which have claimed/used the badge



Issue badges

Issue expiry : The is the duration until which the customer will have the badge once issued to them

Badges Issued : No of badges issued to the customers from the badge series

Issue limit: You can set an individual or across all customer limit for issuing the badge within a fixed or moving window.

Customer limit : Overall limit and rolling limits both are supported. Brands can define the restrictions in the combination of the below options.

Fixed Window: With a fixed window, badges must be issued within a specific, predetermined time period.

Moving Window: A moving window, on the other hand, offers more flexibility. It tracks performance over a rolling time frame, such as the last 30 days. This allows users to meet badge requirements continuously as long as they stay within the moving window.

Across Customer Limit : Overall limit and rolling limits both are supported. Brands can define the restrictions in the permutation combination of all the below options.

Fixed Window: With a fixed window, badges must be issued within a specific, predetermined time period.

Moving Window: A moving window, on the other hand, offers more flexibility. It tracks performance over a rolling time frame, such as the last 30 days. This allows users to meet badge requirements continuously as long as they stay within the moving window.



In the Information tab in view mode, you can find the Badge ID, creation date and creator of the badge. You can also copy the badge ID directly from here like below.



Updated 5 months ago