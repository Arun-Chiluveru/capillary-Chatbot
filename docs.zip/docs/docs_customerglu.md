# Scraped content from: https://docs.capillarytech.com/docs/customerglu

Encrypt PII data

Suggest Edits

You can enable the CONFIG_IS_PII_ENCRYPTED configuration to encrypt the customer Identifiers such as mobile, e-mail and external id. When this configuration is enabled, validations on the encrypted data will not be performed.



Updated 8 months ago