# Scraped content from: https://docs.capillarytech.com/docs/earned-badges-for-customer-template

Edit/Delete event notification

Suggest Edits

You can modify an existing event notification to change headers, Webhook URL, and add or remove events.

Edit event notification

To modify an event notification, follow these steps.

On the Events Notification page, scroll to the event notification that you want to modify. You can use the Search box if the list is too long

Hover on the ... icon and click Edit.

816

Modify the required fields and click Save.

Option Description Webhook URL Enter the Webhook URL that you want to associate with the event notification. Header (Key, Value) Enter the required headers as keys and values. Add Events Select the events to notify. Click Add > select events that you want to tag to the notification >Click Done .

📘

You cannot modify an event name.

Delete event notification

To delete an event notification, ... icon of the event notification that you want to delete.

Click Delete.

816

Updated over 1 year ago