# Scraped content from: https://docs.capillarytech.com/docs/stop-message

Stop message

Suggest Edits

Once a campaign and a message is created, the message is send for approval. The campaign and the associated message (awaiting approval, approved, stopped, completed rejected) is displayed under the campaign tab. The user with message-approving privilege role can edit, approve, stop and reject a message.

To stop a message, refer the followings.

940

On the dashboard click the Campaigns tab.

Search the campaign, and then click on it.

Go to the message row that you want to stop.

In the message row, hover the mouse on the menu button (three dots) and then click on the Stop button.

The message status will be changed to "Stopped."

971

Updated over 1 year ago