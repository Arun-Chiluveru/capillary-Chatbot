# Scraped content from: https://docs.capillarytech.com/docs/external_facts

Issue & update cards

Suggest Edits

Member Care lets you issue cards from an active card series to a customer. You need to assign a source for issuing cards. To ensure security, we have also enabled OTP authentication for card issual.

Card Issual Settings

Assign source for card issual

To set a source for issuing cards:

On Member Care, navigate to Settings > Card Issual Settings.

In Select source & account for card issual, choose the source account that you want to tag for issuing cards.

500

Enable OTP for card issual

Navigate to the Card Issual/Linking OTP settings option.

Enable Card Issual/Linking OTP settings if you want to validate card issual and linking through OTP and choose the channel to send the OTP.

SMS: OTP is sent to the customer's registered mobile number.

Email: OTP is sent to the customer's registered email ID.

Both: OTP is sent via both channels

462

Click Save.

Issue card to customer

On Member Care, search for the customer to whom you want to issue a card.

In Select Actions, click Issue New Card.

1103

Issue manually generated card number

Select Link card number to customer and enter the card number to issue.

463

Enter the card number and click Check availability.

470

In Select Card Label, choose the desired card status.

Click Send OTP to send an OTP to the customer via the configured channel (SMS/ Email ID) and in OTP, enter the OTP received by the customer. This field appears only if Card Issual/Linking OTP settings is enabled.

385

Click Submit.

Issue card from an auto-generated card series

Select Generate and link card number.

328

In Select Card Series, choose the series from which you want to issue the card.

In Select Card Label, choose the status label that you want to associate with the card.

Click Send OTP to send an OTP to the customer via the configured channel (SMS/ Email ID) and enter the OTP received by the customer. This field appears only if Card Issual/Linking OTP settings is enabled.

Click Submit. An auto-generated card is issued to the customer displaying the card number.

📘

Note:

You cannot issue cards from a series beyond the allowed limit - this includes overall cards and active cards per customer.

Updated over 1 year ago