# Scraped content from: https://docs.capillarytech.com/docs/marketing-objective

Marketing objective

Suggest Edits

The marketing objective is an option to define the purpose of your campaign.

1084

Marketing objective Description Boost Sales To increase the overall sales. Campaigns like - EOSS, Deep discounts are an example of this Acquire customers Acquire new customers for your brand. Eg. Any acquisition campaign, referral, etc Promote specific products Promote a specific product, brand, or category eg. new shoes collection, winter launch, etc Collect feedback from customers Collect feedback from customers to analyze their experience Improve retention Send offers, and coupons to retain existing customers like ATV, ABV booster, RFM campaigns Winback lapsed customers Send promotional offers to lapsed customers Capture customer information For data collection like - Date of birth, gender, interest, anniversary, etc Send greetings to customers Festival greetings such as Festivals, Birthdays, Anniversary Increase store visits Promote a specific store, city, or zone to increase the footfall

📘

Note: If you are selecting "Promote specific products" or "Increase store visits" as a marketing objective, then refer to the following steps.

Promote specific products: To promote a specific product, refer to the following.

Click Promote specific products.

Select a category and/or item code, and then click on the menu expand icon '>'.

Select one or more products, which you want to promote through your campaign, and then click Done.

Review the selected product and/or item code, and then click Confirm.

1344

Increase store visits: To increase the store visits, refer to the following.

Click Increase store visits.

Select one or more options from the list, and then click on the menu expand icon '>'. Ex: Select store, and/or zn_sub_zone.

Select the store, and/or zone, which you want to promote through your campaign, and then click Done.

Review the selected store and/or zones, and then click Confirm

1313

Updated over 1 year ago