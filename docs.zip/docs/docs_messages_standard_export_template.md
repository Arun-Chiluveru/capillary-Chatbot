# Scraped content from: https://docs.capillarytech.com/docs/messages-standard-export-template

FAQs

Suggest Edits

Is there a scenario where a customer is mistakenly flagged as fraud? What happens in that case? A: Yes, customers may be mistakenly flagged as fraud. The suspected fraud list is shared with the brand for investigation and confirmation. If a customer is wrongly marked as fraud, their status can be corrected using MemberCare.

Are there any performance metrics like false positive rates or detection accuracy? A: No, performance metrics such as false positive rates or detection accuracy are not applicable because this is a rule-based system, not a prediction-based model.

Is Fraud Management available for all brands by default? A: Yes, Fraud Management is available for all brands. However, brands must provide the threshold values for the predefined rules to activate this functionality.

What are the limitations of this fraud management system? A: These are a few limitations of fraud management system:

The system supports only 13 predefined rules.

Complex rules are not directly available and require external tools like Databricks for implementation.

This is a rule-based system and does not use predictive modeling.

Updated 4 months ago