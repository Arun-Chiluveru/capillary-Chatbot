# Scraped content from: https://docs.capillarytech.com/docs/advanced-loyalty-templates

View tier configuration

Suggest Edits

To view the tier configuration, follow these steps:

On Intouch, navigate to Menu > Loyalty+ > Programs.



In Programs, select the program for which you want to view the tier configuration.



Under Tiers section, you can see the configuration of the tier program.



The first tier is the default tier and in the second tier, you can see the eligibility criteria which is the same for all tiers along with the conditions that were configured. Each tier is interconnected, which shows the sequential flow, the arrow also leads to downgrading information, displaying the downgrade condition.

Updated 11 months ago