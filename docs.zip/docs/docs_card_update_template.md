# Scraped content from: https://docs.capillarytech.com/docs/card-update-template

Fetch import details by import ID

Suggest Edits

Data Exchange Framework allows you to fetch details of an import using import id.

To fetch an import detail

On the Settings page, click Master Data Management > Import File Details.

In the File Id drop-down box, choose the import id for fetching details.

The complete list of data uploaded will appear in the drop-down box

Click Submit

The complete details of that particular import will be displayed on the same page as shown in the following figures.

This table shows the complete details of the status of the report

978

These tables displays the individual details of the file import like basic details, profile details, file properties, mapping details, template mapped and FTP configuration details. Click on each table to expand or collapse the detailed view.

980

Updated over 1 year ago