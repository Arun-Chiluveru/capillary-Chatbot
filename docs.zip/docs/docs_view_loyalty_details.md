# Scraped content from: https://docs.capillarytech.com/docs/view-loyalty_details

Event Notification Block

Suggest Edits

The Event Notification Block (ENB) is a block that helps to retrieve events from Kafka from specific topics, even before it hits the webhook of consumers. This helps to process the events within Connect+ before it reaches Capillary’s event notification.

About Kafka

Kafka is a software framework where data is published and stored. In Kafka, event data are grouped into specified topics called Kafka topics. A Kafka topic is a channel where specific event data is stored and streamed. Each Kafka topic has a unique name.

Fields Description Kafka Topics comma separated A dropdown field where you can select one or more Kafka topics. Each topic has a checkbox—by checking the ones you need, the event will be added. This field specifies the event names (which correspond to Kafka topics in the event notification system) that you want to retrieve events from.





Updated 17 days ago