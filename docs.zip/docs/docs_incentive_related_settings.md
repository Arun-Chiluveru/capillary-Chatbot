# Scraped content from: https://docs.capillarytech.com/docs/incentive-related-settings

Incentive related settings

Suggest Edits

This article helps you with the complete information on Incentive related settings.

To navigate to the Incentive settings page -

On the Engage+ page, click the Setting icon and navigate to the Incentives page.

Navigate to the setting that you need to modify. For detailed information on each setting, refer to the following articles.

See the following sections to know about each options of Incentive settings.

Default resend message

Configure the default message to be sent to customers when a coupon is reissued. You can also Preview the message to confirm whether the message is looking as desired and make necessary changes if required.

Sync offers with InStore

To sync offers or incentives that are created or added on Engage+, enable Sync offers to Capillary InStore client toggle button.

1074

Auto-generated coupon settings

For auto-generated coupon codes, you can set the coupon code length, type, and the information regarding the offer.

On the Incentives page, click Settings for automatically generated coupons.

OPTION DESCRIPTION Code type Select your preferred character type in the coupon code. _ Numeric Codes: Select this to have coupon codes only in numeric characters. For example, 12345678. _ Alphanumeric Codes: Select this to have coupon codes in alpha-numeric characters. For example, ABCD1234. Default code length Set the length of the coupon code. Recommended length: 5-7 characters Extended fields Select the fields that you want to include with the incentive. You need to have each field that you want to include as a coupon level extended field (metadata fields enabled on Incentives section of Product Settings). _ Description : Includes the offer description in incentives. _ Terms and conditions : Includes terms and conditions of the offer in incentives. The maximum number of characters accepted in terms and conditions is 500 characters. * Images : Includes images in incentives, You can add images from creative gallery or upload from your local system. You can add up to three images. Add custom metadata To add any custom metadata, click +Add custom metadata, enter metadata name, and click Save . You can add up to five custom metadata. You can add upto a maximum of 20 custom fields. Comma separated list of purpose for which you need to create coupons Possible purposes (comma-separated values) for coupon creation. These values appear on the coupon creation UI as a drop-down list for Purpos







Limit messages to send through campaigns

📘

By default, a user does not have access to enable the communication limit feature for an org. If authenticated users need access to it, log a JIRA ticket assigning it to the Engage+ Developer team.

When broadcasting multiple marketing campaigns there are chances of sending a campaign message to the same customer multiple times, resulting in customer dissatisfaction and ire. Engage+ allows you to limit the number of messages to be sent for each communication channel and overall messages. For each channel, you can set daily, weekly, and monthly limit.

📘

Day: 12:00 AM until 11:59 PM

Week: Sunday 12:00 AM until the next Saturday 11:59 PM

Month: 12:00 AM on the first of a month until 11:59 PM on the last day of the same month To know more about message limits, see Setting up communication limits for each channel.

Updated over 1 year ago