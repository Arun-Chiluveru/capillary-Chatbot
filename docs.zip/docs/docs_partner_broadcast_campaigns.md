# Scraped content from: https://docs.capillarytech.com/docs/partner-broadcast-campaigns

Partner broadcast campaigns

Suggest Edits

With Partner Broadcast Campaigns, you can issue only coupons or points without sending a communication. Further, there is a provision to export incentivesaudience and audience-related information along with incentive details to an FTP location. You can use this for orgs that want to use Capillary Engage+ to create audience lists and incentives (points or coupons) but use an external tool to send messages.

The following are the different types of partner broadcast campaigns.

Incentives only campaign

No communication message campaign

Incentives only campaign

You can assign offers and points to customers without sending any communication. For example, you can create an offer with a static coupon and assign it to an audience list. You can then send a communication to the selected audience using some external tool.

To create an incentives only campaign:

Create a Campaign and navigate to the New Message creation page.

319

In Audience, add your preferred audience lists to the campaign and navigate to the Content section. You can create an audience list in the following ways - using filters, uploading CSV, combining existing lists.

In Content, enable the Incentives only toggle button

634

Click on Add incentives and choose your desired incentive.

Select Add offers to add coupon series and claim the desired offer. To create a new offer, see Create offers.

Select Add points to add a points strategy and select the desired points allocation and points expiry strategies. To create a new points strategy, see Points strategy.

497

📘

You can add both points strategy and offer in the message content. To add another incentive type, click ADD INCENTIVES and select the other option.

Click Continue to proceed.

No communication message campaign

For FTP-enabled orgs, the No Communication FTP Campaign allows configuring only incentives (coupons/points) without any communications and exporting the data to an FTP server. The org can get the campaign details from the FTP server and can use the data to send communications using a third-party application. To create a No communication message campaign:

Create a Campaign and navigate to the New Message creation page

319

In Audience, add your preferred audience lists to the campaign and navigate to the Content section. You can create an audience list in the following ways - using filters, uploading CSV, combining existing lists.

In Content, enable the No communication message toggle button

727

Click Add FTP location and select the FTP to which you want to export the campaign details.

688

Using + Add column, add the columns that you want to export. By default, the Customer ID is selected. For example, offer name, offer expiry, customer name.

To export message content, define the message in the Message box. You need to have all the tags used in the message as CSV columns. So, ensure that you add the tags that you use in the message as columns. The message will be exported as the last column.

922

Click Done to continue.

725

Click Add Incentives to attach a point strategy/offer.

Select Add offers to add coupon series and claim the desired offer. To create a new offer, see Create offers.

Select Add points to add a points strategy and select the desired points allocation and points expiry strategies. To create a new points strategy, see Points strategy.

Click Continue to proceed to schedule the campaign.

📘

When the message is executed, the customer ID along with the selected labels are exported to the configured FTP location as a CSV file. The last column will have the message content replacing the tags used in the message with dynamic values of the respective customer.

Updated over 1 year ago