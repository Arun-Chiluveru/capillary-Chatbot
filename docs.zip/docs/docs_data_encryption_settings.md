# Scraped content from: https://docs.capillarytech.com/docs/data-encryption-settings

Points & coupons request

Administrators of an org can manage goodwill requests and also issue points or coupons directly to customers.

Suggest Edits

Goodwill coupons

Issue Goodwill coupon

To issue a coupon to a customer, perform the following:

On the Member Care homepage, search for the customer you want to issue a coupon.



Click the ellipsis menu on the Customer Single View (CSV) page.



Click Goodwill request



Click Coupons



From the Select coupon dropdown, choose any coupon of your choice.



From the Reason dropdown, choose the appropriate reason for issuing the coupon.



In the Comments section, enter a note for issuing the goodwill coupon.



Click Send request.



A coupon is issued to the customer.



To approve goodwill coupon requests, refer to old Member Care documentation here.

Issue Goodwill points

📘

Note:

By default, auto approve is enabled for points issual.

To issue goodwill points to a customer, perform the following:

On the Member Care homepage, search for the customer you want to issue points.



Click the ellipsis menu on the Customer Single View (CSV) page.



Click Goodwill request



Click Points



Enter the points you want to add in the Points to be added field.



From the Program dropdown, choose the appropriate program.



In the Comments section, enter a note for issuing the goodwill coupon.



Click Save.



Points have been issued to the customer.



Updated over 1 year ago