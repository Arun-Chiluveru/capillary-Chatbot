# Scraped content from: https://docs.capillarytech.com/docs/add-event-notification-account

Coalition program

This section provides you with information about coalition programs and how to set up a coalition program.

Suggest Edits

Coalition programs are loyalty programs of the Org that are created outside Capillary. Loyalty+ supports syncing tiers of partner programs and adding customers to the program. This means that two or more brands can collaborate to give incentives to customers. Here the burden of the incentive cost is divided between the brands and the customer can become loyal to all these brands simultaneously. For example, a car manufacturer and an insurance company can come together to incentivise customers to pick them together.

Some of the salient features of the coalition program are:

Brand partnerships to increase customer touchpoints to improve engagement and recall

Enrollment only via linking APIs

Can sync with partner tiers based on enrollment or update triggers

Does not expire unless a customer is delinked or unsubscribed from the partner's loyalty program

No program expiry, generally these contracts are long-term.



Add a coalition program

To add a subscription program

From the home page, click on the desired program.

Click Edit program.



In the Coalition Program tab, click Add coalition program.



In the Name field, enter the program's name without blank spaces.

In the Description box, enter a brief description of the program.

Click Next.



Add benefits. See Add, edit and delete benefits.

If required, set the tier settings. See Tier settings.

Click Save.

Click Publish changes.

Enter the details about the change and click Publish.



Edit a coalition program

To edit a subscription program,

From the Coalition Program, click desired coalition program > three dots icon > Edit.

Make the desired changes.

Click Save.

Click Publish changes.

Enter the details about the change and click Publish.



Tier settings

In the tier settings, you can create a partner program tier and configure a loyalty tier downgrade.

Create partner program tier

If you want to define and map the tiers in the coalition partner program to the loyalty tiers defined in the current program, in the Partner program tier,click Yes.

In the Tier field, enter the highest and lowest tier names. For example, Gold, Silver etc. To add more tiers, click Add tier and enter the names.

Click Save

Configure loyalty tier downgrade

When a customer unsubscribes or delinks from a program, you can set it to downgrade their loyalty tier automatically.

To set, in the Set loyalty tier on downgrade, select Yes and from the Downgrade to loyalty tier drop-down, select the tier to which the customer should be downgraded and click Save.



Integration

For information on integration, see Integration.

Workflow

For information on workflow, see Inside workflow.

Updated over 1 year ago