# Scraped content from: https://docs.capillarytech.com/docs/lead-based-filters

Lead based filters

Suggest Edits

Lead Status

This filter lets you build an audience groups by current lead status. You can also get customers by current lead status based on created period, lead owner, sub-status, source, and product associated with leads.

767

Filter Description Status* Get customers by current lead status. You can select multiple statuses. For example, customers whose leads are currently Open , Won , Lost , Deleted , or On hold . To learn in detail, see here . Created Period (Duration)* These filters let you filter leads by created date. Lifetime* Let you get all customers whose current lead status is as defined. During* This lets you further filter customers by purchased date. You can either choose lifetime or duration. Duration could be Specific dates or Relative days . Lifetime will consider transactions of the customer from the time of enrolling into the loyalty program. Lead Owner Let you further filter by owners assigned to leads.  For this, you need to select the TILL code followed by the associate. Sub-Status Let you filter further by lead sub-status. These are user-defined and hence you see the values that are created for the org. Source Let you filter further by the source for which the lead is created. For example, e-commerce, and Line. Product Let you filter further by product category or item code.

Lead Status Change Log

This lets you fetch customers whose lead status has changed to another in a specific duration.

765

Filter Description Status* Get customers based on change of lead status from one to another. For example, customers who migrated from Open to On hold. For more details, see here . You can also select multiple lead statuses. During* This lets you further filter customers by purchased date. You can either choose lifetime or duration. Duration could be Specific dates or Relative days . Lifetime will consider transactions of the customer from the time of enrolling into the loyalty program. Source Let you filter further by the source for which the lead is created. For example, e-commerce, and Line.

Updated over 1 year ago