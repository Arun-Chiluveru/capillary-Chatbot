# Scraped content from: https://docs.capillarytech.com/docs/search-user-journey-history

Search User Journey History

Suggest Edits

You can use the search option and search for a customer who entered a journey using the customer ID. If a customer has entered multiple times, the search result will display the date and time stamps at which the customer entered the journey. You can click on an entry instance to track the customer’s journey path.



Updated 2 months ago