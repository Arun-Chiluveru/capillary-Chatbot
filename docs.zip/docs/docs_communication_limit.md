# Scraped content from: https://docs.capillarytech.com/docs/communication-limit

Communication Limit

Suggest Edits

Some users may fall into multiple segments while creating campaigns and thus receive more than one marketing message within a short time frame. Communication Limit allows you to limit the number of messages users will get during a particular period from a specific channel or all channels.

Steps to configure communication Limit

Click on the settings button in the top right corner to head towards the Campaign Settings section.



Now select the message settings section. Scroll down to find Communication limits section.



Now here to add a new Limit click on the +add Limits button.

Now Configure the Limit.

Select the channel on which you want to put up the limit or else can also select the option of overall to put the limit over all the channels.



Now when you will select the channel you will be able to see the options of selecting time limit whether you want the limit to be on a daily basis or weekly basis or monthly basis.

Also, you have to add the count of messages you want to send.

Now click on done.



Updated 4 months ago