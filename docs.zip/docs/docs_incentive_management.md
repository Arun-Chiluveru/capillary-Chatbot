# Scraped content from: https://docs.capillarytech.com/docs/incentive-management

Incentive management

Suggest Edits

Incentive manager basically allows you to set up various custom-focused incentives like offers, promotions and gift vouchers and also allows you to select the preferred point strategy that you can set up in Loyalty.

Here you can-

Create incentives that can be audience specific

The incentive issual setting can be configured

You can also set up the redeeming conditions here.

Updated over 1 year ago