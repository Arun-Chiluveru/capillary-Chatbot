# Scraped content from: https://docs.capillarytech.com/docs/store-csv-upload

Store CSV upload

Suggest Edits

This feature enables a marketer to bulk upload a list of stores within a condition. This is very useful in cases where a brand has a large number of stores registered. The feature also helps to:

Reduce the hassle of manually adding multiple stores within a condition

Eliminate any errors that can be caused while doing so manually.

Uploading store csv

While configuring a condition, whenever you select Current store > Store, the application displays a Choose file option. To upload a CSV file that includes the list of stores:

Click Choose file. You can choose a file from your computer and upload it directly onto the condition



To download a CSV template, click Sample.csv to download

Once you have uploaded a file, the system will check the file for the right data and format and it may take up-to 30 to 150 seconds to read



If the data uploaded does not match the required format, a trigger is sent to the user to inform them that there are invalid entries within the CSV file

To download the data after successfully uploading the CSV file, click the download icon. You can download the data in two formats for referencing:

Store id

Store id, code and name



Updated over 1 year ago