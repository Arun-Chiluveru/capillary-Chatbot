# Scraped content from: https://docs.capillarytech.com/docs/rewards-event-notification

Setup OTP verification Rules

This page provides you with information on OTP configurations.

Suggest Edits

To configure rules for OTP, perform the following:

Navigate to Organisation settings > Organisation setup > OTP configurations.

Select the Time Hashed random OTP code generation checkbox to enable time-hashed random OTP generation.

In the Set OTP code length textbox, enter the required OTP length. The maximum length allowed is 50 characters.

In the OTP Code validity period text box, enter the OTP code validity in minutes.

Select the Set OTP code expiration time in minutes checkbox to enable the system to check for only recently generated OTP codes. Otherwise, it checks for any of the unexpired OTP codes.

Select the Mask the otp, access based checkbox to mask the OTPs. For more information, refer to the section Masking OTPs.

From the OTP Code type drop-down, select the OTP code type. The available options are numeric and Alphanumeric.

Select the Authorize redemptions with missed call to enable authorization of the OTP through a missed call from the number on which the OTP was received.

From the Communicate OTP via drop-down, select the channel through which the OTP needs to be sent. The platform permits the sending of OTPs based on the channels selected. For instance, if an attempt is made to send an OTP via the Zalo channel while the configuration specifies only "SMS," the OTP will not be sent. The available options are:

Email

SMS

Whatsapp

ZALO

Both Email and SMS

Both Email and WHATSAPP

Both Email and ZALO

Both SMS and WHATSAPP

Both SMS and ZALO

Email if available, else SMS

Email if available, else WHATSAPP

Email, WHATSAPP, and SMS

Email, WHATSAPP, and ZALO

Click Submit.

Masking OTPS

When enabled, OTPs will be hidden in the following GET API calls:

v1.1/customer/interactions

v2/customers/interactions



Simultaneously, you can configure it to allow users with specific access privileges to access and view the OTPs. In such cases, the system uses an internal API, v2/internal/customers/interactions.

Updated about 1 year ago