# Scraped content from: https://docs.capillarytech.com/docs/line-prerequisites

Getting Started

Suggest Edits

Prerequisites

Before integrating LINE into Capillary, ensure the following prerequisites are met:

Create a LINE account: A LINE account is the primary account used to login to the LINE Developer Platform.

Create a LINE Developer Platform Account: The LINE Developer Platform is the portal to connect and utilize the LINE API.

Create a Provider: A provider is an individual developer or organization that provides services and acquires user information on the LINE Developers platform.

Create a Channel: A channel is a communication path for providers to use the LINE platform's features.

Create a Bot: A bot allows you to send messages to users and leverage features such as rich menus and quick replies.

Create a Webhook: A webhook allows you to receive real time information from LINE.

Configure the LINE Message API: The Messaging API lets you develop two-way communication between your service and LINE users.

Channel ID and Secret Keys: The Channel ID and Secret Keys are identifiers used when integrating your LINE account with Capillary.

Creating a LINE Account

Download and install the LINE app and create an account if not already done.

Creating a LINE Developer Platform Account

Create a LINE developer account on the LINE Developers platform using your LINE account.

On the LINE Developers Console, you can manage Developers, Providers, and Channels.

Creating a Provider

To create a provider on the LINE Developer Platform, refer to the LINE Developer Console documentation on creating a provider.

❗️

Important

The provider name should be an official name such as the company name as it is used to verify your identity.

Creating a Channel

The channel is the hub through which your messages are sent. Users can join your channel and receive promotional content and announcements through LINE.

To create a channel on the LINE Developer Platform, refer to the LINE Developer Console documentation on creating a channel.

📘

Note

Choose Messaging API as the channel type while creating a channel.

Creating a Bot

Once you have created the provider and channel, you will need to create and configure a bot. This allows you to send messages to users. Additionally, you can configure the bot to use rich menus, and quick replies for a personalized experience.

To create a bot on the LINE Developer Platform, refer to the LINE Developer Console documentation on creating a bot.

Creating a Webhook

For detailed steps, refer to the Capillary Developer Documentation on creating a webhook.

📘

Note

The generated webhook URL can then be used for integration on LINE.

Setting the Webhook URL

Once the webhook URL has been created, you need to set the webhook onto the LINE developer platform.

For detailed steps to set the webhook URL on the Line Developer Platform, refer to the LINE Developer Console Documentation.

Configuring the LINE Message API

To connect your LINE account with Capillary, you need to enable the Messaging API for your account.

Follow these steps to enable Messaging API:

Log in to your LINE developer account and select your target account.

Click Settings in the top right and go to the settings screen.

Select Messaging API from the menu on the left.

Click on the Enable Messaging API button.



Select the provider you want to associate with and click on Agree.

When the Channel information appears on the screen, the Messaging API activation is complete.

Channel ID and Channel Secret Keys

These are required while setting up a LINE source account on InTouch.

Channel ID is a unique identifier of the channel.

Channel Secret Key is a unique secret key used to grant an app access to your channel.

📘

Note

Find the Channel ID and Channel Secret Keys on the LINE Developer Platform under Settings > Messaging API > Channel Info.

Updated 8 months ago

What’s Next

Configuration