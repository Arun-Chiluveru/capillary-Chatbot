# Scraped content from: https://docs.capillarytech.com/docs/configure-earning-condition-for-rewards-promotion

Configure Earning Condition (for Rewards Promotion)

Suggest Edits

Similar to loyalty earning promotions, customers need to earn reward promotions. You can define the unlock condition based on the Direct Trigger.

To configure a direct trigger, do the following.

In Earning setup, set the limit and duration for which you want to unlock the promotion and click Continue.

Option Description Maximum earning per customer Enable this option to set the number of times a customer can earn the promotion. Set expiry of the earned promotion Set the validity of the promotion. You can set the validity till the promotion duration or mention the validity duration (starting from the date of earning till the number of mentioned days).

588

Click Continue to proceed to other steps.

Next steps

Configure promotion availing conditions and benefits

Enter custom fields to include in the promotion

[Set promotion earning notification and expiry reminder ](https://docs.capillarytech.com/docs/promotion-earning-expiry-communications

Updated over 1 year ago