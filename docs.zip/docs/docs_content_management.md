# Scraped content from: https://docs.capillarytech.com/docs/content-management

Content management

Suggest Edits

Content Management lets you manage all the readily available content used for different channels like mobile push, SMS templates, and more. You can also create the content from scratch and save it for future usage.

Content management is the process of collection, delivery, retrieval, governance, and overall management of information in any format. The term is typically used in reference to the administration of the digital content lifecycle, from creation to permanent storage or deletion. The content involved may be images, video, audio and multimedia as well as text.

Updated over 1 year ago