# Scraped content from: https://docs.capillarytech.com/docs/insights-archive-report

Archive Custom Report

Suggest Edits

You can archive the custom reports created by you. To archive a report, perform the following:

Navigate to the reports list.

Click the More Options icon located next to the report you want to archive and select Archive report. You can also archive from the report view page.

In the Archive report confirmation dialogue box, click Yes, Archive. A confirmation notification appears. For private reports, the notification message appears only for you.



Unarchive a report

To unarchive a report, perform the following steps:

From the left navigation panel on the Insights+ page, navigate to Archived reports.

Click the Unarchive icon located next to the report you want to unarchive.

In the Unarchive report confirmation dialogue box, click Yes, unarchive. A confirmation notification appears.



📘

Note

Reports can remain in the archive indefinitely until they are intentionally deleted, with no automatic deletion based on a predefined time period.

Updated 7 months ago