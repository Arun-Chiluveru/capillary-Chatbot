# Scraped content from: https://docs.capillarytech.com/docs/behavioural-events-ingestion

Mark stores as inactive using the data import

Suggest Edits

You can mark stores as inactive using the data import feature. Perform the following:

Create a file with column store_code and enter the list of store codes you want to deactivate in that column.



Configure the template using the profile Org Entity Status Update.

From the identifier drop-down, select ORG_ENTITY_CODE and from the Entity type drop-down, select STORE.

Clear the Activate checkbox.



Map the store code against the Org Entity Code in the below image and import. The stores are deactivated after the data import.



Updated 9 months ago